%this function takes any list of 3-vectors and repeats them n(rpt) times in
%groups of m(grp)

%v=[1 2 3;4 5 6;7 8 9;10 11 12] if m=2 and n=3;

%v=[1 2 3;4 5 6;1 2 3;4 5 6;1 2 3;4 5 6;7 8 9;10 11 12;7 8 9
%;10 11 12;7 8
%9;10 11 12]

function valgrprptvec= repmatdiferent3D(vec,grp,rpt)

% line1=vec(:,1);
% line2=vec(:,2);
% line3=vec(:,3);

line1temp=reshape(repmat(reshape(vec(:,1),grp,[]),rpt,1),[],1);
line2temp=reshape(repmat(reshape(vec(:,2),grp,[]),rpt,1),[],1);
line3temp=reshape(repmat(reshape(vec(:,3),grp,[]),rpt,1),[],1);

valgrprptvec=[line1temp,line2temp,line3temp];
