function Area=Areafinder(name)

[~,triangle,positions]=reader(name);
tottri=size(triangle,1);
p1=positions(triangle(:,1),:);
p2=positions(triangle(:,2),:);
p3=positions(triangle(:,3),:);

b=cross((p2-p1),(p3-p1),2);
bnorm=sqrt(sum(b.^2,2));
Area=sum((0.5)*bnorm,1);
% n=b./bnorm(:,ones(3,1));
% vecheight=sum((p1-repmat([0 0 0],tottri,1)).*n,2);
% totalvolume=sum((1/3)*(Area.*vecheight),1);