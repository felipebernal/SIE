% this function is the product of the functions in the term 1_1 of the
% integral 35 in reference A.Kern  in pag 736

function funEHInt1_1farfieldval= funEHInt1_1farfield(rtoeval,rtri,nodetri,rpt,k,pm,LineNodes,triangle,positions)

%Although the original DivG (which is actually gradient of G...sorry for that!)in this term does not have a minus sign I put it here given that this is the 
%divergence over the not primed coordinate which is the same as minus the divergence of the primed 
%coordinate which we had already caculated.  

%%This is commented to improve memory resources...
%prefactor=DivRWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions);
%funEHInt1_1SMTHval=-DivGsmth(rtoeval,rtri,k).*prefactor(:,ones(3,1));
funEHInt1_1farfieldval=-DivGTOTAL(rtoeval,rtri,k).*repmat(DivRWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions),1,3);
