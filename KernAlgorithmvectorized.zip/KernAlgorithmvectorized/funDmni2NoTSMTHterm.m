% this function is the product of the functions in the second 
%integral not-smooth Dmni, i.e. div f *Kp1p1

function funDmni2NoTSMTHtermval= funDmni2NoTSMTHterm(rtri,nodetri,nodetrip,rpt,pm,LineNodes,triangle,positions)

%Given that RWGfunction and DivRWGfunction need two lists with the same
%seze where the node list is one to one with the r-position list then we
%need to modify the nodtri list.

nodetrimod=VECrpt1D(nodetri,rpt);

%In this case p means prime. 
funDmni2NoTSMTHtermval=DivRWGfunction(rtri,nodetrimod,rpt,pm,LineNodes,triangle,positions).*...
  Kp1p1(rtri,nodetrip,rpt,LineNodes,triangle,positions);