function MatPlot=FieldPlotZplane(i,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions)

% xmin=-2;
% xmax=2;
ymin=xmin;
ymax=xmax;
% xstep=0.1;
ystep=xstep;
%now we define the rtoeval list of 3-vectors.
xvec=[xmin:xstep:xmax]';
%yvec=flipud([ymin:ystep:ymax]');
yvec=[ymin:ystep:ymax]'; %no flip given that contourrf flips the matrix
sizex=size(xvec,1);
sizey=size(yvec,1);
zvec=z*ones(sizex,1);
%repx=VECrpt1D(xvec,sizey);
%repy=repmat(yvec,sizex,1);
%rtoeval=[repx,repy,zvec];

% omega=1;
% epsilonv=[1;15];
% muv=[1;1];
% direction=[1 1 0];
% pol=[0 0 1];
% rsource=[0 0 0];

% vectoplot=FieldEfinder(i,rtoeval,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,matM,LineNodes,triangle,positions);
% 
% %%%%%vectoplot=PlaneWaveE(omega,direction,pol,rtoeval,rsource);
% 
% magvectoplot=sqrt(sum(vectoplot.^2,2));
% 
% fieldnoscatter=contourf(reshape(magvectoplot,sizey,[]));



%---------------------with tiles---------------------

totalnodes=size(yvec,1);

ndiv=numberoftiles; %If commented means that we want to do it ina single go.

%ndiv=1; %if comented it mwans that we want to divide the comput.
numblock=max(gcd(totalnodes,1:ndiv));
%nodeslist=1:totalnodes;
basenodelist=1:(totalnodes/numblock);
basenodelist=basenodelist';
%nodemlist=zeros(size(nodeslist,1),numblock^2);
%nodenlist=zeros(size(nodeslist,1),numblock^2);
%noden=VECrpt1D(basenodelist,totalnodes/numblock);

nodem=repmat(basenodelist,totalnodes/numblock,1);
zpart=z*ones((totalnodes/numblock)^2,1);
MatPlot=zeros(totalnodes,totalnodes); 
h = waitbar(0,'Please wait while the Field is found...');
for conta= 1:numblock
   
    noden=VECrpt1D(basenodelist,totalnodes/numblock); 

   for contb= 1:numblock
      indexn1=((contb-1)*(totalnodes/numblock)+1);
      indexn2=((contb)*(totalnodes/numblock));
      indexm1=((conta-1)*(totalnodes/numblock)+1);
      indexm2=((conta)*(totalnodes/numblock));

      xpart=xvec(noden);
      ypart=yvec(nodem);
      rtoeval=[xpart,ypart,zpart];
      vectoplot=FieldEfinder(i,rtoeval,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,1,LineNodes,triangle,positions);
      
      MatPlot(indexm1:indexm2,indexn1:indexn2)=reshape(sqrt(sum(real(vectoplot).^2,2)),totalnodes/numblock,totalnodes/numblock);
    %Here we may have a problem of n and m indices I'm not sure if the reshaping is the one that we want.  
      %but it may very well be...chances...80% good 20% not good
     
      noden=(totalnodes/numblock)+noden;
    end
  nodem=(totalnodes/numblock)+nodem;
  waitbar(conta/numblock)
end
close(h); 
imagesc(real(MatPlot));