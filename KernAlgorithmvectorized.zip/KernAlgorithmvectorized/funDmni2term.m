% this function is the product of the functions in the second term of the
% integral Dmni, i.e. div f *G* div' f

function funDmni2termval= funDmni2term(rtri,rtrip, nodetri,nodetrip,rpt,k,pm,pmp,LineNodes,triangle,positions)

%In this case p means prime. 
preterm=Gsmth(rtri,rtrip,k);

funDmni2termval=sum(RWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions).*...
preterm(:,ones(3,1)).*RWGfunction(rtrip,nodetrip,rpt,pmp,LineNodes,triangle,positions),2);
