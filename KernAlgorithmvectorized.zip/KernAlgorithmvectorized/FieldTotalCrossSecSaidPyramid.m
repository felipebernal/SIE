function vecplot=FieldTotalCrossSecSaidPyramid

Radius=100;
numberofpoints=10;


direction=[0 0 -1];
pol=[1 0 0];
rsource=[0 0 0];
sourceinout=1;
name='SaidPyramidZ';
[LineNodes,triangle,positions]= reader(name);

thetapoints=[0:pi/(numberofpoints-1):pi]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';

alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];

%dia='07-Oct-2012';
dia='22-Oct-2012';

%dia='06-Oct-2012';
minlam=400;
maxlam=910;
deltalam=15;

vecplot=zeros(size([minlam:deltalam:maxlam]',1),1);
cont=1;

for c=minlam:deltalam:maxlam
    
    epsilonv=[1.58^2;Aluminium(c)];
    muv=[1;1];
    
    matrix=load(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\',name,'_',int2str(c),'_Matrix','.mat']);
    TheMat=matrix.TheMat;
    vector=load(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\',name,'_',int2str(c),'_Vector_','.mat']);
    TheV=vector.TheV;
   % clear('matrix','vector');
    valE=FieldEfinder(1,'scatt','far',positionsphere,(2*pi/(c/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
    %valE=FieldEfinder(1,'scatt','far',positionsphere,(2*pi/(c/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions);
    vecplot(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);
    cont=cont+1;
end
a=[[minlam:deltalam:maxlam]',vecplot];
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\TotalScattCrossSec.txt'], 'a','-ascii');
plot([minlam:deltalam:maxlam]',vecplot);
end