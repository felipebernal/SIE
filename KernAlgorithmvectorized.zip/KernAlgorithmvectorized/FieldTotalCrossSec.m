function vecplot=FieldTotalCrossSec

Radius=10;
numberofpoints=10;
epsilonv=[1;4^2];
muv=[1;1];
direction=[1 0 0];
pol=[0 0 1];
rsource=[0 0 0];
[LineNodes,triangle,positions]= reader('minisphererefinedIII');

thetapoints=[0:pi/(numberofpoints-1):pi]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';

alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];

vecplot=zeros(38,1);
cont=1;
for c=20:5:205
    matrix=load(['\\nanorfsrv\Users\Bernal\Simulations\31-Mar-2011\minisphererefinedIII_',int2str(c),'_Matrix','.mat']);
    TheMat=matrix.TheMat;
    vector=load(['\\nanorfsrv\Users\Bernal\Simulations\31-Mar-2011\minisphererefinedIII_',int2str(c),'_Vector_','.mat']);
    TheV=vector.TheV;
   % clear('matrix','vector');
    valE=FieldEfinder(1,positionsphere,(2*pi/(c/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,2,LineNodes,triangle,positions);
    vecplot(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);
    cont=cont+1;
end

%plot([20:5:205]',vecplot);
%  \\nanorfsrv\Users\Bernal\Simulations\21-Mar-2011\simulationsOmegaMin
    %  iSphere