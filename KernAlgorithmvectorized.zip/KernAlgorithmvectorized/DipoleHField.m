function valfunHDipole= DipoleHField(omega,~,pol,rtoeval,rsource,muv,epsilonv,sourceinout)
% omega is the frequency at which the dipole radiates..
%polarization is the orientation of the dipole in x y and z.
%direction  is not used at all...
%rtoeval is the position at which we want to find the E field.
%rsource is the position of the dipole


numpoints=size(rtoeval,1);
c=1;
%pol=[1 0 0];
%numr=size(rtoeval,1);
pol=repmat(pol./norm(pol),numpoints,1);

epsilon=epsilonv(sourceinout);
mu=muv(sourceinout);
k=omega*sqrt(epsilon*mu)/c;

valfunHDipole=-1i*omega*multiprod(CurlFreeDyadG(k,rtoeval,repmat(rsource,size(rtoeval,1),1)),pol',[1,2],[1])';

end