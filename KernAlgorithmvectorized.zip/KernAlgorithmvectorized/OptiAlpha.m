function residuous=OptiAlpha(x,P,E)
eta=etafromx(x);
%residuous=norm((P-eta*E)'*(P-eta*E));
%residuous=sqrt(norm(sum(sum(conj((eta*E-P))'*(eta*E-P),2),1))/norm(sum(sum(conj(eta)'*eta,2),1)));
%residuous=sqrt(norm(sum(sum(conj((eta*E-P)).*(eta*E-P),2),1))/norm(sum(sum(conj(eta).*eta,2),1)));
%residuous=sum(sum(abs(eta*E-P)./abs(P),2),1);This one is definitely not
residuous=sum(sum(abs(eta*E-P),2),1)./sum(sum(abs(P),2),1);
end