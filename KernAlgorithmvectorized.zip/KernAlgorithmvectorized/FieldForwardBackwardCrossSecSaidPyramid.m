function FieldForwardBackwardCrossSecSaidPyramid

%name='SaidPyramid3';
name='SaidPyramidY';
[LineNodes,triangle,positions]= reader(name);


%dia='07-Oct-2012';
dia='22-Oct-2012';
%dia='06-Oct-2012';
minlam=400;
%maxlam=1000;
maxlam=910;
deltalam=15;
ForwardScatteringTOP=zeros(size([minlam:deltalam:maxlam]',1),1);
BackwardScatteringTOP=zeros(size([minlam:deltalam:maxlam]',1),1);
TotalScatteringTOP=zeros(size([minlam:deltalam:maxlam]',1),1);
ForwardScatteringBottom=zeros(size([minlam:deltalam:maxlam]',1),1);
BackwardScatteringBottom=zeros(size([minlam:deltalam:maxlam]',1),1);
TotalScatteringBottom=zeros(size([minlam:deltalam:maxlam]',1),1);

cont=1;
for lambdac=minlam:deltalam:maxlam
    omega=1000*(2*pi)/lambdac;
    epsilonv=[1.58^2;Aluminium(lambdac)];
    muv=[1;1];
    matrix=load(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\',name,'_',int2str(lambdac),'_Matrix','.mat']);
    TheMat=matrix.TheMat;
    
    %%%Top Excitation
    direction=[0 -1 0];
    %direction=[0 0 -1];
    pol=[1 0 0];
    rsource=[0 0 0];
    sourceinout=1;
    %forward scattering cross section
    PosFB=100;
    positionForwardTOP=[0,-PosFB,0];
    %positionForwardTOP=[0,0,-PosFB];
    %forward scattering cross section
    PosFB=100;
    positionBackwardTOP=[0,PosFB,0];
    %positionBackwardTOP=[0,0,PosFB];
    %%%
    %%%%Near-Field scattering cross section Positions
    Radius=0.3;
    numberofpoints=10;
    thetapoints=[0:pi/(numberofpoints-1):pi]';
    phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
    alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
    allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
    positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
    %%%%
    TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
    
    valEForwardTOP=FieldEfinder(1,'scatt','far',positionForwardTOP,(2*pi/(lambdac/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
    valEBackwardTOP=FieldEfinder(1,'scatt','far', positionBackwardTOP,(2*pi/(lambdac/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
    valESphereTOP=FieldEfinder(1,'scatt','far',positionsphere,(2*pi/(lambdac/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
        
    ForwardScatteringTOP(cont)=(Radius^2).*(sum(valEForwardTOP.*conj(valEForwardTOP),2));
    BackwardScatteringTOP(cont)=(Radius^2).*(sum(valEBackwardTOP.*conj(valEBackwardTOP),2));
    TotalScatteringTOP(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valESphereTOP.*conj(valESphereTOP),2)),1);
    
    
     %%%Bottom Excitation
    direction=[0 1 0];
    %direction=[0,0,1];
    pol=[1 0 0];
    rsource=[0 0 0];
    sourceinout=1;
    %forward scattering cross section
    PosFB=100;
    positionForwardBottom=[0,PosFB,0];
    %positionForwardBottom=[0,0,PosFB];
    %forward scattering cross section
    PosFB=100;
    positionBackwardBottom=[0,-PosFB,0];
    %positionBackwardBottom=[0,0,-PosFB];
    %%%
    %%%%Near-Field scattering cross section Positions
    Radius=0.3;
    numberofpoints=10;
    thetapoints=[0:pi/(numberofpoints-1):pi]';
    phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
    alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
    allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
    positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
    %%%%
    TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
    valEForwardBottom=FieldEfinder(1,'scatt','far',positionForwardBottom,(2*pi/(lambdac/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
    valEBackwardBottom=FieldEfinder(1,'scatt','far', positionBackwardBottom,(2*pi/(lambdac/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
    valESphereBottom=FieldEfinder(1,'scatt','far',positionsphere,(2*pi/(lambdac/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
   
    ForwardScatteringBottom(cont)=(Radius^2).*(sum(valEForwardBottom.*conj(valEForwardBottom),2));
    BackwardScatteringBottom(cont)=(Radius^2).*(sum(valEBackwardBottom.*conj(valEBackwardBottom),2));
    TotalScatteringBottom(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valESphereBottom.*conj(valESphereBottom),2)),1);
   
    cont=cont+1;
end
lambdas=[minlam:deltalam:maxlam]';
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\ForwardBackwardScatteringNEARFieldScatteringTOPBOTTOM',name],...
    'lambdas','ForwardScatteringBottom','ForwardScatteringTOP','BackwardScatteringBottom','BackwardScatteringTOP',...
    'TotalScatteringBottom','TotalScatteringTOP');
figure(1)
plot(lambdas,ForwardScatteringBottom,lambdas,ForwardScatteringTOP);

figure(2)
plot(lambdas,BackwardScatteringBottom,lambdas,BackwardScatteringTOP);

figure(3)
plot(lambdas,TotalScatteringBottom,lambdas,TotalScatteringTOP);

end