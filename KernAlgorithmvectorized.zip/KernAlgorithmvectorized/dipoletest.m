function ...[dipoleparalemission,dipoleperpemission]=dipoletest(radiusbead,k,Radius)
dipolemoment=dipoletest(radiusbead,k,Radius)
%units must be placed in microns so that the epsilon of the gold is
%consistent with its units.

%global t
%t=0;
%global struct
%struct=[[1;2.127;2.127],[1;1;1]];
struct=[[1;1;1],[1;1;1]];
c=1;
center=[0,0,0];
omega=k*c;
eps0=1;
mu1=struct(1,2);
eps=Gold((2*pi/k)*1000);
%eps=3;


alphastatic=4*pi*((radiusbead)^3)*((eps-1)/(eps+2))*eye(3,3);

%alpha=((1/alphastatic)-1i*((k)^3/(6*pi)))^-1; %Thi sis the old version of
%alpha static

%invalpha=(1/alphastatic)*eye(3,3)-1i*(k)^2*(imag(GreenWaveguide(k,center,center,struct,t))+imag(FreeDyadG(k,center,center)));
%alpha=inv(invalpha)


invalpha=inv(alphastatic)-((1i*(k)^3)/(6*pi))*eye(3,3);


%invalpha=inv(alphastatic)-((1i*(k)^3)/(6*pi))*eye(3,3);
%invalpha=inv(alphastatic);

direction=[-1,0,0];
pol=[0,1,0];
positioncenterbead=[0,0,0];
E=PlaneWaveE(k,direction,pol,positioncenterbead);
dipolemoment=E/invalpha;

% 
% numberofpoints=100;
% directuni=direction/norm(direction);
% poluni=pol/norm(pol);
% polperpenduni=cross(directuni,pol)/(norm(cross(directuni,pol)));
% 
% thetapoints=[0:2*pi/(numberofpoints-1):2*pi]';
% positionsphereparalel=(Radius*cos(thetapoints)*directuni+Radius*sin(thetapoints)*poluni)+repmat(center,numberofpoints,1);
% positionsphereperpedicular=(Radius*cos(thetapoints)*directuni+ Radius*sin(thetapoints)*polperpenduni)+repmat(center,numberofpoints,1);
% 
% rsource=repmat(positioncenterbead,numberofpoints,1);
% 
% cond1par=logical(positionsphereparalel(:,3)>=0);
% cond2par=logical(positionsphereparalel(:,3)<0);
% Gparallel=zeros(3,3,size(positionsphereparalel,1));
% % Gparallel(:,:,cond1par)=GreenWaveguide(k,positionsphereparalel(cond1par,:),rsource(cond1par,:),struct,t)+FreeDyadG(k,positionsphereparalel(cond1par,:),rsource(cond1par,:));
% % Gparallel(:,:,cond2par)=GreenWaveguide(k,positionsphereparalel(cond2par,:),rsource(cond2par,:),struct,t);
% Gparallel(:,:,cond1par)=FreeDyadG(k,positionsphereparalel(cond1par,:),rsource(cond1par,:));
% Gparallel(:,:,cond2par)=FreeDyadG(k,positionsphereparalel(cond2par,:),rsource(cond2par,:));
% 
% 
% cond1perp=logical(positionsphereperpedicular(:,3)>=0);
% cond2perp=logical(positionsphereperpedicular(:,3)<0);
% Gperpendicular=zeros(3,3,size(positionsphereperpedicular,1));
% % Gperpendicular(:,:,cond1perp)=GreenWaveguide(k,positionsphereperpedicular(cond1perp,:),rsource(cond1perp,:),struct,t)+FreeDyadG(k,positionsphereperpedicular(cond1perp,:),rsource(cond1perp,:));
% % Gperpendicular(:,:,cond2perp)=GreenWaveguide(k,positionsphereperpedicular(cond2perp,:),rsource(cond2perp,:),struct,t);
% Gperpendicular(:,:,cond1perp)=FreeDyadG(k,positionsphereperpedicular(cond1perp,:),rsource(cond1perp,:));
% Gperpendicular(:,:,cond2perp)=FreeDyadG(k,positionsphereperpedicular(cond2perp,:),rsource(cond2perp,:));
% 
% 
% 
% 
% Efieldsparallel=k^2*multiprod(Gparallel,repmat(dipolemoment,numberofpoints,1)',[1,2],[1])';
% Efieldsperpendicular=k^2*multiprod(Gperpendicular,repmat(dipolemoment,numberofpoints,1)',[1,2],[1])';
% %polar([0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* sum(Efieldsparallel.*conj(Efieldsparallel),2)); 
% 
% 
% % subplot(2,1,1), polar([0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* sum(Efieldsparallel.*conj(Efieldsparallel),2)),title('\it{Circle parallel to the polarization-k plane }','FontSize',16);
% % subplot(2,1,2), polar([0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* sum(Efieldsperpendicular.*conj(Efieldsperpendicular),2)),title('\it{Circle perpendicular to the polarization-k plane }','FontSize',16);
% 
% figure(1);
% polar([[0:2*pi/(numberofpoints-1):2*pi]';NaN;[0:2*pi/(numberofpoints-1):2*pi]'],[4*pi*Radius^2* sum(Efieldsparallel.*conj(Efieldsparallel),2);NaN;4*pi*Radius^2* sum(Efieldsperpendicular.*conj(Efieldsperpendicular),2)]); 
% dipoleparalemission=4*pi*Radius^2* sum(Efieldsparallel.*conj(Efieldsparallel),2);
% dipoleperpemission=4*pi*Radius^2* sum(Efieldsperpendicular.*conj(Efieldsperpendicular),2);
% 
% 
% 
% 
% % 
% %      Escatsqrparallel=sum(vecplotparallel.*conj(vecplotparallel),2);%sum(abs(vecplotparallel).^2,2);
% %      sigmascatparallel=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2*Escatsqrparallel];
% %      
% %      Escatsqrperpendm=sum(vecplotperpedicular.*conj(vecplotperpedicular),2);    %sum(abs(vecplotperpedicular),2);
% %      sigmascatperpend=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* Escatsqrperpendm];