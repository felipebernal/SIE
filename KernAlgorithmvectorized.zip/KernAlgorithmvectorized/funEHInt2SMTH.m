% this function is the product of the functions in the
% second integral in function 35 in reference A.Kern  in pag 736

function funEHInt2SMTHval= funEHInt2SMTH(rtoeval,rtri,nodetri,rpt,k,pm,LineNodes,triangle,positions)

%Although the original DivG (which is actually gradient of G...sorry for that!)in this term does not have a minus sign I put it here given that this is the 
%divergence over the not primed coordinate which is the same as minus the divergence of the primed 
%coordinate which we had already caculated.  
funEHInt2SMTHval=cross(DivGsmth(rtoeval,rtri,k),RWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions),2);