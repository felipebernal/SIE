function Valh=Hh(r,p1,p2,p3)

b=cross((p2-p1),(p3-p1),2);
normb=sqrt(sum(b.^2,2));
n=b./normb(:,ones(3,1));
numr=size(r,1);
%P1=p1(ones(numr,1),:);
%N=n(ones(numr,1),:);
Valh=sum(n.*(r-p1),2);

%%Checked