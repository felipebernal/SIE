function fvec = RWGtest(n,r,pm,LineNodes,triangle,positions)
%r is a vector that belongs to the surface and therefore it is assumed that
%it belongs to a certain triangle. ie. RWG function is only defined for R
%that lie on the surface and not for any other point in space.
%pm is plus or minus and is another index for the function, which defines
%on which triangle are we working with.
nodes1=0;
nodes2=0;
nodepm1=0;
nodepm2=0;
%Definition of the nodes of each triangle and the area
nodes1=positions([triangle(LineNodes(n,1),1)...
    triangle(LineNodes(n,1),2) triangle(LineNodes(n,1),3)],:);
nodes2=positions([triangle(LineNodes(n,2),1)...
    triangle(LineNodes(n,2),2) triangle(LineNodes(n,2),3)],:);
nodepm1=positions(triangle(LineNodes(n,1),LineNodes(n,3)),:);
nodepm2=positions(triangle(LineNodes(n,2),LineNodes(n,4)),:);
Area1=norm( cross((nodes1(1,:)-nodes1(3,:)),(nodes1(2,:)-nodes1(3,:))))/2;
Area2=norm( cross((nodes2(1,:)-nodes2(3,:)),(nodes2(2,:)-nodes2(3,:))))/2;

if pm==1
    fvec=(LineNodes(n,5)/(2*Area1))*(r-nodepm1);
else
    if pm==2
       fvec=(-LineNodes(n,5)/(2*Area2))*(r-nodepm2);
    else
        return
    end
end