% This function finds the value of the integral I^{s}_{-3} from the paper
% PIER 63, 243-278, 2006

function hOmega =Ism3(r,p1,p2,p3) 

b=cross((p2-p1),(p3-p1),2);

normb=sqrt(sum(b.^2,2));
n=b./normb(:,ones(3,1));



hval=sum(n.*(r-p1),2);

%this is tony's trick to transform p1 in a column of3-vectors of p1 with
%size of r positions.
%Tonys trick dnorm(:,ones(3,1))

dnorm1=sqrt(sum((p1-r).^2,2));
dnorm2=sqrt(sum((p2-r).^2,2));
dnorm3=sqrt(sum((p3-r).^2,2));

%sqrt(sum((A).^2,2)) is the norm of 3 vectors organized in a column
%Dnorm just repeats the column vector dnorm 3 times so we can vectorize the
%a's
a1=(p1-r)./dnorm1(:,ones(3,1));
a2=(p2-r)./dnorm2(:,ones(3,1));
a3=(p3-r)./dnorm3(:,ones(3,1));
%sqrt(sum((A).^2,2)) is the vectorized norm of a a column of vectors
x=1+sum(a1.*a2,2)+sum(a1.*a3,2)+sum(a2.*a3,2);
%sum(a1.*a2,2) is the vectorized inner product between a1 and a2 for a list
%of vectors.
y=abs(sum(a1.*cross(a2,a3,2),2));
%y=sqrt(sum((yb).^2,2));

%Given the convention of the sign of the solid angle
%(see pag 254 of the reference) the sign of omega=2arctan(y/x) is equal to
%the sign of h

hOmega=2*(1./hval).*atan2(y,x).*sign(hval);


%%Checked and Double Checked
