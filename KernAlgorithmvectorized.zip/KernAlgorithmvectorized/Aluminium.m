function epsilon=Aluminium(lambda)
%The units of Lambda are in nanometers!!!

% epsinf=4;
% Lp=141;
% gama=17000;
% epsilon=epsinf-((1./(Lp^2)*(1./(lambda.^2)+(1i./(gama.*lambda)))));


Aluminiumrefractiveindex=load('Aluminiumrefractiveindex.mat');
nt=Aluminiumrefractiveindex.Aluminumrefractiveindex;
Lambdatable=nt(:,1)*1000;
n=nt(:,2);
ninter=interp1(Lambdatable,n,lambda);
epsilon=ninter.^2;