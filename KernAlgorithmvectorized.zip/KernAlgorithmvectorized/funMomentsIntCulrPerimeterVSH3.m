function funMomentsIntVSH3val= funMomentsIntCulrPerimeterVSH3(l,m,rtri,nodetri,rpt,k,pm,LineNodes,triangle,positions)

tri1=LineNodes(nodetri,pm);
p1=positions(triangle(tri1,1),:);
p2=positions(triangle(tri1,2),:);
p3=positions(triangle(tri1,3),:);
b=cross((p2-p1),(p3-p1),2);
bnorm=sqrt(sum(b.^2,2));
n=b./bnorm(:,ones(3,1));
p2p1norm=sqrt(sum((p2-p1).^2,2));
m1=cross((p2-p1)./p2p1norm(:,ones(3,1)),n,2);
p3p2norm=sqrt(sum((p3-p2).^2,2));
m2=cross((p3-p2)./p3p2norm(:,ones(3,1)),n,2);
p1p3norm=sqrt(sum((p1-p3).^2,2));
m3=cross((p1-p3)./p1p3norm(:,ones(3,1)),n,2);


mx=[m1(:,1),m1(:,1),m2(:,1),m2(:,1),m3(:,1),m3(:,1)].';
my=[m1(:,2),m1(:,2),m2(:,2),m2(:,2),m3(:,2),m3(:,2)].';
mz=[m1(:,3),m1(:,3),m2(:,3),m2(:,3),m3(:,3),m3(:,3)].';
mvector=[mx(:),my(:),mz(:)];

theta=atan2(sqrt(rtri(:,1).^2+rtri(:,2).^2),rtri(:,3));
phi=atan2(rtri(:,2),rtri(:,1));


r=sqrt(rtri(:,1).^2+rtri(:,2).^2+rtri(:,3).^2);
kr=k*r;

nodePer=VECrpt1D(nodetri,6);

funMomentsIntVSH3val=conj(Ylm(l,m,theta,phi)).*jl(l,kr).*(sum(cross(rtri,RWGfunction(rtri,nodePer,rpt,pm,LineNodes,triangle,positions),2).*mvector,2));
%funMomentsIntVSH3val=sqrt((sum(mvector.*mvector,2)));

function valYlm=Ylm(l,m,theta,phi)
LegeCosthetaLM=legendre(l,cos(theta));
if m>=0&&m<=l
valYlm=sqrt(((2*l+1)/(4*pi))*factorial(l-m)/factorial(l+m)).*LegeCosthetaLM(m+1,:)'.*exp(1i*m*phi);
elseif m<0&&m<=l
   absm=abs(m);
 valYlm=(-1)^(absm)*conj(sqrt(((2*l+1)/(4*pi))*factorial(l-absm)/factorial(l+absm)).*LegeCosthetaLM(absm+1,:)'.*exp(1i*absm*phi));  
elseif m>l
    valYlm=zeros(size(theta,1),1);
end
end

function valsphebessel=jl(l,x)
valsphebessel=sqrt(pi./(2*x)).* besselj(l+1/2,x);
end

end