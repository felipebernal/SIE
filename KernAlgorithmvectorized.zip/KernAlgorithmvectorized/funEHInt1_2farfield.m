% this function is the product of the functions in the term 1_2 of the
% integral 35 in reference A.Kern  in pag 736 but with the total G for the
% far field

function funEHInt1_2farfieldval= funEHInt1_2farfield(rtoeval,rtri,nodetri,rpt,k,pm,LineNodes,triangle,positions)

  
funEHInt1_2farfieldval=repmat(GTOTAL(rtoeval,rtri,k),1,3).*RWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions);
