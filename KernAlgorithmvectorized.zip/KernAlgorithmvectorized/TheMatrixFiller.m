function TheMatrix = TheMatrixFiller(omega,epsilon,mu,LineNodes,triangle,positions,numberoftiles)

% This function fills up the big matrix which should be
% [D1+D2 -K1-K2; K1+K2 (1/Z1^2)D1 (1/Z2^2)D2]

%This is the function that need to be changed in case there are more than 2
%materials, it is rather easy in that case to change it.
%Actually not only this one but also Dmni and Kmni...in there it is
%necesary to say that the matices for i=!1 (not air) should be only as big
%as the number of nodes that are in contact with i=2,3....Nmaterials
%but it should be easy
% 
TheMatrix=zeros(size(LineNodes,1)*2,size(LineNodes,1)*2);
K1=zeros(size(LineNodes,1),size(LineNodes,1));
K2=zeros(size(LineNodes,1),size(LineNodes,1));
D1=zeros(size(LineNodes,1),size(LineNodes,1));
D2=zeros(size(LineNodes,1),size(LineNodes,1));

h = waitbar(0,'Please wait...Matrix being filled...');
K1=Kmni(1,omega,epsilon,mu,LineNodes,triangle,positions,numberoftiles);
waitbar(1/4);
K2=Kmni(2,omega,epsilon,mu,LineNodes,triangle,positions,numberoftiles);
waitbar(2/4);
D1=Dmni(1,omega,epsilon,mu,LineNodes,triangle,positions,numberoftiles);
waitbar(3/4);
D2=Dmni(2,omega,epsilon,mu,LineNodes,triangle,positions,numberoftiles);
waitbar(4/4);
Z1=Zi(1,epsilon,mu);
Z2=Zi(2,epsilon,mu);
close(h); 
%TheMatrix=[D1+D2, -K1-K2; K1+K2, (1/(Z1^2))*D1+(1/(Z2^2))*D2];

TheMatrix(1:size(LineNodes,1),1:size(LineNodes,1))=D1+D2;
TheMatrix(size(LineNodes,1)+1:end,size(LineNodes,1)+1:end)=(1/(Z1^2))*D1+(1/(Z2^2))*D2;
clear('D1','D2');
TheMatrix(1:size(LineNodes,1),size(LineNodes,1)+1:end)=-K1-K2;
TheMatrix(size(LineNodes,1)+1:end,1:size(LineNodes,1))=K1+K2;





