
function ...[alphafinal,NeeONhh,fvaltol]=PolarizabilityTensorCalculator(k,epsilonv,muv,TheMat,name)
            alphafinal=PolarizabilityTensorCalculator(k,epsilonv,muv,TheMat,name)
%This function retrieves the polarizability tensor by doing six different
%calculations over the system then it retrieves the dipole moments and we
%know that the matrix p made out the dipole moment vectores in columns of 6
%simulations so 6 coulums multiplied by the inverse of the matrix E made by
%the six different input fields gives alpha which is the polarizability
%matrix.
% In other words b dot inv(E)=alpha.

sourceinout=1;
c=1;
omega=k*c;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date;

[LineNodes,triangle,positions]= reader(name);
rsource=[0,0,0];

%
positioncenterstructure=[0,0,0];
%%%With only 6 diferent vectors retrieval of alpha

directionmatrix=[1 0 0;0 1 0;0 0 1];

polarizationmatrix=[0 1 0;0 0 1;1 0 0;0 0 1;1 0 0;0 1 0];
%This was the original not useful for counterpropagting fields
%orderer=[1,1; 1,2; 2,3; 2,4; 3,5; 3,6];
orderer=[1,1; 1,2; 2,3; 2,3; 3,5; 3,6];

sizeN=6;


%%%With many different vectors from many different angle retieval from
%%%alpha:
% rpt=4;
% theta=linspace(0, pi, rpt)';
% phi=linspace(0, pi, rpt)';
% 
% theta=repmat(theta,rpt,1);
% phi=VECrpt1D(phi,rpt);
% 
% directionmatrixHalf=[cos(phi).*sin(theta), sin(phi).*sin(theta), -cos(theta)];
% polarizationmatrix1=[-sin(phi),  cos(phi) 0*sin(theta)];
% polarizationmatrix2=[cos(phi).*cos(theta),  sin(phi).*cos(theta), sin(theta)];
% 
% directionmatrix=repmat(directionmatrixHalf,2,1);
% polarizationmatrix=[polarizationmatrix1;polarizationmatrix2];
% sizeN=size(directionmatrix,1);


MatP=zeros(6,sizeN);
MatE=zeros(6,sizeN);
for dircont=1:sizeN
    
    direction=directionmatrix(orderer(dircont,1),:);
    pol=polarizationmatrix(orderer(dircont,2),:);
    %direction=directionmatrix(dircont,:);
    %pol=polarizationmatrix(dircont,:);
    
    %%%%%Alpha found with the currents dipole calculator:
%     TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
%     [Totalelectricdipole,Totalmagneticdipole]=effectivedipolecalculator(k,epsilonv,muv,TheMat,TheV,name);
%     E=PlaneWaveE(k,direction,pol,positioncenterstructure);
%     H=PlaneWaveH(k,direction,pol,positioncenterstructure);
%     MatP(:,dircont)=[Totalelectricdipole,Totalmagneticdipole].';
%     MatE(:,dircont)=[E,H].';   
    
    %%%%%Alpha found with the projection of the fields in vector spherical harmonics:
    
%%%%%%%%%%%%%%Here we have the change into only counterpropagating beams
%     if dircont<=3
%     CounterpropE=@(om,di,po,reval,rso) (1/2)*(PlaneWaveE(om,di,po,reval,rso)+PlaneWaveE(om,-1*di,po,reval,rso));
%     CounterpropH=@(om,di,po,reval,rso) (1/2)*(PlaneWaveH(om,di,po,reval,rso)+PlaneWaveH(om,-1*di,po,reval,rso));
%     else
%        CounterpropE=@(om,di,po,reval,rso) (1/2)*(PlaneWaveE(om,di,po,reval,rso)+PlaneWaveE(om,-1*di,-1*po,reval,rso));
%     CounterpropH=@(om,di,po,reval,rso) (1/2)*(PlaneWaveH(om,di,po,reval,rso)+PlaneWaveH(om,-1*di,-1*po,reval,rso)); 
%     end
%     
    
    if dircont<=3
    CounterpropE=@(om,di,po,reval,rso,m,ep,souinout) (1/2)*(PlaneWaveE(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveE(om,-1*di,po,reval,rso,m,ep,souinout));
    CounterpropH=@(om,di,po,reval,rso,m,ep,souinout) (1/2)*(PlaneWaveH(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveH(om,-1*di,po,reval,rso,m,ep,souinout));
    else
       CounterpropE=@(om,di,po,reval,rso,m,ep,souinout) (1/2)*(PlaneWaveE(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveE(om,-1*di,-1*po,reval,rso,m,ep,souinout));
    CounterpropH=@(om,di,po,reval,rso,m,ep,souinout) (1/2)*(PlaneWaveH(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveH(om,-1*di,-1*po,reval,rso,m,ep,souinout)); 
    end
    
        
    %TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
    TheV=TheVectorFiller(omega,direction,pol,rsource,CounterpropE,CounterpropH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
    
    [Dipoles,Quadrupoles]=VectorSphericalHarmonicsMultipoleRetrieval(k,epsilonv,muv,TheMat,TheV,direction,pol,rsource,name,sourceinout);
    Totalelectricdipole=Dipoles(1:3);
    Totalmagneticdipole=Dipoles(4:6);
    
    %E=PlaneWaveE(k,direction,pol,positioncenterstructure);
    %H=PlaneWaveH(k,direction,pol,positioncenterstructure);
    
    E=CounterpropE(k,direction,pol,positioncenterstructure,0*positioncenterstructure,0,0,0);%Here we put 0 toignore the values for muv epsilonv and sourceinout
    H=CounterpropH(k,direction,pol,positioncenterstructure,0*positioncenterstructure,0,0,0);%Here we put 0 toignore the values for muv epsilonv and sourceinout
    
    
    
    MatP(:,dircont)=[Totalelectricdipole;Totalmagneticdipole];
    MatE(:,dircont)=[E,H].';   
end

alpha=MatP/MatE; %This is the same as MatP*inv(MatE)


if 1<-1
%%%%Here we have another solution for alpha which preconditions the stuff
minimizefunct= @(x) OptiAlpha(x,MatP,MatE);
[Xmin,fvaltol]=fminsearch(minimizefunct,alpha(:),optimset('PlotFcns',@optimplotfval,'TolX',1e-8));
%[Xmin,fvaltol]=fminsearch(minimizefunct,alpha(:));
alphafinal=zeros(6,6);
alphafinal=etafromx(Xmin);
%NeeONhh=norm(trace(alphafinal(1:3,1:3))/trace(alphafinal(4:6,4:6)));
else
    
   alphafinal=alpha; 
end

end

function residuous=OptiAlpha(x,P,E)
eta=etafromx(x);
%residuous=norm((P-eta*E)'*(P-eta*E));
 %residuous=norm(sum(sum(conj((eta*E-P)).'*(eta*E-P),2),1))/norm(sum(sum(conj(eta)'*eta,2),1));
 residuous=sum(sum(abs(eta*E-P),2),1)./sum(sum(abs(P),2),1);
end

function eta=etafromx(x)
eta=zeros(6,6);
% %version one of eta
% eta(1,1)=x(1);
% eta(2,1)=x(2);
% eta(3,1)=x(3);
% eta(4,1)=x(4);
% eta(5,1)=x(5);
% eta(6,1)=x(6);
% 
% eta(1,2)=x(7);
% eta(2,2)=x(8);
% eta(3,2)=x(9);
% eta(4,2)=x(10);
% eta(5,2)=x(11);
% eta(6,2)=x(12);
% 
% 
% eta(1,3)=x(13);
% eta(2,3)=x(14);
% eta(3,3)=x(15);
% eta(4,3)=x(16);
% eta(5,3)=x(17);
% eta(6,3)=x(18);
% 
% eta(1,4)=x(19);
% eta(2,4)=x(20);
% eta(3,4)=x(21);
% eta(4,4)=x(22);
% eta(5,4)=x(23);
% eta(6,4)=x(24);
% 
% eta(1,5)=x(25);
% eta(2,5)=x(26);
% eta(3,5)=x(27);
% eta(4,5)=x(28);
% eta(5,5)=x(29);
% eta(6,5)=x(30);
% 
% eta(1,6)=x(31);
% eta(2,6)=x(32);
% eta(3,6)=x(33);
% eta(4,6)=x(34);
% eta(5,6)=x(35);
% eta(6,6)=x(36);
% 
% %%%%%%

% %version two of eta, Neh and Nhe are
%the minus transpose of the other
% eta(1,1)=x(1);
% eta(2,1)=x(2);
% eta(3,1)=x(3);
% eta(4,1)=x(4);
% eta(5,1)=x(5);
% eta(6,1)=x(6);
% 
% eta(1,2)=x(2);
% eta(2,2)=x(8);
% eta(3,2)=x(9);
% eta(4,2)=x(10);
% eta(5,2)=x(11);
% eta(6,2)=x(12);
% 
% 
% eta(1,3)=x(3);
% eta(2,3)=x(9);
% eta(3,3)=x(15);
% eta(4,3)=x(16);
% eta(5,3)=x(17);
% eta(6,3)=x(18);
% 
% eta(1,4)=-x(4);
% eta(2,4)=-x(10);
% eta(3,4)=-x(16);
% eta(4,4)=x(22);
% eta(5,4)=x(23);
% eta(6,4)=x(24);
% 
% eta(1,5)=-x(5);
% eta(2,5)=-x(11);
% eta(3,5)=-x(17);
% eta(4,5)=x(23);
% eta(5,5)=x(29);
% eta(6,5)=x(30);
% 
% eta(1,6)=-x(6);
% eta(2,6)=-x(12);
% eta(3,6)=-x(18);
% eta(4,6)=x(24);
% eta(5,6)=x(30);
% eta(6,6)=x(36);
% 
% %%%%%%

% %version three of eta...where the nee and Nhh are just diagonal matrices,Neh and Nhe are
%the minus transpose of the other
% eta(1,1)=x(1);
% eta(2,1)=0*x(2);
% eta(3,1)=0*x(3);
% eta(4,1)=x(4);
% eta(5,1)=x(5);
% eta(6,1)=x(6);
% 
% eta(1,2)=0*x(2);
% eta(2,2)=x(8);
% eta(3,2)=0*x(9);
% eta(4,2)=x(10);
% eta(5,2)=x(11);
% eta(6,2)=x(12);
% 
% 
% eta(1,3)=0*x(3);
% eta(2,3)=0*x(9);
% eta(3,3)=x(15);
% eta(4,3)=x(16);
% eta(5,3)=x(17);
% eta(6,3)=x(18);
% 
% eta(1,4)=-x(4);
% eta(2,4)=-x(10);
% eta(3,4)=-x(16);
% eta(4,4)=x(22);
% eta(5,4)=0*x(23);
% eta(6,4)=0*x(24);
% 
% eta(1,5)=-x(5);
% eta(2,5)=-x(11);
% eta(3,5)=-x(17);
% eta(4,5)=0*x(23);
% eta(5,5)=x(29);
% eta(6,5)=0*x(30);
% 
% eta(1,6)=-x(6);
% eta(2,6)=-x(12);
% eta(3,6)=-x(18);
% eta(4,6)=0*x(24);
% eta(5,6)=0*x(30);
% eta(6,6)=x(36);
% %%%%%%

%version foure of eta where Nee and Nhh are symetric and Neh and Nhe are
%the minus transpose of the other
eta(1,1)=x(1);
eta(2,1)=x(2);
eta(3,1)=x(3);
eta(4,1)=x(4);
eta(5,1)=x(5);
eta(6,1)=x(6);

eta(1,2)=x(2);
eta(2,2)=x(8);
eta(3,2)=x(9);
eta(4,2)=x(10);
eta(5,2)=x(11);
eta(6,2)=x(12);


eta(1,3)=x(3);
eta(2,3)=x(9);
eta(3,3)=x(15);
eta(4,3)=x(16);
eta(5,3)=x(17);
eta(6,3)=x(18);

eta(1,4)=-x(4);
eta(2,4)=-x(10);
eta(3,4)=-x(16);
eta(4,4)=x(22);
eta(5,4)=x(23);
eta(6,4)=x(24);

eta(1,5)=-x(5);
eta(2,5)=-x(11);
eta(3,5)=-x(17);
eta(4,5)=x(23);
eta(5,5)=x(29);
eta(6,5)=x(30);

eta(1,6)=-x(6);
eta(2,6)=-x(12);
eta(3,6)=-x(18);
eta(4,6)=x(24);
eta(5,6)=x(30);
eta(6,6)=x(36);

%%%%%%

end