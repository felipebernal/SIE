function valfunHDipole= MagneticDipoleHField(omega,~,pol,rtoeval,rsource,muv,epsilonv,sourceinout)
% omega is the frequency at which the dipole radiates..
%polarization or pol is the orientation of the dipole in x y and z.
%direction is not used at all...
%rtoeval is the position at which we want to find the E field.
%rsource is the position of the dipole

%to define the magnetic field of a magnetic dipole we use the electric
%field of an electric dipole and change mu0mu by eps0eps.

numpoints=size(rtoeval,1);

mu0=1;
eps0=1;
c=1;
epsilon=epsilonv(sourceinout);
mu=muv(sourceinout);
pol=repmat(pol./norm(pol),numpoints,1);
k=omega*sqrt(epsilon*mu)/c;

valfunHDipole=omega^2.*eps0*epsilon*multiprod(FreeDyadG(k,rtoeval,repmat(rsource,size(rtoeval,1),1)),pol',[1,2],[1])';

end