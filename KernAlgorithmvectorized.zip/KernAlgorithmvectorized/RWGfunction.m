function fvec = RWGfunction(r,node,rpt,pm,LineNodes,triangle,positions)


%r is a vector that belongs to the surface and therefore it is assumed that
%it belongs to a certain triangle. ie. RWG function is only defined for R
%that lie on the surface and not for any other point in space. (in this
%case)In general it would be zero outside, but that is not coded here.
%pm is plus or minus and is another index for the function, which defines
%on which triangle are we working with.
%%version 2 strating from scratch to make it vectorized not only for r but
%also for the triangles.
%node is the sharedlinenode list , r is the list of positions for
%each triangle, pm is the first or second triangle.
%rpn is the number of r per sharednode 
%n has to be a column vector!!!
%numnodes=size(n,1);
%numr=size(r,1);


%node=VECrpt1D(node,rpt);Tghis is not needed given that the list of nodes
%given in the double quadrature alredy repeats the nodes in the list for
%the r's per node.
%This part takes nodes and repeats it rpt times

if pm==1
%        Prefactor1=(LineNodes(node,5)./(2*LineNodes(node,6)));
%        fvec=Prefactor1(:,ones(3,1)).*(r-positions(triangle(sub2ind(size(triangle), LineNodes(node,1), LineNodes(node,3))),:));
         fvec=repmat( (LineNodes(node,5)./(2*LineNodes(node,6))),1,3).*(r-positions(triangle(sub2ind(size(triangle), LineNodes(node,1), LineNodes(node,3))),:));
else
    if pm==2
%        Prefactor2=(-1)*(LineNodes(node,5)./(2*LineNodes(node,7)));
%        fvec=Prefactor2(:,ones(3,1)).*(r-positions(triangle(sub2ind(size(triangle), LineNodes(node,2), LineNodes(node,4))),:));
         fvec=repmat((-1)*(LineNodes(node,5)./(2*LineNodes(node,7))),1,3).*(r-positions(triangle(sub2ind(size(triangle), LineNodes(node,2), LineNodes(node,4))),:));
    else
        return
    end
end

