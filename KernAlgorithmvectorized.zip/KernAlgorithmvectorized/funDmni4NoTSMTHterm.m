% this function is the product of the functions in the fourth
%integral not-smooth Dmni, i.e. f dot Kp1p2

function funDmni4NoTSMTHtermval= funDmni4NoTSMTHterm(rtri,nodetri,nodetrip,rpt,pm,LineNodes,triangle,positions)
%In this case p means prime. 


%Given that RWGfunction and DivRWGfunction need two lists with the same
%seze where the node list is one to one with the r-position list then we
%need to modify the nodtri list.

nodetrimod=VECrpt1D(nodetri,rpt);

funDmni4NoTSMTHtermval=sum(RWGfunction(rtri,nodetrimod,rpt,pm,LineNodes,triangle,positions).*...
  Kp1p2(rtri,nodetrip,rpt,LineNodes,triangle,positions),2);