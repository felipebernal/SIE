% This function finds the value of the integral I^{L}_{-1} from the paper
% PIER 63, 243-278, 2006

function lnR =ILm1(r,pa,pb)
%pa and pb should be a list of 3-vectors with as many positions as r

numr=size(r,1);

%this is tony's trick to transform pa and b in a column of 3-vectors
%of pa and b with size of size(r,1) positions.

Rp=sqrt(sum((r-pb).^2,2));
Rm=sqrt(sum((r-pa).^2,2));
%sqrt(sum((A).^2,2)) is the vectorized norm of a a column of vectors
normpbpa=sqrt(sum((pb-pa).^2,2));
s=(pb-pa)./normpbpa(:,ones(3,1));
sp= sum((pb-r).*s,2);
sm= sum((pa-r).*s,2);
%sum(a1.*a2,2) is the vectorized inner product between a1 and a2 for a list
%of vectors.
R02=Rm.^2-sm.^2;
lnR=zeros(numr,1);
integ=log((Rp+sp)./(Rm+sm));

%integ=log(sp+sqrt((sp.^2)+R02))-log(sm+sqrt((sm.^2)+R02));

lnR(logical(R02>1e-15))=integ(logical(R02>1e-15));

%This is an if for if RO2 is zero then only those values different than
%zero are evaluated and given inside lnR.
%This part uses logical indexing to do the following if
%but vectorized. it is not R02==0 but <1e-15 in order to avoid problems.
%if R02==0
%    
%    lnR=0
%else
%   lnR=log((Rp+sp)./(Rm+sm));
%end




%% Checked Double Checked