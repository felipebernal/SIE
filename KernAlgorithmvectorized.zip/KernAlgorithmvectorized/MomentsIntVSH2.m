function valMomentsIntVSH2= MomentsIntVSH2(l,m,k,node,LineNodes,triangle,positions)

%Dmnismth(k,mu,nodem,noden,LineNodes,triangle,positions)
%c=1;
%omega=c*k;
barycentryctable;

[rpos1, rpos2]=BarycentGaussQuadPos(node,SPQ,LineNodes,triangle,positions);
%This function findss the positions for the plus 1 and minus 2 triangles
%for the list of nodes gven in nodem.
rpt=size(rpos1,1)/size(node,1);


valMomentsIntVSH2=BaryQuadratureSimpleOneNodeMomentsVSH2(l,m,k,rpos1,rpos2,weigths,@funMomentsIntVSH2,node,rpt,LineNodes,triangle,positions,1);               

