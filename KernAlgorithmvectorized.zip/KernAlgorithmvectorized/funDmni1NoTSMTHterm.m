% this function is the product of the functions in the first 
%integral not-smooth Dmni, i.e. div f *Km1p1

function funDmni1NoTSMTHtermval= funDmni1NoTSMTHterm(rtri,nodetri,nodetrip,rpt,pm,LineNodes,triangle,positions)


%Given that RWGfunction and DivRWGfunction need two lists with the same
%seze where the node list is one to one with the r-position list then we
%need to modify the nodtri list.

nodetrimod=VECrpt1D(nodetri,rpt);

%In this case p means prime. 
funDmni1NoTSMTHtermval=DivRWGfunction(rtri,nodetrimod,rpt,pm,LineNodes,triangle,positions).*...
  Km1p1(rtri,nodetrip,rpt,LineNodes,triangle,positions);

