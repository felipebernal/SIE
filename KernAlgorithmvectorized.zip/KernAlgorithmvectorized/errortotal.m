function [errror]=errortotal

%matrixvalues=readerfiles;
name='minisphererefinedIII';
[LineNodes,triangle,positions]=reader(name);
%[LineNodes,triangle,positions]= reader('minisphererefinedIII');

epsilonv=[1;(4)^2];
%epsilonv=[1;Gold(1000*(2*pi)/omega)]; %This one suposes that a=1micron (the unit of lenght)
muv=[1;1];
direction=[1 0 0];
pol=[0 0 1];
rsource=[0 0 0];


%Radius=1.00000;
numberofpoints=91;
numberoftilesMatrix=4;

icont=1;
z=0;
numberoftiles=10;
xmin=-1;
xmax=1;
xstep=0.1;
Radius=10;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia='31-Mar-2011';%date; %This is done so that if the simulation takes more than a day then you don't have problems saving the data.
%matrixsimulations=zeros(numberofpoints,2,20);
errror=zeros(20,3);
cont=1;
for lambda=10:10:200
   
    matrixvalues=load(['\\nanorfsrv\Users\Bernal\Simulations\31-Mar-2011\MIEFILESR0.009964\',int2str(lambda),'nm.txt'],'-ascii');
    matrixvalues(:,2:4)=matrixvalues(:,2:4)*((lambda/1000)^2)/pi;
    matrixvalues(:,1)=matrixvalues(:,1)*(pi)/180;
    omega=2*pi/(lambda/1000);
    Structmat=load([directory, dia,'\',name,'_',int2str(lambda),'_Matrix','.mat']);
    TheMat=Structmat.TheMat;
    clear('Structmat');
    Structvec=load([directory, dia,'\',name,'_',int2str(lambda),'_Vector_','.mat']);
    TheV=Structvec.TheV;
    clear('Structvec');
    %[vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,i,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);%
    [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,TheV,TheMat,omega,epsilonv,muv,direction,pol,rsource);
      
    Escatsqrparallel=sum(vecplotparallel.*conj(vecplotparallel),2);%sum(abs(vecplotparallel).^2,2);
    Escatsqrperpendm=sum(vecplotperpedicular.*conj(vecplotperpedicular),2);    %sum(abs(vecplotperpedicular),2);
    matrixsimulationsMIE=[(pi/180)*[0:2:180]',(4*pi*Radius^2*Escatsqrperpendm),(4*pi*Radius^2*Escatsqrparallel),matrixvalues(1:20:1801,2),matrixvalues(1:20:1801,3)];
   
    
    prefactorperpend=sqrt((1/numberofpoints)*sum(matrixvalues(1:20:1801,2).^2,1));
    prefactorparallel=sqrt((1/numberofpoints)*sum(matrixvalues(1:20:1801,3).^2,1));
    
    errror(cont,1)=lambda;
    errror(cont,2)=sqrt((1/numberofpoints)*sum((((4*pi*Radius^2*Escatsqrperpendm)-matrixvalues(1:20:1801,2)).^2),1))/prefactorperpend;%The number 10 comes from the numberof points of the angle resolution.
    errror(cont,3)=sqrt((1/numberofpoints)*sum((((4*pi*Radius^2*Escatsqrparallel)-matrixvalues(1:20:1801,3)).^2),1))/prefactorparallel;%The number 10 comes from the numberof points of the angle resolution.
    
    
    
    save(['\\nanorfsrv\Users\Bernal\Simulations\31-Mar-2011\MIEFILESR0.009964\',int2str(lambda),'nmSimulation&MIE.txt'], 'matrixsimulationsMIE','-ascii');
    clear('matrixsimulationsMIE','Escatsqrparallel','Escatsqrperpendm');
    cont=cont+1;
    
    %lnR(logical(R02>1e-15))=integ(logical(R02>1e-15));
    
end
  save(['\\nanorfsrv\Users\Bernal\Simulations\31-Mar-2011\MIEFILESR0.009964\','errror.txt'], 'errror','-ascii');

  plot(errror(:,1:2));
  
  function [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,TheV,TheMat,omega,epsilonv,muv,direction,pol,rsource)

      thetapoints=(pi/180)*[0:180/(numberofpoints-1):180]';
      
      positionsphereparalel=[Radius*cos(thetapoints),0*thetapoints,Radius*sin(thetapoints)];
      positionsphereperpedicular=[Radius*cos(thetapoints),Radius*sin(thetapoints),0*thetapoints];
      
      vecplotparallel=FieldEfinder(1,positionsphereparalel,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,2,LineNodes,triangle,positions);
      vecplotperpedicular=FieldEfinder(1,positionsphereperpedicular,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,2,LineNodes,triangle,positions);
      
  end
end
