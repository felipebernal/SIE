function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
    MatPlot=runner(name)

omega=pi;
epsilonv=[1;16];
muv=[1;1];
direction=[1 0 0];
pol=[0 0 1];
rsource=[0 0 0];

numberoftilesMatrix=10;

i=1;
z=0;
numberoftiles=100;
xmin=-0.050;
xmax=0.050;
xstep=0.001;




directory='\\nanorfsrv\Users\Bernal\Simulations\';

if exist([directory, date])==0
    mkdir([directory, date]);
    [LineNodes,triangle,positions]= reader(name);
    TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
    save([directory, date,'\',name,'.mat'],'TheMat','LineNodes','triangle','positions');
    TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
     MatPlot= FieldPlotZplane(i,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);
else
    if exist([directory, date,'\',name,'.mat'])==0
    
        [LineNodes,triangle,positions]= reader(name);
        TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
        save([directory, date,'\',name,'.mat'],'TheMat','LineNodes','triangle','positions');
        TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
       MatPlot=FieldPlotZplane(i,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);
    
    else
        Struct=load([directory, date,'\',name,'.mat']);
        TheMat=Struct.TheMat;
        LineNodes=Struct.LineNodes;
        triangle=Struct.triangle;
        positions=Struct.positions;
        clear('Struct');
        TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
       MatPlot=FieldPlotZplane(i,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);
    end
end
    
     save([directory, date,'\',name,'DrawingMatrix.mat'],'MatPlot');
% 
% if matchecker==0
%     [LineNodes,triangle,positions]= reader;
%     TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,1);
%     save(name,'TheMat','LineNodes','triangle','positions');
%     TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
%     FieldPlotZplane(i,z,TheV,TheMat,omega,epsilonv,muv,direction,pol,rsource,100,LineNodes,triangle,positions);
%     matchecker=1;
% else
%     TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
%     FieldPlotZplane(i,z,TheV,TheMat,omega,epsilonv,muv,direction,pol,rsource,100,LineNodes,triangle,positions);
%     matchecker=1;
% end
    
    