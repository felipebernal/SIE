%%Quadrature based on the positions, weights and functions
%This function does the quadrature of the fnction "funcion" over the region
%made by the two triangles in the node list.
%it requires the positions in both triangles rpos1 and rpos2 which com from
%the function "BarycentGaussQuadPos(node,SPQ,LineNodes,triangle,positions)"



function quadvalTheVector= BaryQuadratureTheVector(omega,direction,pol,rsource,rpos1,rpos2,weigths,funcion,nodem,dimfun,rpt,LineNodes,triangle,positions,muv,epsilonv,sourceinout)

%in this case rpos1 and rpos2 are the r values that come from
%BarycentGaussQuadPos for a single node, that means 1 is the + and 2 is the
%- triangle.
%dimfun is the dimension of the answer given by the function funcion. i.e.
%if funcion gives a 3-vector dimfun=3, if it is an scalar function then
%dimfun=1.

%rpt is 7 Given that SPQ is a 7 position list of 3-vectors 
%rpt=7;



nodenmr=size(nodem,1);
weigthsrep=repmat(weigths,nodenmr,1);

%weigths=weigths(:,(ones(nodenmr,1)));
%weigths=weigths(:); % this one is just repmat(weigths,nodenmr,1)

Area1=LineNodes(nodem,6);
Area2=LineNodes(nodem,7);

%this is the way to make the sum of 7  3-vectors in a list that contains 
%a 9 times repetition of the 7 3-vectors ,
%reshape(sum(reshape(t,7,[]),1),9,[]) by the way it also works with
%2-vector

valTerm1=funcionFmult(omega,direction,pol,funcion,rpos1,rsource,nodem,rpt,1,LineNodes,triangle,positions,muv,epsilonv,sourceinout).*weigthsrep(:,ones(dimfun,1));
valTerm2=funcionFmult(omega,direction,pol,funcion,rpos2,rsource,nodem,rpt,2,LineNodes,triangle,positions,muv,epsilonv,sourceinout).*weigthsrep(:,ones(dimfun,1));
quadvalTheVector=...
   Area1.* reshape(sum(reshape(valTerm1,rpt,[]),1),nodenmr,[])+...
  Area2.*reshape(sum(reshape(valTerm2,rpt,[]),1),nodenmr,[]);

