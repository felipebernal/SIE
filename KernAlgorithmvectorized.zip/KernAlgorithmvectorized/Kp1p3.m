% This function finds the value of the integral K^{1}_{3} from the paper
% PIER 63, 243-278, 2006

function valKp1p3=Kp1p3(r,p1,p2,p3)

numr=size(r,1);

b=cross((p2-p1),(p3-p1));
bnorm=sqrt(sum(b.^2,2));
n=b./bnorm(:,ones(3,1));

p2p1norm=sqrt(sum((p2-p1).^2,2));
m1=cross((p2-p1)./p2p1norm(:,ones(3,1)),n,2);

p3p2norm=sqrt(sum((p3-p2).^2,2));
m2=cross((p3-p2)./p3p2norm(:,ones(3,1)),n,2);

p1p3norm=sqrt(sum((p1-p3).^2,2));
m3=cross((p1-p3)./p1p3norm(:,ones(3,1)),n,2);

%dP1 boundary of the triangle defined by the pa and pb nodes
pa1=p1;
pb1=p2;

%vectorized inner product sum(a1.*a2,2) for a list of vectors
%dp2
pa2=p2;
pb2=p3;

%dP3
pa3=p3;
pb3=p1;

%The integral is
h=Hh(r,p1,p2,p3);

FpT1=ILp1(r,pa1,pb1);
FpT2=ILp1(r,pa2,pb2);
FpT3=ILp1(r,pa3,pb3);
SpT=ISm1(r,p1,p2,p3);

valKp1p3=zeros(numr,3);

firstpart=-h(:,ones(3,1)).*n.*SpT(:,ones(3,1)); 
secondpart=m1.*FpT1(:,ones(3,1))+m2.*FpT2(:,ones(3,1))+m3.*FpT3(:,ones(3,1));

combinedpart=firstpart+secondpart; 

valKp1p3(logical(h.^2<=1e-15),:)=secondpart(logical(h.^2<=1e-15),:);

valKp1p3(logical(h.^2>1e-15),:)=combinedpart(logical(h.^2>1e-15),:);

%Checked !!
