function doubinteTrianK = Kmnismth(k,mu,nodem,noden,LineNodes,triangle,positions)
% This function makes the double integration over the triangles m and n of
% the green's function. 
%c=299792458;

barycentryctable;

[rtrim1, rtrim2]=BarycentGaussQuadPos(nodem,SPQ,LineNodes,triangle,positions);
%This function findss the positions for the plus 1 and minus 2 triangles
%for the list of nodes gven in nodem.

[rtrin1, rtrin2]=BarycentGaussQuadPos(noden,SPQ,LineNodes,triangle,positions);
%This function findss the positions for the plus 1 and minus 2 triangles
%for the list of nodes gven in noden.

%The Dmnismth value is composed by two integrals, each one of which is
%calculated over a node region composed by two triangles.
%Given that the integration can only be done for single triangles in the
%BaryDoubleTriQuadrature, then these two integrals are divided in 4
%different terms each. Each one with ++ +- -+ --

%%Version zero
% Int1term1=BaryDoubleTriQuadrature(1,1,rtrim1,rtrin1,weigths,@funKmniterm,nodem,noden,k,rpt,LineNodes,triangle,positions);
% Int1term2=BaryDoubleTriQuadrature(1,2,rtrim1,rtrin2,weigths,@funKmniterm,nodem,noden,k,rpt,LineNodes,triangle,positions);
% Int1term3=BaryDoubleTriQuadrature(2,1,rtrim2,rtrin1,weigths,@funKmniterm,nodem,noden,k,rpt,LineNodes,triangle,positions);
% Int1term4=BaryDoubleTriQuadrature(2,2,rtrim2,rtrin2,weigths,@funKmniterm,nodem,noden,k,rpt,LineNodes,triangle,positions);
% 
% 
% doubinteTrianK=(Int1term1+Int1term2+Int1term3+Int1term4);

%%Version one

doubinteTrianK=(BaryDoubleTriQuadrature(1,1,rtrim1,rtrin1,weigths,@funKmniterm,nodem,noden,k,rpt,LineNodes,triangle,positions)+...
                BaryDoubleTriQuadrature(1,2,rtrim1,rtrin2,weigths,@funKmniterm,nodem,noden,k,rpt,LineNodes,triangle,positions)+...
                BaryDoubleTriQuadrature(2,1,rtrim2,rtrin1,weigths,@funKmniterm,nodem,noden,k,rpt,LineNodes,triangle,positions)+...
                BaryDoubleTriQuadrature(2,2,rtrim2,rtrin2,weigths,@funKmniterm,nodem,noden,k,rpt,LineNodes,triangle,positions));
%Checked!