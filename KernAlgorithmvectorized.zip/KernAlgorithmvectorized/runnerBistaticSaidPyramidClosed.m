function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]=
    ...[sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
    ...   [Totalelectricdipole,Totalmagneticdipole,alpha,NeeONhh,fvaltol,moments]=runnerBistatic(Radius,name)
    ...    [Totalelectricdipole,Totalmagneticdipole,Dipoles,Quadrupoles,alpha]
    [Dipoles1,Quadrupoles1,alpha]=runnerBistaticSaidPyramidClosed

Radius=100;
name='SaidPyramidClosed';
%omega=2*pi/(1550/1000); %BORIS probe

%omega=2*pi/(10000/1000); %1microns wavelength
%omega=0.10;

%omega=2*pi/(10000/1000); %Minisphere 10 nm
%omega=2*pi/(1507/1000); %SplitRing
%omega=2*pi/(1528/1000); %SplitRingRefined
%omega=2*pi/(1544.5/1000); %SplitRingcurvedrefined
omega=2*pi/(625/1000); %SaidPyramid

%omega=2*pi/(2*pi*1000/1000); %test

%omega=2*pi/(62500/1000); %DSRR
%omega=2*pi/(16500/1000); %DGSRR px electric resonance
%omega=2*pi/(25000/1000); %DGSRR py resonance
%omega=2*pi/(23250/1000); %DGSRR  resonance

%omega=2*pi/(18000/1000); %Omega
%omega=2*pi/(2500/1000); %CasimirOmega

%omega=2*pi/(15404/1000); %Omega1
%omega=2*pi/(16803/1000); %Omega2
%omega=2*pi/(16063/1000); %Omega3
%omega=2*pi/(16411/1000); %Omega4
%omega=2*pi/(15475/1000); %Omega5
%omega=2*pi/(15559/1000); %OmegaSmothedMedium

lambda=(2*pi/omega)*1000;


%omega=0.1;
c=1;
k=omega/c;
%epsilonv=[1;12];

%epsilonv=[1;Aluminium(1000*(2*pi)/omega)]; %This one suposes that a=1micron (the unit of lenght)BORISPROBE

epsilonv=[1;Aluminium(1000*(2*pi)/omega)]; %This one suposes that a=1micron (the unit of lenght)
%epsilonv=[1;2];
muv=[1;1];
%muv=[1;1+100i];

direction=[0 -1 0];
pol=[1 0 0];

% direction=[1 0 0];
% pol=[0 1 0];


rsource=[0 0 0];
sourceinout=1;

%Radius=1.00000;
numberofpoints=100;
numberoftilesMatrix=5;

icont=1;
z=0;
numberoftiles=10;
xmin=-1;
xmax=1;
xstep=0.1;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date; %This is done so that if the simulation takes more than a day then you don't have problems saving the data.
%dia='28-Oct-2011';
if exist([directory, dia])==0
    mkdir([directory, dia]);
    [LineNodes,triangle,positions]= reader(name);
    TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
    save([directory, dia,'\',name,'.mat'],'TheMat','LineNodes','triangle','positions');
    TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
    [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions,sourceinout);
else
    if exist([directory, dia,'\',name,'.mat'])==0
        
        [LineNodes,triangle,positions]= reader(name);
        TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
        save([directory, dia,'\',name,'.mat'],'TheMat','LineNodes','triangle','positions');
        TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
        [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions,sourceinout);
        
    else
        Struct=load([directory, dia,'\',name,'.mat']);
        TheMat=Struct.TheMat;
        % LineNodes=Struct.LineNodes;
        %triangle=Struct.triangle;
        %positions=Struct.positions;
        [LineNodes,triangle,positions]= reader(name);
        
        clear('Struct');
        
        
        TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
        [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions,sourceinout);
    end
end



Escatsqrparallel=sum(vecplotparallel.*conj(vecplotparallel),2);%sum(abs(vecplotparallel).^2,2);
sigmascatparallel=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2*Escatsqrparallel];

Escatsqrperpendm=sum(vecplotperpedicular.*conj(vecplotperpedicular),2);    %sum(abs(vecplotperpedicular),2);
sigmascatperpend=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* Escatsqrperpendm];

% [dipoles1,Quadrupoles1]=currents2MomentsVSH(k,epsilonv,muv,TheMat,TheV,name)%%ERASE!!! <--------------------------------------
%    valMomentsIntVSH1=MomentsIntVSH1(1,1,k,node,LineNodes,triangle,positions);%%ERASE!!! <--------------------------------------

%save([directory, dia,'\',name,'DrawingparallelperpendMatrix.mat'],'sigmascatparallel','sigmascatperpend');

%polar(sigmascatparallel(:,1),sigmascatparallel(:,2));
%polar(sigmascatperpend(:,1),sigmascatperpend(:,2));
figure(1);
polar([sigmascatparallel(:,1);NaN;sigmascatperpend(:,1)],[sigmascatparallel(:,2);NaN;sigmascatperpend(:,2)]);
figure(2);
polar(sigmascatparallel(:,1),sigmascatparallel(:,2));
figure(3)
polar(sigmascatperpend(:,1),sigmascatperpend(:,2));
% [Totalelectricdipole,Totalmagneticdipole]=effectivedipolecalculator(k,epsilonv,muv,TheMat,TheV,name);
%       abtotma=abs(Totalmagneticdipole);
%    abtotel=abs(Totalelectricdipole);
%    abtot=[abtotel;abtotma];
%     dipotot=[Totalelectricdipole;Totalmagneticdipole];
%figure(4)
%quiver3([0;0],[0;0],[0;0],abtot(:,1),abtot(:,2),abtot(:,3))
%           [alpha,NeeONhh,fvaltol]=PolarizabilityTensorCalculator(k,epsilonv,muv,TheMat,name);



savefiles=1;
[Dipoles1,Quadrupoles1]=VectorSphericalHarmonicsMultipoleRetrieval(k,epsilonv,muv,TheMat,TheV,direction,pol,rsource,name,sourceinout);

alpha=PolarizabilityTensorCalculator(k,epsilonv,muv,TheMat,name);
%alpha=0;

if savefiles==0
    
else
    alphaReal=real(alpha);
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\PolarizabilityReal',name,'_',num2str(lambda) ,'.txt'], 'alphaReal','-ascii');
    alphaIm=imag(alpha);
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\Polarizability',name,'_',num2str(lambda) ,'.txt'], 'alphaIm','-ascii');
end   
    
    
    
    
    function [dipoles,Quadrupoles]=VectorSphericalHarmonicsMultipoleRetrieval(k,epsilonv,muv,TheMat,TheV,direction,pol,rsource,name,sourceinout)
    shiftedcentersphere=[0,-0.05,0];
    %shiftedcentersphere=[0,0.105,0];
    %Medium radius is good to find dipoles without numerical noise
    %Short radius is better to find quadrupoles.
    
    Radius=10000*2*pi/k; %This distance works very well for the mcronedsized splitrings
    %Radius=100*2*pi/k;
    c=1;
    Zo=sqrt(muv(1)/epsilonv(1));
    omega=k*c;
    numberofpoints=10;
    [LineNodes,triangle,positions]= reader(name);
    
    FemiusCode=1;
    
    if FemiusCode==1
        
        
        Nth=20;
        Nphi=20;
        theta=[1:Nth]/(Nth+1)*pi;
        phi=[1:Nphi]/Nphi*2*pi;
        [theta phi]=meshgrid(theta,phi);
        thetalist=reshape(theta,1,prod(size(theta)));
        
        philist=reshape(phi,size(thetalist));
        
        positionsphere=[Radius*sin(thetalist.').*cos(philist.'),Radius*sin(thetalist.').*sin(philist.'),Radius*cos(thetalist.')]+repmat(shiftedcentersphere,size(thetalist,2),1);
        valE=FieldEfinder(1,'scatt','far',positionsphere,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
        size(thetalist);
        size(philist);
        size(valE);
        
        %for p=1:length(thetalist),
        %    Efield.x(p)=valE(p,1); Efield.y(p)=valE(p,2); Efield.z(p)=valE(p,3);
        %end
        
        Efield.x=valE(:,1); Efield.y=valE(:,2); Efield.z=valE(:,3);
        
        [p m]=retrievedipoleFemius(Efield,k,Radius,thetalist,philist);
        
        dipoles=[(4*pi)*p.';(4*pi)*m.'];
        Quadrupoles=0;
        
        
        
        
        
    else
        
        
        
        
        
        
        thetapoints=[0:pi/(numberofpoints-1):pi]';
        phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
        
        alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
        allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
        positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
        
        
        valE=FieldEfinder(1,'scatt','far',positionsphere,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
        valH=FieldHfinder(1,'scatt','far',positionsphere,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
        
        
        %px=-1i*(sqrt(3*pi)/(c*k^3))*(aE(1,1)-aE(1,-1));
        %py=(sqrt(3*pi)/(c*k^3))*(aE(1,1)+aE(1,-1));
        %pz=(1i*sqrt(6*pi)/(c*k^3))*aE(1,0);
        
        px=-sqrt(2/3)*1i*(sqrt(3*pi)/(c*k^3))*(aE(1,1)-aE(1,-1));
        py=(sqrt(3*pi)/(c*k^3))*(aE(1,1)+aE(1,-1));
        pz=sqrt(27/(10*pi))*(1i*sqrt(6*pi)/(c*k^3))*aE(1,0);
        
        
        %mx=c*1i*(sqrt(3*pi)/(c*k^3))*(aM(1,1)-aM(1,-1));
        %my=-c*(sqrt(3*pi)/(c*k^3))*(aM(1,1)+aM(1,-1));
        %mz=-c*(1i*sqrt(6*pi)/(c*k^3))*aM(1,0);
        
        
        mx=sqrt(2/3)*c*1i*(sqrt(3*pi)/(c*k^3))*(aM(1,1)-aM(1,-1));
        my=-c*(sqrt(3*pi)/(c*k^3))*(aM(1,1)+aM(1,-1));
        mz=-sqrt(27/(10*pi))*c*(1i*sqrt(6*pi)/(c*k^3))*aM(1,0);
        
        dipoles=[px;py;pz;mx;my;mz];
        
        
        prefact1=6*1i*sqrt(5*pi)/(c*k^4);
        prefact2=1i*sqrt(30*pi)/(c*k^4);
        prefact3=6*sqrt(5*pi)/(c*k^4);
        Q11=prefact1*(aE(2,2)+aE(2,-2))-2*prefact2*aE(2,0);
        Q22=-prefact1*(aE(2,2)+aE(2,-2))-2*prefact2*aE(2,0);
        Q33=4*prefact2*aE(2,0);
        Q12=-prefact3*(aE(2,2)-aE(2,-2));
        Q13=-prefact1*(aE(2,1)-aE(2,-1));
        Q23=prefact3*(aE(2,1)+aE(2,-1));
        
        Quadrupoles=[Q11,Q12,Q13;Q12,Q22,Q23;Q13,Q23,Q33];
        
        
        
    end
    
        function valaE=aE(l,m)
            valaE=(-k/sqrt(l*(l+1))).*(1/Zo).*(1/(h1l(l,k*Radius))).*(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*sum(sin(alltheta).*conj( Ylm(l,m,alltheta,allphi) ).*(sum(positionsphere.*valE,2)),1);
        end
    
        function valaM=aM(l,m)
            valaM=(k/sqrt(l*(l+1))).*(1/(h1l(l,k*Radius))).*(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*sum(sin(alltheta).*conj( Ylm(l,m,alltheta,allphi) ).*(sum(positionsphere.*valH,2)),1);
        end
    
    
    
    end
    % function valYlm=Ylm(l,m,theta,phi)
    % LegeCosthetaLM=legendre(l,cos(theta));
    % if m>=0
    %
    % valYlm=sqrt(((2*l+1)/(4*pi))*factorial(l-m)/factorial(l+m)).*LegeCosthetaLM(m+1,:)'.*exp(1i*m*phi);
    % else
    %    absm=abs(m);
    %  valYlm=(-1)^(absm)*conj(sqrt(((2*l+1)/(4*pi))*factorial(l-absm)/factorial(l+absm)).*LegeCosthetaLM(absm+1,:)'.*exp(1i*absm*phi));
    % end
    % end
    
    % function valYlm=Ylm(l,m,theta,phi)%This is actually the conjugate of Ylm not Ylm
    % LegeCosthetaLM=legendre(l,cos(theta));
    % if m>=0
    % valYlm=conj(sqrt(((2*l+1)/(4*pi))*factorial(l-m)/factorial(l+m)).*LegeCosthetaLM(m,:)'.*exp(1i*m*phi));
    % else
    %    absm=abs(m);
    %  valYlm=conj((-1)^(absm)*conj(sqrt(((2*l+1)/(4*pi))*factorial(l-absm)/factorial(l+absm)).*LegeCosthetaLM(absm,:)'.*exp(1i*absm*phi)));
    % end
    % end
    %
    %
    
    function valYlm=Ylm(l,m,theta,phi)
    LegeCosthetaLM=legendre(l,cos(theta));
    if m>=0&&m<=l
        valYlm=sqrt(((2*l+1)/(4*pi))*factorial(l-m)/factorial(l+m)).*LegeCosthetaLM(m+1,:)'.*exp(1i*m*phi);
    elseif m<0&&m<=l
        absm=abs(m);
        valYlm=(-1)^(absm)*conj(sqrt(((2*l+1)/(4*pi))*factorial(l-absm)/factorial(l+absm)).*LegeCosthetaLM(absm+1,:)'.*exp(1i*absm*phi));
    elseif m>l
        valYlm=zeros(size(theta,1),1);
    end
    end
    
    
    
    
    
    
    
    
    function valsphehank=h1l(n,x)
    valsphehank=sqrt(pi./(2*x)).* besselh(n+1/2,1,x);
    end
   


% function ...[alphafinal,NeeONhh,fvaltol]=PolarizabilityTensorCalculator(k,epsilonv,muv,TheMat,name)
%             alphafinal=PolarizabilityTensorCalculator(k,epsilonv,muv,TheMat,name)
% %This function retrieves the polarizability tensor by doing six different
% %calculations over the system then it retrieves the dipole moments and we
% %know that the matrix p made out the dipole moment vectores in columns of 6
% %simulations so 6 coulums multiplied by the inverse of the matrix E made by
% %the six different input fields gives alpha which is the polarizability
% %matrix.
% % In other words b dot inv(E)=alpha.
% 
% sourceinout=1;
% c=1;
% omega=k*c;
% 
% directory='\\nanorfsrv\Users\Bernal\Simulations\';
% dia=date;
% 
% [LineNodes,triangle,positions]= reader(name);
% rsource=[0,0,0];
% 
% %
% positioncenterstructure=[0,0,0];
% %%%With only 6 diferent vectors retrieval of alpha
% 
% directionmatrix=[1 0 0;0 1 0;0 0 1];
% 
% polarizationmatrix=[0 1 0;0 0 1;1 0 0;0 0 1;1 0 0;0 1 0];
% %This was the original not useful for counterpropagting fields
% %orderer=[1,1; 1,2; 2,3; 2,4; 3,5; 3,6];
% orderer=[1,1; 1,2; 2,3; 2,3; 3,5; 3,6];
% 
% sizeN=6;
% 
% 
% %%%With many different vectors from many different angle retieval from
% %%%alpha:
% % rpt=4;
% % theta=linspace(0, pi, rpt)';
% % phi=linspace(0, pi, rpt)';
% % 
% % theta=repmat(theta,rpt,1);
% % phi=VECrpt1D(phi,rpt);
% % 
% % directionmatrixHalf=[cos(phi).*sin(theta), sin(phi).*sin(theta), -cos(theta)];
% % polarizationmatrix1=[-sin(phi),  cos(phi) 0*sin(theta)];
% % polarizationmatrix2=[cos(phi).*cos(theta),  sin(phi).*cos(theta), sin(theta)];
% % 
% % directionmatrix=repmat(directionmatrixHalf,2,1);
% % polarizationmatrix=[polarizationmatrix1;polarizationmatrix2];
% % sizeN=size(directionmatrix,1);
% 
% 
% MatP=zeros(6,sizeN);
% MatE=zeros(6,sizeN);
% for dircont=1:sizeN
%     
%     direction=directionmatrix(orderer(dircont,1),:);
%     pol=polarizationmatrix(orderer(dircont,2),:);
%     %direction=directionmatrix(dircont,:);
%     %pol=polarizationmatrix(dircont,:);
%     
%     %%%%%Alpha found with the currents dipole calculator:
% %     TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
% %     [Totalelectricdipole,Totalmagneticdipole]=effectivedipolecalculator(k,epsilonv,muv,TheMat,TheV,name);
% %     E=PlaneWaveE(k,direction,pol,positioncenterstructure);
% %     H=PlaneWaveH(k,direction,pol,positioncenterstructure);
% %     MatP(:,dircont)=[Totalelectricdipole,Totalmagneticdipole].';
% %     MatE(:,dircont)=[E,H].';   
%     
%     %%%%%Alpha found with the projection of the fields in vector spherical harmonics:
%     
% %%%%%%%%%%%%%%Here we have the change into only counterpropagating beams
% %     if dircont<=3
% %     CounterpropE=@(om,di,po,reval,rso) (1/2)*(PlaneWaveE(om,di,po,reval,rso)+PlaneWaveE(om,-1*di,po,reval,rso));
% %     CounterpropH=@(om,di,po,reval,rso) (1/2)*(PlaneWaveH(om,di,po,reval,rso)+PlaneWaveH(om,-1*di,po,reval,rso));
% %     else
% %        CounterpropE=@(om,di,po,reval,rso) (1/2)*(PlaneWaveE(om,di,po,reval,rso)+PlaneWaveE(om,-1*di,-1*po,reval,rso));
% %     CounterpropH=@(om,di,po,reval,rso) (1/2)*(PlaneWaveH(om,di,po,reval,rso)+PlaneWaveH(om,-1*di,-1*po,reval,rso)); 
% %     end
% %     
%     
%     if dircont<=3
%     CounterpropE=@(om,di,po,reval,rso,m,ep,souinout) (1/2)*(PlaneWaveE(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveE(om,-1*di,po,reval,rso,m,ep,souinout));
%     CounterpropH=@(om,di,po,reval,rso,m,ep,souinout) (1/2)*(PlaneWaveH(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveH(om,-1*di,po,reval,rso,m,ep,souinout));
%     else
%        CounterpropE=@(om,di,po,reval,rso,m,ep,souinout) (1/2)*(PlaneWaveE(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveE(om,-1*di,-1*po,reval,rso,m,ep,souinout));
%     CounterpropH=@(om,di,po,reval,rso,m,ep,souinout) (1/2)*(PlaneWaveH(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveH(om,-1*di,-1*po,reval,rso,m,ep,souinout)); 
%     end
%     
%         
%     %TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
%     TheV=TheVectorFiller(omega,direction,pol,rsource,CounterpropE,CounterpropH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
%     
%     [Dipoles,Quadrupoles]=VectorSphericalHarmonicsMultipoleRetrieval(k,epsilonv,muv,TheMat,TheV,direction,pol,rsource,name,sourceinout);
%     Totalelectricdipole=Dipoles(1:3);
%     Totalmagneticdipole=Dipoles(4:6);
%     
%     %E=PlaneWaveE(k,direction,pol,positioncenterstructure);
%     %H=PlaneWaveH(k,direction,pol,positioncenterstructure);
%     
%     E=CounterpropE(k,direction,pol,positioncenterstructure,0*positioncenterstructure,0,0,0);%Here we put 0 toignore the values for muv epsilonv and sourceinout
%     H=CounterpropH(k,direction,pol,positioncenterstructure,0*positioncenterstructure,0,0,0);%Here we put 0 toignore the values for muv epsilonv and sourceinout
%     
%     
%     
%     MatP(:,dircont)=[Totalelectricdipole;Totalmagneticdipole];
%     MatE(:,dircont)=[E,H].';   
% end
% 
% alpha=MatP/MatE; %This is the same as MatP*inv(MatE)
% 
% 
% if 1<-1
% %%%%Here we have another solution for alpha which preconditions the stuff
% minimizefunct= @(x) OptiAlpha(x,MatP,MatE);
% [Xmin,fvaltol]=fminsearch(minimizefunct,alpha(:),optimset('PlotFcns',@optimplotfval,'TolX',1e-8));
% %[Xmin,fvaltol]=fminsearch(minimizefunct,alpha(:));
% alphafinal=zeros(6,6);
% alphafinal=etafromx(Xmin);
% %NeeONhh=norm(trace(alphafinal(1:3,1:3))/trace(alphafinal(4:6,4:6)));
% else
%     
%    alphafinal=alpha; 
% end
% 
% end
% 
% function residuous=OptiAlpha(x,P,E)
% eta=etafromx(x);
% %residuous=norm((P-eta*E)'*(P-eta*E));
%  %residuous=norm(sum(sum(conj((eta*E-P)).'*(eta*E-P),2),1))/norm(sum(sum(conj(eta)'*eta,2),1));
%  residuous=sum(sum(abs(eta*E-P),2),1)./sum(sum(abs(P),2),1);
% end
% 
% function eta=etafromx(x)
% eta=zeros(6,6);
% % %version one of eta
% % eta(1,1)=x(1);
% % eta(2,1)=x(2);
% % eta(3,1)=x(3);
% % eta(4,1)=x(4);
% % eta(5,1)=x(5);
% % eta(6,1)=x(6);
% % 
% % eta(1,2)=x(7);
% % eta(2,2)=x(8);
% % eta(3,2)=x(9);
% % eta(4,2)=x(10);
% % eta(5,2)=x(11);
% % eta(6,2)=x(12);
% % 
% % 
% % eta(1,3)=x(13);
% % eta(2,3)=x(14);
% % eta(3,3)=x(15);
% % eta(4,3)=x(16);
% % eta(5,3)=x(17);
% % eta(6,3)=x(18);
% % 
% % eta(1,4)=x(19);
% % eta(2,4)=x(20);
% % eta(3,4)=x(21);
% % eta(4,4)=x(22);
% % eta(5,4)=x(23);
% % eta(6,4)=x(24);
% % 
% % eta(1,5)=x(25);
% % eta(2,5)=x(26);
% % eta(3,5)=x(27);
% % eta(4,5)=x(28);
% % eta(5,5)=x(29);
% % eta(6,5)=x(30);
% % 
% % eta(1,6)=x(31);
% % eta(2,6)=x(32);
% % eta(3,6)=x(33);
% % eta(4,6)=x(34);
% % eta(5,6)=x(35);
% % eta(6,6)=x(36);
% % 
% % %%%%%%
% 
% % %version two of eta, Neh and Nhe are
% %the minus transpose of the other
% % eta(1,1)=x(1);
% % eta(2,1)=x(2);
% % eta(3,1)=x(3);
% % eta(4,1)=x(4);
% % eta(5,1)=x(5);
% % eta(6,1)=x(6);
% % 
% % eta(1,2)=x(2);
% % eta(2,2)=x(8);
% % eta(3,2)=x(9);
% % eta(4,2)=x(10);
% % eta(5,2)=x(11);
% % eta(6,2)=x(12);
% % 
% % 
% % eta(1,3)=x(3);
% % eta(2,3)=x(9);
% % eta(3,3)=x(15);
% % eta(4,3)=x(16);
% % eta(5,3)=x(17);
% % eta(6,3)=x(18);
% % 
% % eta(1,4)=-x(4);
% % eta(2,4)=-x(10);
% % eta(3,4)=-x(16);
% % eta(4,4)=x(22);
% % eta(5,4)=x(23);
% % eta(6,4)=x(24);
% % 
% % eta(1,5)=-x(5);
% % eta(2,5)=-x(11);
% % eta(3,5)=-x(17);
% % eta(4,5)=x(23);
% % eta(5,5)=x(29);
% % eta(6,5)=x(30);
% % 
% % eta(1,6)=-x(6);
% % eta(2,6)=-x(12);
% % eta(3,6)=-x(18);
% % eta(4,6)=x(24);
% % eta(5,6)=x(30);
% % eta(6,6)=x(36);
% % 
% % %%%%%%
% 
% % %version three of eta...where the nee and Nhh are just diagonal matrices,Neh and Nhe are
% %the minus transpose of the other
% % eta(1,1)=x(1);
% % eta(2,1)=0*x(2);
% % eta(3,1)=0*x(3);
% % eta(4,1)=x(4);
% % eta(5,1)=x(5);
% % eta(6,1)=x(6);
% % 
% % eta(1,2)=0*x(2);
% % eta(2,2)=x(8);
% % eta(3,2)=0*x(9);
% % eta(4,2)=x(10);
% % eta(5,2)=x(11);
% % eta(6,2)=x(12);
% % 
% % 
% % eta(1,3)=0*x(3);
% % eta(2,3)=0*x(9);
% % eta(3,3)=x(15);
% % eta(4,3)=x(16);
% % eta(5,3)=x(17);
% % eta(6,3)=x(18);
% % 
% % eta(1,4)=-x(4);
% % eta(2,4)=-x(10);
% % eta(3,4)=-x(16);
% % eta(4,4)=x(22);
% % eta(5,4)=0*x(23);
% % eta(6,4)=0*x(24);
% % 
% % eta(1,5)=-x(5);
% % eta(2,5)=-x(11);
% % eta(3,5)=-x(17);
% % eta(4,5)=0*x(23);
% % eta(5,5)=x(29);
% % eta(6,5)=0*x(30);
% % 
% % eta(1,6)=-x(6);
% % eta(2,6)=-x(12);
% % eta(3,6)=-x(18);
% % eta(4,6)=0*x(24);
% % eta(5,6)=0*x(30);
% % eta(6,6)=x(36);
% % %%%%%%
% 
% %version foure of eta where Nee and Nhh are symetric and Neh and Nhe are
% %the minus transpose of the other
% eta(1,1)=x(1);
% eta(2,1)=x(2);
% eta(3,1)=x(3);
% eta(4,1)=x(4);
% eta(5,1)=x(5);
% eta(6,1)=x(6);
% 
% eta(1,2)=x(2);
% eta(2,2)=x(8);
% eta(3,2)=x(9);
% eta(4,2)=x(10);
% eta(5,2)=x(11);
% eta(6,2)=x(12);
% 
% 
% eta(1,3)=x(3);
% eta(2,3)=x(9);
% eta(3,3)=x(15);
% eta(4,3)=x(16);
% eta(5,3)=x(17);
% eta(6,3)=x(18);
% 
% eta(1,4)=-x(4);
% eta(2,4)=-x(10);
% eta(3,4)=-x(16);
% eta(4,4)=x(22);
% eta(5,4)=x(23);
% eta(6,4)=x(24);
% 
% eta(1,5)=-x(5);
% eta(2,5)=-x(11);
% eta(3,5)=-x(17);
% eta(4,5)=x(23);
% eta(5,5)=x(29);
% eta(6,5)=x(30);
% 
% eta(1,6)=-x(6);
% eta(2,6)=-x(12);
% eta(3,6)=-x(18);
% eta(4,6)=x(24);
% eta(5,6)=x(30);
% eta(6,6)=x(36);
% 
% %%%%%%
% 
% end


    
end

