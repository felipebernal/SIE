function valfuncionF = funcionFmult(omega,direction,pol,funcionEorH, rtri,rsource,nodetri,rpt,pm,LineNodes,triangle,positions,muv,epsilonv,sourceinout)

nodetrimod=VECrpt1D(nodetri,rpt);
valfuncionF=sum(RWGfunction(rtri,nodetrimod,rpt,pm,LineNodes,triangle,positions).*funcionEorH(omega,direction,pol,rtri,rsource,muv,epsilonv,sourceinout),2);