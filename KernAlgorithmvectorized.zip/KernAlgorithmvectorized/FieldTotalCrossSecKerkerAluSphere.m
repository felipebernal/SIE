function vecplot=FieldTotalCrossSecKerkerAluSphere

Radius=10;
numberofpoints=10;
epsilonv=[1;0.142857];
muv=[1;3];
direction=[0 1 0];
pol=[1 0 0];
rsource=[0 0 0];
name='minisphererefinedIII';
[LineNodes,triangle,positions]= reader(name);

thetapoints=[0:pi/(numberofpoints-1):pi]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';

alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];

dia='13-Feb-2012';
minlam=100;
maxlam=1000;
deltalam=50;

vecplot=zeros(size([minlam:deltalam:maxlam]',1),1);
cont=1;

for c=minlam:deltalam:maxlam
    matrix=load(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\',name,'_',int2str(c),'_Matrix','.mat']);
    TheMat=matrix.TheMat;
    vector=load(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\',name,'_',int2str(c),'_Vector_','.mat']);
    TheV=vector.TheV;
   % clear('matrix','vector');
    
    valE=FieldEfinder(1,'scatt','far',positionsphere,(2*pi/(c/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions);
    vecplot(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);
    cont=cont+1;
end
a=[[minlam:deltalam:maxlam]',vecplot];
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\TotalScattCrossSec.txt'], 'a','-ascii');

plot([minlam:deltalam:maxlam]',vecplot);
end