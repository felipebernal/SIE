% this function is the sum of the terms in the first integral for
% finding the Total electric or magnetic field.

function valEHInt1NTSMTH= EHInt1NTSMTH(k,rtoeval,node,LineNodes,triangle,positions)

valEHInt1NTSMTH= EHInt1_1NTSMTH(k,rtoeval,node,LineNodes,triangle,positions)+EHInt1_2NTSMTH(k,rtoeval,node,LineNodes,triangle,positions);


