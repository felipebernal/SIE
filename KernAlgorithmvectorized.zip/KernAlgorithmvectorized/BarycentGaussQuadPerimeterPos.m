%Points in the Barycentric reference frame for doing the quadrature. 
%r=beta_1*v_1+beta_2*v_2+beta_3*v_3
function [rposPer1 , rposPer2,Lengths1,Lengths2] = BarycentGaussQuadPerimeterPos(node,LineNodes,triangle,positions)

tri1=LineNodes(node,1);
tri2=LineNodes(node,2);

p1p=positions(triangle(tri1,1),:);
p2p=positions(triangle(tri1,2),:);
p3p=positions(triangle(tri1,3),:);

dT1a=(p2p-p1p);
dT1b=(p3p-p2p);
dT1c=(p1p-p3p);

rposPer1a=(0.5-1/sqrt(3))*dT1a;
rposPer1a2=(0.5+1/sqrt(3))*dT1a;

rposPer1b=(0.5-1/sqrt(3))*dT1b;
rposPer1b2=(0.5+1/sqrt(3))*dT1b;

rposPer1c=(0.5-1/sqrt(3))*dT1c;
rposPer1c2=(0.5+1/sqrt(3))*dT1c;

rposPer1x=[rposPer1a(:,1),rposPer1a2(:,1),rposPer1b(:,1),rposPer1b2(:,1),rposPer1c(:,1),rposPer1c2(:,1)].';
rposPer1y=[rposPer1a(:,2),rposPer1a2(:,2),rposPer1b(:,2),rposPer1b2(:,2),rposPer1c(:,2),rposPer1c2(:,2)].';
rposPer1z=[rposPer1a(:,3),rposPer1a2(:,3),rposPer1b(:,3),rposPer1b2(:,3),rposPer1c(:,3),rposPer1c2(:,3)].';



rposPer1=[rposPer1x(:),rposPer1y(:),rposPer1z(:)];


p1m=positions(triangle(tri2,1),:);
p2m=positions(triangle(tri2,2),:);
p3m=positions(triangle(tri2,3),:);

dT2a=(p2m-p1m);
dT2b=(p3m-p2m);
dT2c=(p1m-p3m);

rposPer2a=(0.5-1/sqrt(3))*dT2a;
rposPer2a2=(0.5+1/sqrt(3))*dT2a;

rposPer2b=(0.5-1/sqrt(3))*dT2b;
rposPer2b2=(0.5+1/sqrt(3))*dT2b;

rposPer2c=(0.5-1/sqrt(3))*dT2c;
rposPer2c2=(0.5+1/sqrt(3))*dT2c;

rposPer2x=[rposPer2a(:,1),rposPer2a2(:,1),rposPer2b(:,1),rposPer2b2(:,1),rposPer2c(:,1),rposPer2c2(:,1)].';
rposPer2y=[rposPer2a(:,2),rposPer2a2(:,2),rposPer2b(:,2),rposPer2b2(:,2),rposPer2c(:,2),rposPer2c2(:,2)].';
rposPer2z=[rposPer2a(:,3),rposPer2a2(:,3),rposPer2b(:,3),rposPer2b2(:,3),rposPer2c(:,3),rposPer2c2(:,3)].';


rposPer2=[rposPer2x(:),rposPer2y(:),rposPer2z(:)];


Lengths1a=sqrt(sum(dT1a.^2,2));
Lengths1b=sqrt(sum(dT1b.^2,2));
Lengths1c=sqrt(sum(dT1c.^2,2));
lengthsperm1=[Lengths1a,Lengths1a,Lengths1b,Lengths1b,Lengths1c,Lengths1c].';
Lengths1=lengthsperm1(:);



Lengths2a=sqrt(sum(dT2a.^2,2));
Lengths2b=sqrt(sum(dT2b.^2,2));
Lengths2c=sqrt(sum(dT2c.^2,2));
lengthsperm2=[Lengths2a,Lengths2a,Lengths2b,Lengths2b,Lengths2c,Lengths2c].';
Lengths2=lengthsperm2(:);



