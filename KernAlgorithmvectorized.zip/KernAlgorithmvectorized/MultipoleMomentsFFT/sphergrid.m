function [theta,phi,w,thetagrid,phigrid]=sphergrid(n)
%%% create the grid of special points for the fast spher ham transform
%% based on the gauslegendre abscissa and weights
%% for LDOS we need n=4

[x,w]=gausleg(n);
theta=acos(x);
phi=2*pi*[0:2*n-1]/(2*n);



[thetagrid phigrid]=meshgrid(theta,phi);

theta=reshape(thetagrid,prod(size(thetagrid)),1);
phi=reshape(phigrid,prod(size(thetagrid)),1);


 