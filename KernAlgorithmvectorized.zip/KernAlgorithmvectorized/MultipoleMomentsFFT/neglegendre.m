function [legbit]=neglegendre(n,x)
%%% 
%%%% legendre Pnm also for negative m

legbit=legendre(n,x,'norm');


if(n>0),
 
legbit=[legbit(n+1:-1:2,:);legbit];
end