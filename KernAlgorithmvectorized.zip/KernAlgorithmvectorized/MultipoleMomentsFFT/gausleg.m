
function [x,w]=gausleg(n)
%% taken from Numerical Recipes in C
%% transcribed to matlab
m=(n+1)/2;
x1=-1.0;
x2=1.0;
xm=0.5*(x2+x1);
xl=0.5*(x2-x1);
for p=1:m,
z=cos(pi*(p-0.25)/(n+0.5));
z1=-1;
while(abs(z-z1)>3E-11)
p1=1.0;
p2=0.0;
for j=1:n,
p3=p2;
p2=p1;
p1=((2*j-1)*z*p2-(j-1)*p3)/j;
end
pp=n*(z*p1-p2)/(z*z-1.0);
z1=z;
z=z1-p1/pp;
end
x(p)=xm-xl*z;
x(n+1-p)=xm+xl*z;
w(p)=2.0*xl/((1.0-z*z)*pp*pp);
w(n+1-p)=w(p);
end
