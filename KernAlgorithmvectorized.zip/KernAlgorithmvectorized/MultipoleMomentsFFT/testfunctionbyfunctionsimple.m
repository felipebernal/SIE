function testfunctionbyfunctionsimple

%radius is how far from the center we want to make the projection
%FieldE is a function that when given a (nx3) vector with [x,y,z] positions
%gives the scattered electric field.

%Get the points where the fields and functions need to be found
%And do it for a maximum order nmax of your Ynm's

nmax=10;
%The weights and points are found with the gauss-legendre quadrature function
%from numerical recipies
[thetaspecial,phispecial,weights,thetagrid,phigrid]=sphergrid(nmax);

%Now we evaluate our functions in these special points at a given radius.
%the fucntions come from the paper of mhulig  and rokstuhl Metamaterials 5 (2011) 64�73
%These functions are the eq 7 but with out the conjugate(Ynm)sin(theta).

%positions=[radius.*sin(thetaspecial).*cos(phispecial),radius.*sin(thetaspecial).*sin(phispecial),radius.*cos(thetaspecial)];
%Exyz=FieldE(positions);
%Er=sin(thetaspecial).*cos(phispecial).*Exyz(:,1)+sin(thetaspecial).*sin(phispecial).*Exyz(:,2)+cos(thetaspecial).*Exyz(:,3);
%Etheta=cos(thetaspecial).*cos(phispecial).*Exyz(:,1)+cos(thetaspecial).*sin(phispecial).*Exyz(:,2)-sin(thetaspecial).*Exyz(:,3);
%Ephi=-sin(thetaspecial).*Exyz(:,1)+cos(phispecial).*Exyz(:,2);

%evalfunction=Ynm(thetaspecial,phispecial,2,2)+0.5*Ynm(thetaspecial,phispecial,2,-2);
radius=5;
k=5;
n=1;
m=-1;
%evalfunction=BBottThetaFunc(thetaspecial,phispecial,radius,k,n,m);
%evalfunction=Mnmtheta(thetaspecial,phispecial,radius,k,2,-2);
%evalfunction=BBottPhiFunc1(thetaspecial,phispecial,radius,k,n,m);
%evalfunction=BBottPhiFunc2(thetaspecial,phispecial,radius,k,n,m);
%evalfunction=Ynm(thetaspecial,phispecial,n,m);
%evalfunction=2*sin(thetaspecial).^5.*cos(phispecial).^3;
%evalfunction=ABottRFunc(thetaspecial,phispecial,radius,k,n,m);
%evalfunction=ABottPhiFunc(thetaspecial,phispecial,radius,k,n,m);
evalfunction=ABottThetaFunc2(thetaspecial,phispecial,radius,k,n,m);




radius='doenstmaater';
k=radius;
%First the a values

n=0;m=0;
a00=anm(thetaspecial,phispecial,radius,k,evalfunction,weights,n,m)

n=1;m=0;
a10=anm(thetaspecial,phispecial,radius,k,evalfunction,weights,n,m)
n=1;m=1;
a11=anm(thetaspecial,phispecial,radius,k,evalfunction,weights,n,m)
n=1;m=-1;
a1m1=anm(thetaspecial,phispecial,radius,k,evalfunction,weights,n,m)
n=2;m=0;
a20=anm(thetaspecial,phispecial,radius,k,evalfunction,weights,n,m)
n=2;m=-1;
a2m1=anm(thetaspecial,phispecial,radius,k,evalfunction,weights,n,m)
n=2;m=1;
a21=anm(thetaspecial,phispecial,radius,k,evalfunction,weights,n,m)
n=2;m=-2;
a2m2=anm(thetaspecial,phispecial,radius,k,evalfunction,weights,n,m)
n=2;m=2;
a22=anm(thetaspecial,phispecial,radius,k,evalfunction,weights,n,m)





    function val=ABottThetaFunc1(theta,phi,radi,K,n,m)
        val=((-(1+n)*cot(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m)).*Ynm(theta,phi,n,m)+((n-m+1)*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n+1,m)).*Ynm(theta,phi,n+1,m))...
            .*conj(-(1+n)*cot(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m));
    end


  
    function val=Nthetanm2(theta,phi,radi,K,n,m)
        val=((n-m+1)*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n+1,m)).*Ynm(theta,phi,n+1,m);
    end


    function val=ABottThetaFunc2(theta,phi,radi,K,n,m)
        val=((-(1+n)*cot(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m)).*Ynm(theta,phi,n,m)+((n-m+1)*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n+1,m)).*Ynm(theta,phi,n+1,m))...
            .*conj((n-m+1)*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n+1,m));
    end

%

    function val=ABottPhiFunc(theta,phi,radi,K,n,m)
        val=Ynm(theta,phi,n,m).*(1i*m*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m)).*conj(1i*m*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m));
    end


    function val=ABottRFunc(theta,phi,radi,K,n,m)
        val=Ynm(theta,phi,n,m).*( n*(n+1).*invF(n,m).*besselh(n,1,K.*radi)./(K*radi))...
            .*conj(n*(n+1).*invF(n,m).*besselh(n,1,K.*radi)./(K*radi) );
    end

    function val=BBottThetaFunc(theta,phi,radi,K,n,m)
        val=(1i*m*(csc(theta))*besselh(n,1,K.*radi)*invF(n,m).*Ynm(theta,phi,n,m)).*conj(1i*m*(csc(theta))*besselh(n,1,K.*radi)*invF(n,m));
        %Checked
    end
%
    function val=Mnmtheta(theta,phi,radi,K,n,m)
        val=(1i*m*(csc(theta))*besselh(n,1,K.*radi)*invF(n,m).*Ynm(theta,phi,n,m));
        %Checked
    end

    function val=BBottPhiFunc1(theta,phi,radi,K,n,m)
        
        val=(((1+n)*cot(theta).*besselh(n,1,K.*radi).*invF(n,m)).*Ynm(theta,phi,n,m)+(-(n-m+1)*csc(theta).*besselh(n,1,K.*radi).*invF(n+1,m)).*Ynm(theta,phi,n+1,m))...
            .*conj((1+n)*cot(theta).*besselh(n,1,K.*radi).*invF(n,m));
        %checked
    end


    function val=BBottPhiFunc2(theta,phi,radi,K,n,m)
        val=(((1+n)*cot(theta).*besselh(n,1,K.*radi).*invF(n,m)).*Ynm(theta,phi,n,m)+(-(n-m+1)*csc(theta).*besselh(n,1,K.*radi).*invF(n+1,m)).*Ynm(theta,phi,n+1,m))...
            .*conj(-(n-m+1)*csc(theta).*besselh(n,1,K.*radi).*invF(n+1,m));
        
    end






%[coeffs]=invertdata(reshape(evalfunction,size(thetagrid)),thetagrid,phigrid,weights,nmax);

    function vala=anm(theta,phi,radius,k,evalfunction,w,n,m)
        weightint=VECrpt1D(w.',size(theta,1)/size(w,2));
        pnmval=Pnm(cos(theta),n,m);
        if m>=0
            normalization=((2*n+1)/2)*factorial(n-m)/factorial(n+m);
        elseif m<0
            normalization=(((2*n+1)/2));
        end
        inverso=invF(n,m);
        %integraltop=
        integralupnm=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmval*invF(n,m)*normalization.*(evalfunction);
        vala=sum(integralupnm,1);
    end



    function [theta,phi,w,thetagrid,phigrid]=sphergrid(n)
        % create the grid of special points for the fast spher ham transform
        % based on the gauslegendre abscissa and weights
        [x,w]=gausleg(n);%this get us the points and weights in the interval -1 to 1;
        theta=acos(x);
        phi=2*pi*[0:2*n-1]/(2*n);%why is this choice?
        [thetagrid phigrid]=meshgrid(theta,phi);
        %theta=reshape(thetagrid,prod(size(thetagrid)),1);
        theta=thetagrid(:);
        %phi=reshape(phigrid,prod(size(thetagrid)),1);
        phi=phigrid(:);
    end


    function val=invF(n,m)
        
        if m>=0
            val=1/(sqrt(((2*n+1)*factorial(n-m) )./(4*pi*factorial(n+m))));
            
        elseif m<0
            val=conj(1/(sqrt(((2*n+1)*factorial(n-abs(m)) )./(4*pi*factorial(n+abs(m))))));
            
        end
    end

    function val=ddrhankel(radi,K,n)
        val=K*radi*besselh(n-1,1,K*radi)-(n-1)*besselh(n,1,K*radi);
    end

    function val=Ynm(theta,phi,n,m)
        if m>=0
            val=sqrt(((2*n+1)*factorial(n-m))./(4*pi*factorial(n+m))).*Pnm(cos(theta),n,m).*exp(1i*m*phi);
        elseif m<0
            val=(-1)^abs(m)*conj(sqrt(((2*n+1)*factorial(n-abs(m)))./(4*pi*factorial(n+abs(m)))).*Pnm(cos(theta),n,abs(m)).*exp(1i*abs(m)*phi));
            
        end
        %Checked
    end


    function val=Pnm(x,n,m)
        if n==0
            val=legendre(n,x);%this is because if n is equal to zero then the function keep the orderthat the costheta had, otherwise it flips it.
        elseif(n>0),
            valvec=legendre(n,x).';
            if m>=0
                val=valvec(:,m+1);
            elseif m<0
                val=((-1)^abs(m))*factorial(n-abs(m))/factorial(n+abs(m))*valvec(:,abs(m)+1);
            end
            %checked
        end
        
        %         if n==0
        %             val=legendre(n,x,'norm');%this is because if n is equal to zero then the function keep the orderthat the costheta had, otherwise it flips it.
        %         elseif(n>0),
        %             valvec=legendre(n,x,'norm').';
        %             if m>=0
        %                 val=valvec(:,m+1);
        %             elseif m<0
        %                 val=((-1)^abs(m))*factorial(n-abs(m))/factorial(n+abs(m))*valvec(:,abs(m)+1);
        %             end
        %
        %         end
        %
        
    end







%%%%%%%%%%%%%%%%%%%%%%%%%55
    function val=AUpRFunc(~,~,radi,K,Fieldr,n,m)
        val=Fieldr.*conj( n*(n+1).*invF(n,m).*besselh(n,1,K.*radi)./(K*radi) );
    end

    function val=AUpPhiFunc(theta,~,radi,K,Fieldphi,n,m)
        val=Fieldphi.*conj(1i*m.*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m));
    end

    function val=AUpThetaFunc1(theta,~,radi,K,Fieldtheta,n,m)
        %         if n==0
        %             val=zeros(size(theta,1),1);
        %         else
        %         val=Fieldtheta.*conj(n*cot(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m));
        %         end
        val=Fieldtheta.*conj(-(1+n)*cot(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m));
        
    end
    function val=AUpThetaFunc2(theta,~,radi,K,Fieldtheta,n,m)
        %if n==0
        %    val=zeros(size(theta,1),1);
        %else
        %val=Fieldtheta.*conj(-(1/K*radi)*(n+m)*ddrhankel(radi,K,n)*invF(n-1,m));
        %end
        val=Fieldtheta.*conj((n-m+1)*csc(theta)*(1/K*radi)*ddrhankel(radi,K,n)*invF(n+1,m));
        
    end
    function val=BUpPhiFunc1(theta,phi,radi,K,Fieldphi,n,m)
        % val=Fieldphi.*conj(-n*cot(theta).*besselh(n,1,K.*radi).*invF(n,m));
        val=Fieldphi.*conj((1+n)*cot(theta).*besselh(n,1,K.*radi).*invF(n,m));
    end
    function val=BUpPhiFunc2(theta,phi,radi,K,Fieldphi,n,m)
        %if n==0
        %    val=zeros(size(theta,1),1);
        %else
        %val=Fieldphi.*conj((n+m)*csc(theta).*besselh(n,1,K.*radi).*invF(n-1,m));
        %end
        val=Fieldphi.*conj(-(n-m+1)*csc(theta).*besselh(n,1,K.*radi).*invF(n+1,m));
    end
    function val=BUpThetaFunc(theta,phi,radi,K,Fieldtheta,n,m)
        val=Fieldtheta.*conj(1i*m.*(csc(theta))*besselh(n,1,K.*radi)*invF(n,m));
    end
%function val=BBottThetaFunc(theta,phi,radi,K,n,m)
%    val=(1i*m*(csc(theta))*besselh(n,1,K.*radi)*invF(n,m).*Ynm(theta,phi,n,m)).*conj(1i*m*(csc(theta))*besselh(n,1,K.*radi)*invF(n,m));
%end



end