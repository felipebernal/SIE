% this function is the product of the functions in the term 1_2 of the
% integral 35 in reference A.Kern  in pag 736

function funEHInt1_2SMTHval= funEHInt1_2SMTH(rtoeval,rtri,nodetri,rpt,k,pm,LineNodes,triangle,positions)

%Although the original DivG (which is actually gradient of G...sorry for that div!)in this term does not have a minus sign I put it here given that this is the 
%divergence over the not primed coordinate which is the same as minus the divergence of the primed 
%coordinate which we had already caculated.  
prefactor=Gsmth(rtoeval,rtri,k);
funEHInt1_2SMTHval=prefactor(:,ones(3,1)).*RWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions);


%Checked