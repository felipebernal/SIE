% this function is the sum of the terms smooth and not smooth in the first integral for
% finding the Total electric or magnetic field.

function valEHInt1= EHInt1(k,rtoeval,node,LineNodes,triangle,positions)

valEHInt1= EHInt1SMTH(k,rtoeval,node,LineNodes,triangle,positions)+EHInt1NTSMTH(k,rtoeval,node,LineNodes,triangle,positions);