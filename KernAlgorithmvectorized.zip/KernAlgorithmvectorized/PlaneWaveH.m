function valfunH= PlaneWaveH(omega,direction,pol, r,~,muv,epsilonv,sourceinout)
%in this case direction and pol are the direction and polarization 
%for the E field and they are converted inside the program.
c=1;
epsilon=epsilonv(sourceinout);
mu=muv(sourceinout);
%pol=[1 0 0];
numr=size(r,1);
normk=omega*sqrt(epsilon*mu)/c;
direction=direction./norm(direction);
directionrtp=repmat(normk*direction,numr,1);
kr=sum(directionrtp.*r,2);
hpol=cross(direction,pol);
valueH=exp(1i*kr);
valfunH=hpol(ones(numr,1),:).*valueH(:,ones(3,1));
