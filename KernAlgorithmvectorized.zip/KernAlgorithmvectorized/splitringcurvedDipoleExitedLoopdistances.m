function [elecdip,magdip]=splitringcurvedDipoleExitedLoopdistances

name='Splitringcurved';
omega=2*pi/(1544.3/1000);
lambda=(2*pi/omega)*1000;
c=1;
k=omega/c;
epsilonv=[1;Gold(1000*(2*pi)/omega)];
muv=[1;1];


%Source things
direction=[0 0 -1];
pol=[1 0 0];
%rsource=[0 0.07+0 0];
sourceinout=1;
%That was it

numberofpoints=100;
numberoftilesMatrix=2;

icont=1;
z=0;
numberoftiles=10;


directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date;


        Struct=load([directory, dia,'\',name,'.mat']);
        TheMat=Struct.TheMat;
        [LineNodes,triangle,positions]= reader(name);
        clear('Struct');
        %TheV=TheVectorFiller(omega,direction,pol,rsource,@DipoleEField,@DipoleHField,LineNodes,triangle,positions,muv,epsilonv,sourceinout);

 numpos=200;  
 minpos=0.05;
 maxpos=2.5;
 elecdip=zeros(numpos,3);       
 magdip=zeros(numpos,3);   
 cont=1;
%for rsourceshift=logspace(log10( minpos),log10(maxpos),numpos)     
 for rsourceshift=linspace(minpos,maxpos,numpos)     
    
 rsource=[0 0+rsourceshift 0];      
 TheV = TheVectorFillerForLDOS(omega,direction,pol,rsource,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
 [dipoles,Quadrupoles]=VectorSphericalHarmonicsMultipoleRetrieval(k,epsilonv,muv,TheMat,TheV,direction,pol,rsource,name,sourceinout);
elecdip(cont,1:3)=dipoles(1:3,:);
magdip(cont,1:3)=dipoles(4:6,:);
 cont=cont+1;
end
    figure(1);
    plot(linspace(minpos,maxpos,numpos),abs(elecdip),linspace(minpos,maxpos,numpos),abs(magdip));
    %plot(logspace(log10( minpos),log10(maxpos),numpos),abs(elecdip),logspace(log10( minpos),log10(maxpos),numpos)  ,abs(magdip));
    figure(2);
    plot(linspace(minpos,maxpos,numpos),angle(elecdip),linspace(minpos,maxpos,numpos),angle(magdip));
    %plot(logspace(log10( minpos),log10(maxpos),numpos),angle(elecdip),logspace(log10( minpos),log10(maxpos),numpos),angle(magdip));


plotfields=0;

if plotfields==1
    %[vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions,sourceinout);
   numberofpoints=100;
   Radiusf=1000;
    [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radiusf,numberofpoints,TheV,TheMat,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions,sourceinout);
    Escatsqrparallel=sum(vecplotparallel.*conj(vecplotparallel),2);%sum(abs(vecplotparallel).^2,2);
    sigmascatparallel=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radiusf^2*Escatsqrparallel];
    
    Escatsqrperpendm=sum(vecplotperpedicular.*conj(vecplotperpedicular),2);    %sum(abs(vecplotperpedicular),2);
    sigmascatperpend=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radiusf^2* Escatsqrperpendm];
    
    figure(1);
    polar([sigmascatparallel(:,1);NaN;sigmascatperpend(:,1)],[sigmascatparallel(:,2);NaN;sigmascatperpend(:,2)]);
    figure(2);
    polar(sigmascatparallel(:,1),sigmascatparallel(:,2));
    figure(3)
    polar(sigmascatperpend(:,1),sigmascatperpend(:,2));
    
end

%Here we are going to put the vector spherical harmonic function with the
%change to use the total field rather than the scattered field.

%%
    function [dipoles,Quadrupoles]=VectorSphericalHarmonicsMultipoleRetrieval(k,epsilonv,muv,TheMat,TheV,direction,pol,rsource,name,sourceinout)
        %Medium radius is good to find dipoles without numerical noise
        %Short radius is better to find quadrupoles.
        Radius=1000*2*pi/k;
        c=1;
        Zo=sqrt(muv(1)/epsilonv(1));
        omega=k*c;
        numberofpoints=10;
        [LineNodes,triangle,positions]= reader(name);
        
        FemiusCode=1;
        
        if FemiusCode==1
            
            
            Nth=20;
            Nphi=20;
            theta=[1:Nth]/(Nth+1)*pi;
            phi=[1:Nphi]/Nphi*2*pi;
            [theta phi]=meshgrid(theta,phi);
            thetalist=reshape(theta,1,prod(size(theta)));
            
            philist=reshape(phi,size(thetalist));
            
            positionsphere=[Radius*sin(thetalist.').*cos(philist.'),Radius*sin(thetalist.').*sin(philist.'),Radius*cos(thetalist.')];
            
                   
             %this is the scattered field
            valE=FieldEfinder(1,'scatt','far',positionsphere,omega,epsilonv,muv,direction,pol,rsource,@DipoleEField,@DipoleHField,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
            %this is the total field
            %valE=FieldEfinder(1,'total','far',positionsphere,omega,epsilonv,muv,direction,pol,rsource,@DipoleEField,@DipoleHField,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
            %this is the source field
            %valE=FieldEfinder(1,'total','far',positionsphere,omega,epsilonv,muv,direction,pol,rsource,@DipoleEField,@DipoleHField,TheV,TheMat,LineNodes,triangle,positions,sourceinout)-FieldEfinder(1,'scatt','far',positionsphere,omega,epsilonv,muv,direction,pol,rsource,@DipoleEField,@DipoleHField,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
            
            
            
            size(thetalist);
            size(philist);
            size(valE);
            
            %for p=1:length(thetalist),
            %    Efield.x(p)=valE(p,1); Efield.y(p)=valE(p,2); Efield.z(p)=valE(p,3);
            %end
            
            Efield.x=valE(:,1); Efield.y=valE(:,2); Efield.z=valE(:,3);
            
            [p m]=retrievedipoleFemius(Efield,k,Radius,thetalist,philist);
            dipoles=[(4*pi)*p.';(4*pi)*m.'];
            Quadrupoles=0;
            
        else
            
            
            thetapoints=[0:pi/(numberofpoints-1):pi]';
            phipoints=[0:2*pi/(numberofpoints-1):2*pi]';
            
            alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
            allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
            positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];
            
            
            valE=FieldEfinder(1,'total','far',positionsphere,omega,epsilonv,muv,direction,pol,rsource,@DipoleEField,@DipoleHField,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
            valH=FieldHfinder(1,'total','far',positionsphere,omega,epsilonv,muv,direction,pol,rsource,@DipoleEField,@DipoleHField,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
            %px=-1i*(sqrt(3*pi)/(c*k^3))*(aE(1,1)-aE(1,-1));
            %py=(sqrt(3*pi)/(c*k^3))*(aE(1,1)+aE(1,-1));
            %pz=(1i*sqrt(6*pi)/(c*k^3))*aE(1,0);
            
            %px=-sqrt(2/3)*1i*(sqrt(3*pi)/(c*k^3))*(aE(1,1)-aE(1,-1));
            px=(sqrt(2/3)*1i*(sqrt(3*pi)/(c*k^3))*(aE(1,1)-aE(1,-1)))';
            py=(sqrt(3*pi)/(c*k^3))*(aE(1,1)+aE(1,-1));
            pz=sqrt(27/(10*pi))*(1i*sqrt(6*pi)/(c*k^3))*aE(1,0);
            %mx=c*1i*(sqrt(3*pi)/(c*k^3))*(aM(1,1)-aM(1,-1));
            %my=-c*(sqrt(3*pi)/(c*k^3))*(aM(1,1)+aM(1,-1));
            %mz=-c*(1i*sqrt(6*pi)/(c*k^3))*aM(1,0);
            mx=sqrt(2/3)*c*1i*(sqrt(3*pi)/(c*k^3))*(aM(1,1)-aM(1,-1));
            my=-c*(sqrt(3*pi)/(c*k^3))*(aM(1,1)+aM(1,-1));
            mz=-sqrt(27/(10*pi))*c*(1i*sqrt(6*pi)/(c*k^3))*aM(1,0);
            dipoles=[px;py;pz;mx;my;mz];
            prefact1=6*1i*sqrt(5*pi)/(c*k^4);
            prefact2=1i*sqrt(30*pi)/(c*k^4);
            prefact3=6*sqrt(5*pi)/(c*k^4);
            Q11=prefact1*(aE(2,2)+aE(2,-2))-2*prefact2*aE(2,0);
            Q22=-prefact1*(aE(2,2)+aE(2,-2))-2*prefact2*aE(2,0);
            Q33=4*prefact2*aE(2,0);
            Q12=-prefact3*(aE(2,2)-aE(2,-2));
            Q13=-prefact1*(aE(2,1)-aE(2,-1));
            Q23=prefact3*(aE(2,1)+aE(2,-1));
            
            Quadrupoles=[Q11,Q12,Q13;Q12,Q22,Q23;Q13,Q23,Q33];
            
        end
        
        function valaE=aE(l,m)
            valaE=(-k/sqrt(l*(l+1))).*(1/Zo).*(1/(h1l(l,k*Radius))).*(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*sum(sin(alltheta).*conj( Ylm(l,m,alltheta,allphi) ).*(sum(positionsphere.*valE,2)),1);
        end
        
        function valaM=aM(l,m)
            valaM=(k/sqrt(l*(l+1))).*(1/(h1l(l,k*Radius))).*(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*sum(sin(alltheta).*conj( Ylm(l,m,alltheta,allphi) ).*(sum(positionsphere.*valH,2)),1);
        end
        
        function valYlm=Ylm(l,m,theta,phi)
            LegeCosthetaLM=legendre(l,cos(theta));
            if m>=0&&m<=l
                valYlm=sqrt(((2*l+1)/(4*pi))*factorial(l-m)/factorial(l+m)).*LegeCosthetaLM(m+1,:)'.*exp(1i*m*phi);
            elseif m<0&&m<=l
                absm=abs(m);
                valYlm=(-1)^(absm)*conj(sqrt(((2*l+1)/(4*pi))*factorial(l-absm)/factorial(l+absm)).*LegeCosthetaLM(absm+1,:)'.*exp(1i*absm*phi));
            elseif m>l
                valYlm=zeros(size(theta,1),1);
            end
        end
        
        function valsphehank=h1l(n,x)
            valsphehank=sqrt(pi./(2*x)).* besselh(n+1/2,1,x);
        end
    end

%%
    %function [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,i,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions,sourceinout)
     function [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,TheV,TheMat,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions,sourceinout)   
        center=[0,0,0];
             directuni=direction/norm(direction);
        poluni=pol/norm(pol);
        polperpenduni=cross(directuni,pol)/(norm(cross(directuni,pol)));
        
        thetapoints=[0:2*pi/(numberofpoints-1):2*pi]';
        
        positionsphereparalel=Radius*cos(thetapoints)*directuni+Radius*sin(thetapoints)*poluni;
        positionsphereperpedicular=Radius*cos(thetapoints)*directuni+ Radius*sin(thetapoints)*polperpenduni;
        
        vecplotparallel=FieldEfinder(1,'total','far',positionsphereparalel,omega,epsilonv,muv,direction,pol,rsource,@DipoleEField,@DipoleHField,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
        vecplotperpedicular=FieldEfinder(1,'total','far',positionsphereperpedicular,omega,epsilonv,muv,direction,pol,rsource,@DipoleEField,@DipoleHField,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
        
        
        
    end


end