function [vecplotsigmaplus,vecplotsigmaminus]=FieldTotalCrossSecHakkiHelixPolarizationChangePLUS

Radius=10;
numberofpoints=10;

muv=[1;1];
direction=[0 0 -1];
sourceinout=1;

v1=[-sin(0)  cos(0) 0];
    v2=[cos(0)*cos(0) sin(0)*cos(0) sin(0)];%   
    sigmaplus=1/sqrt(2)*(v1-1i*v2);
    sigmaminus=1/sqrt(2)*(v1+1i*v2);

    
    
%%%first for sigmaplus.....    
rsource=[0 0 0];
name='HakiHelixMesh';
[LineNodes,triangle,positions]= reader('HakiHelixMesh');

thetapoints=[0:pi/(numberofpoints-1):pi]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';

alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];

directory='\\nanorfsrv\Users\Bernal\Simulations\';
minlam=500;
maxlam=1500;
deltalam=20;

vecplotsigmaplus=zeros(size([minlam:deltalam:maxlam]',1),1);
vecplotsigmaminus=zeros(size([minlam:deltalam:maxlam]',1),1);

cont=1;
dia='29-May-2012';

dia2=date;
for c=minlam:deltalam:maxlam
    matrix=load(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\',name,'_',int2str(c),'_Matrix','.mat']);
    TheMat=matrix.TheMat;
    
     omega=1000*(2*pi)/c;
    epsilonv=[1;Gold(1000*(2*pi)/c)]; %This one suposes that a=1micron (the unit of lenght)
    
    
    %first for sigmaplus
    TheV=TheVectorFiller(omega,direction,sigmaplus,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
    save([directory, dia2,'\',name,'_',int2str(c),'_','VectorSigmaplus_.mat'],'TheV');
    % clear('matrix','vector');
    valE=FieldEfinder(1,'scatt','far',positionsphere,(2*pi/(c/1000)),epsilonv,muv,direction,sigmaplus,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
    vecplotsigmaplus(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);
   
    %now for sigmaminus
    TheV=TheVectorFiller(omega,direction,sigmaminus,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
    save([directory, dia2,'\',name,'_',int2str(c),'_','VectorSigmaminus_.mat'],'TheV');
    % clear('matrix','vector');
    valE=FieldEfinder(1,'scatt','far',positionsphere,(2*pi/(c/1000)),epsilonv,muv,direction,sigmaminus,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
    vecplotsigmaminus(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);
   
    cont=cont+1;
end
aplus=[[minlam:deltalam:maxlam]', vecplotsigmaplus];
aminus=[[minlam:deltalam:maxlam]', vecplotsigmaminus];
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia2,'\TotalScattCrossSecHakkiHelixSigmaplus.txt'], 'aplus','-ascii');
 save([directory, dia2,'\',name,'polarizationRangesandsoonsigmaplus.mat'],'minlam','maxlam','sigmaplus','direction');
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia2,'\TotalScattCrossSecHakkiHelixSigmaminus.txt'], 'aminus','-ascii');
 save([directory, dia2,'\',name,'polarizationRangesandsoonsigmaminus.mat'],'minlam','maxlam','sigmaminus','direction');
 
 
figure(1)
plot([minlam:deltalam:maxlam]',vecplotsigmaplus);
title('sigmaplus');
figure(2)
plot([minlam:deltalam:maxlam]',vecplotsigmaminus);
title('sigmaminus');


end
