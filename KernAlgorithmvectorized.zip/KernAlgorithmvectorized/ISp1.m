% This function finds the value of the integral I^{S}_{1} from the paper
% PIER 63, 243-278, 2006


function valIsp1=ISp1(r,p1,p2,p3)%Dtri,triangle,positions)

%p1=positions(triangle(Dtri,1),:);
%p2=positions(triangle(Dtri,2),:);
%p3=positions(triangle(Dtri,3),:);

numr=size(r,1);


b=cross((p2-p1),(p3-p1));
bnorm=sqrt(sum(b.^2,2));
n=b./bnorm(:,ones(3,1));




p2p1norm=sqrt(sum((p2-p1).^2,2));
m1=cross((p2-p1)./p2p1norm(:,ones(3,1)),n,2);

p3p2norm=sqrt(sum((p3-p2).^2,2));
m2=cross((p3-p2)./p3p2norm(:,ones(3,1)),n,2);

p1p3norm=sqrt(sum((p1-p3).^2,2));
m3=cross((p1-p3)./p1p3norm(:,ones(3,1)),n,2);


%dP1 boundary of the triangle defined by the pa and pb nodes
pa1=p1;
pb1=p2;
%PA1=pa1(ones(numr,1),:);
%PB1=pb1(ones(numr,1),:);
%M1=m1(ones(numr,1),:);
t1=sum(m1.*(r-pa1),2);

%vectorized inner product sum(a1.*a2,2) for a list of vectors
%dp2
pa2=p2;
pb2=p3;
%PA2=pa2(ones(numr,1),:);
%PB2=pb2(ones(numr,1),:);
%M2=m2(ones(numr,1),:);
t2=sum(m2.*(r-pa2),2);

%dP3
pa3=p3;
pb3=p1;
%PA3=pa3(ones(numr,1),:);
%PB3=pb3(ones(numr,1),:);
%M3=m3(ones(numr,1),:);
t3=sum(m3.*(r-pa3),2);

%The integral is
h=Hh(r,p1,p2,p3);
valIsp1=zeros(numr,1);

firstpart=((h.^2)/3).*ISm1(r,p1,p2,p3);
secondpart=-(1/3)*(t1.*ILp1(r,pa1,pb1)+t2.*ILp1(r,pa2,pb2)+t3.*ILp1(r,pa3,pb3));
combinedpart=firstpart+secondpart; 
%valIsp1=((h.^2)/3).*ISm1(r,p1,p2,p3)-(1/3)*(t1.*ILp1(r,pa1,pb1)+t2.*ILp1(r,pa2,pb2)+t3.*ILp1(r,pa3,pb3));
valIsp1(logical(h.^2<=1e-15))=secondpart(logical(h.^2<=1e-15));
valIsp1(logical(h.^2>1e-15))=combinedpart(logical(h.^2>1e-15));

