% this function is the second notsmooth term of the first integral for
% finding the Total electric or magnetic field.

function valEHInt1_2NTSMTH= EHInt1_2NTSMTH(K,rtri,node,LineNodes,triangle,positions)
rpt=1; %this rpt is differnet given that in this case I want to see what is the
%values of all the nodes for one singel r and before I wanted to know for 7 r's the value in a single node.
%Thats why in this case rpt is 1 but we repeat the nodes with repmat a
%numeber or times.

totalnodes=size(node,1);
totalr=size(rtri,1);
rtrirpt=VECrpt3D(rtri,totalnodes);
nodesrpt=repmat(node,totalr,1);

valEHInt1_2NTSMTH=(1/(4*pi))*( Km1p2(rtrirpt,nodesrpt,rpt,LineNodes,triangle,positions)-((K^2)/2)*Kp1p2(rtrirpt,nodesrpt,rpt,LineNodes,triangle,positions));    
 
%valEHInt1_2NTSMTH=(1/(4*pi))*Kp1p2(rtrirpt,nodesrpt,rpt,LineNodes,triangle,positions).*( Km1p2(rtrirpt,nodesrpt,rpt,LineNodes,triangle,positions)./Kp1p2(rtrirpt,nodesrpt,rpt,LineNodes,triangle,positions)-((K^2)/2));    
 