function greenTrans=GreenTransversal(r,w,lambdat)

I=[1 0 0;0 1 0;0 0 1];
outr=r'*r;
c=2.98*10^8;
k=w/c;
R=norm(r)
    
    function pval=P(z)
        pval=(1-1/z-1/z^2);
    end

    function pval=Q(z)
        pval=(-1+3/z-3/z^2);
    end

    function fval=fnormaliz(lambdats,p)
        fval=(lambdats^2)/((lambdats^2)+p^2);
    end

greenTrans=(I-3*outr)/(4*pi*k^2*R^3)-...
    ((exp(1i*k*R))/(4*pi*R)*(P(1i*k*R)*I+Q(1i*k*R)*outr)...
    -(exp(-lambdat*R))/(4*pi*R)*(P(-lambdat*R)*I+Q(-lambdat*R)*outr))...
    *fnormaliz(lambdat,k);
end

