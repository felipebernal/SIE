function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
    [sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistaticFDTDSPHERE(Radius)

name='sphereFDTD';
global struct;
global t;
%struct=[[1;4.01;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
%struct=[[1;2.127;2.127],[1;1;1]];%for glass the n is 1.45846(refractive index database for siN is 2.00347)
struct=[[1;2.25;2.25],[1;1;1]];
t=0;

omega=2*pi/(12.9);
%omega=pi;

%epsilonv=[1;12];
%epsilonv=[struct(1,1);Gold(1000*(2*pi)/omega)]; %This one suposes that a=1micron (the unit of lenght)
epsilonv=[struct(1,1);4.96+1i*4.16]; 
muv=[struct(1,2);1];
direction=[0 0 -1];
pol=[1 0 0];
rsource=[0 0 0];


%Radius=1.00000;
numberofpoints=100;
numberoftilesMatrix=1;

icont=1;
z=0;
numberoftiles=10;
xmin=-1;
xmax=1;
xstep=0.1;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia='24-Aug-2011'; %This is done so that if the simulation takes more than a day then you don't have problems saving the data.

if exist([directory, dia])==0
    mkdir([directory, dia]);
    [LineNodes,triangle,positions]= reader(name);
    TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
    save([directory, dia,'\',name,'.mat'],'TheMat','LineNodes','triangle','positions');
    TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveELayered,@PlaneWaveHLayered,LineNodes,triangle,positions);
     [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);
else
    if exist([directory, dia,'\',name,'.mat'])==0
    
        [LineNodes,triangle,positions]= reader(name);
        TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
        save([directory, dia,'\',name,'.mat'],'TheMat','LineNodes','triangle','positions');
        TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveELayered,@PlaneWaveHLayered,LineNodes,triangle,positions);
       [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);
    
    else
        Struct=load([directory, dia,'\',name,'.mat']);
        TheMat=Struct.TheMat;
        LineNodes=Struct.LineNodes;
        triangle=Struct.triangle;
        positions=Struct.positions;
        clear('Struct');
        TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
       [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);
    end
end
    
     
     
     Escatsqrparallel=sum(vecplotparallel.*conj(vecplotparallel),2);%sum(abs(vecplotparallel).^2,2);
     sigmascatparallel=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2*Escatsqrparallel];
     
     Escatsqrperpendm=sum(vecplotperpedicular.*conj(vecplotperpedicular),2);    %sum(abs(vecplotperpedicular),2);
     sigmascatperpend=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* Escatsqrperpendm];
     
          
    save([directory, dia,'\',name,'DrawingparallelperpendMatrix.mat'],'sigmascatparallel','sigmascatperpend'); 
    
    %polar(sigmascatparallel(:,1),sigmascatparallel(:,2));
    %polar(sigmascatperpend(:,1),sigmascatperpend(:,2));
    polar([sigmascatparallel(:,1);NaN;sigmascatperpend(:,1)],[sigmascatparallel(:,2);NaN;sigmascatperpend(:,2)]); 

    