function doubinteTrian = Dmnismth(omega,k,mu,nodem,noden,LineNodes,triangle,positions)
% This function makes the double integration over the triangles m and n of
% the green's function. 
%c=299792458;
barycentryctable;

[rtrim1, rtrim2]=BarycentGaussQuadPos(nodem,SPQ,LineNodes,triangle,positions);
%This function findss the positions for the plus 1 and minus 2 triangles
%for the list of nodes gven in nodem.

[rtrin1, rtrin2]=BarycentGaussQuadPos(noden,SPQ,LineNodes,triangle,positions);
%This function findss the positions for the plus 1 and minus 2 triangles
%for the list of nodes gven in noden.

%The Dmnismth value is composed by two integrals, each one of which is
%calculated over a node region composed by two triangles.
%Given that the integration can only be done for single triangles in the
%BaryDoubleTriQuadrature, then these two integrals are divided in 4
%different terms each. Each one with ++ +- -+ --

Int1term1=BaryDoubleTriQuadrature(1,1,rtrim1,rtrin1,weigths,@funDmni1term,nodem,noden,k,rpt,LineNodes,triangle,positions);
Int1term2=BaryDoubleTriQuadrature(1,2,rtrim1,rtrin2,weigths,@funDmni1term,nodem,noden,k,rpt,LineNodes,triangle,positions);
Int1term3=BaryDoubleTriQuadrature(2,1,rtrim2,rtrin1,weigths,@funDmni1term,nodem,noden,k,rpt,LineNodes,triangle,positions);
Int1term4=BaryDoubleTriQuadrature(2,2,rtrim2,rtrin2,weigths,@funDmni1term,nodem,noden,k,rpt,LineNodes,triangle,positions);
%Int1Term1,2,3,4 Checked!!

Int2term1=BaryDoubleTriQuadrature(1,1,rtrim1,rtrin1,weigths,@funDmni2term,nodem,noden,k,rpt,LineNodes,triangle,positions);
Int2term2=BaryDoubleTriQuadrature(1,2,rtrim1,rtrin2,weigths,@funDmni2term,nodem,noden,k,rpt,LineNodes,triangle,positions);
Int2term3=BaryDoubleTriQuadrature(2,1,rtrim2,rtrin1,weigths,@funDmni2term,nodem,noden,k,rpt,LineNodes,triangle,positions);
Int2term4=BaryDoubleTriQuadrature(2,2,rtrim2,rtrin2,weigths,@funDmni2term,nodem,noden,k,rpt,LineNodes,triangle,positions);
%Int2Term1,2,3,4 Checked!!

doubinteTrian=(omega*mu/1i)*(...
            (-1/(k^2))*(Int1term1+Int1term2+Int1term3+Int1term4)...
            +(Int2term1+Int2term2+Int2term3+Int2term4)...
            );
        %Checked!!