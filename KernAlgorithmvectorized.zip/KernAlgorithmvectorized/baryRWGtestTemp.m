function valbaryRWGtest=baryRWGtestTemp(rpos,nodem,~,rpt,pm,LineNodes,triangle,positions)

nodem=VECrpt1D(nodem,rpt);
valbaryRWGtest=RWGfunction(rpos,nodem,rpt,pm,LineNodes,triangle,positions);

