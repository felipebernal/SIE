%This is the  green's function found in page 735 of Vol 26, No 4
%April 2009/J.Opt.SocAm.A Kern and Martin.


function valGTOTAL=GTOTAL(r,rp,k)
%r and rp can be a list of 3-vectors, but the list should have the same number of
%positions.
R=sqrt(sum((r-rp).^2,2));
valGTOTAL=(1/(4*pi))*(exp(1i*k.*R)./R);
%Checked
