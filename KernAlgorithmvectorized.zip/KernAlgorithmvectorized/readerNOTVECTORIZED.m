%you need to save the .msh file from gmsh in the version 1 that is given
%in save as....version two does not work!!!!

function [LineNodes,triangle,positions]= readerNOTVECTORIZED(name)

%STRUCTURE DEFINITIONS
%%load the values and get the nodes and triangles
struct=load_gmsh2( ['\\nanorfsrv\Users\Bernal\Simulations\Meshes\',name,'.msh'], 2);
%struct=load_gmsh2( 'twospheresII.msh', 2);
positions=struct.POS;
triangle=struct.TRIANGLES;
%%define the shared lines (LineNodes)
numtri=size(triangle);
i=1;
LineNodes=zeros(1,7);
sizelinenodes=0;
pm1=0;
pm2=0;
nodelength=0;
for n=1:numtri(1)
    for m=(n+1):numtri(1)
        %doing a for over all the triangles first we find how many
        %triangles share two nodes.
        if nnz(triangle(n,1)==triangle(m,:))==1&&...
               nnz(triangle(n,2)==triangle(m,:))==1
               i=1;
               nodelength=norm(positions(triangle(n,1),:)-positions(triangle(n,2),:));
         else
            if nnz(triangle(n,2)==triangle(m,:))==1&&...
                nnz(triangle(n,3)==triangle(m,:))==1
                i=1;
                nodelength=norm(positions(triangle(n,2),:)-positions(triangle(n,3),:));
            else
                if nnz(triangle(n,3)==triangle(m,:))==1&&...
                  nnz(triangle(n,1)==triangle(m,:))==1
                  i=1;
                  nodelength=norm(positions(triangle(n,3),:)-positions(triangle(n,1),:));
                end
            end
        end
        %If they share two nodes then we find which are the two nodes that
        %are not shared and we call them pm1 and pm2
        if i==1
           if nnz(triangle(n,1)==triangle(m,:))==0
               pm1=1;
           else
               if nnz(triangle(n,2)==triangle(m,:))==0
                  pm1=2;
               else
                  if nnz(triangle(n,3)==triangle(m,:))==0
                    pm1=3;
                  end
               end
           end 
           
            if nnz(triangle(m,1)==triangle(n,:))==0
               pm2=1;
           else
               if nnz(triangle(m,2)==triangle(n,:))==0
                  pm2=2;
               else
                  if nnz(triangle(m,3)==triangle(n,:))==0
                    pm2=3;
                  end
               end
            end     
            sizelinenodes=sizelinenodes+1;
            LineNodes(sizelinenodes,:)=[n,m,pm1,pm2,nodelength,Area(n,triangle,positions),Area(m,triangle,positions)];
            i=0;
            nodelength=0;
        else
            i=0;
            nodelength=0;
        end
    end
end
    %LineNodes is composed by the index of the two triangles that share a
    %line and the two indexes of the nodes of each triangle that are not
    %shared the last value is the length of the shared linenode