%This is the smoothed green's function found in page 735 of Vol 26, No 4
%April 2009/J.Opt.SocAm.A Kern and Martin.


function valGsmth=Gsmth(r,rp,k)
%r and rp can be a list of 3-vectors, but the list should have the same number of
%positions.
numr=size(r,1);
R=sqrt(sum((r-rp).^2,2));
% valGsmth=(1/(4*pi))*((exp(1i*k*R)-ones(numr,1))./(R)+(k^2)*R/2);
valGsmth=(1i*k/(4*pi))*ones(numr,1);
%valGsmth=(1/(4*pi))*((exp(1i*k*R)-ones(numr,1))./(R)+(k^2)*R/2);
firstpart=(1/(4*pi))*((exp(1i*k*R)-1)./(R)+(k^2)*R/2);
valGsmth(logical(k*R>1e-15),:)=firstpart(logical(k*R>1e-15),:);
%checked!!