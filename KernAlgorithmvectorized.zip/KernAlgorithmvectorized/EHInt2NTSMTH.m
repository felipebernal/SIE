% this function is the notsmooth term of the second integral for
% finding the Total electric or magnetic field (see pag736 of A. Kern paper).

function valEHInt2NTSMTH= EHInt2NTSMTH(K,rtri,node,LineNodes,triangle,positions)

rpt=1; %this rpt is differnet given that in this case I want to see what is the
%values of all the nodes for one singel r and before I wanted to know for 7 r's the value in a single node.
%Thats why in this case rpt is 1 but we repeat the nodes with repmat a
%numeber or times.

totalnodes=size(node,1);
totalr=size(rtri,1);
rtrirpt=VECrpt3D(rtri,totalnodes);
nodesrpt=repmat(node,totalr,1);

valEHInt2NTSMTH=(1/(4*pi))*( Km1p4(rtrirpt,nodesrpt,rpt,LineNodes,triangle,positions)-((K^2)/2)*Kp1p4(rtrirpt,nodesrpt,rpt,LineNodes,triangle,positions));    

%Checked!!!
           