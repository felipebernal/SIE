function CurldyadG=CurlFreeDyadG(k,rdetect,rsource)
%function CurldyadG=CurlFreeDyadG(k,rvec)
rvec=rdetect-rsource;
A=1/(4*pi); %% remove 4pi to match de Abajo, and to get G in the (E,ZoH) unit system
numpoints=size(rvec,1);
r=sqrt(rvec(:,1).^2+rvec(:,2).^2+rvec(:,3).^2); 
  
F=A*exp(1i*k*r).*((1i*k)./(r.^2)-1./(r.^3));
 
%scalG=F;
%dyadG=[diagmat  -offdiagmat; offdiagmat diagmat];

%aux1=[0 -rvec(3) rvec(2); rvec(3),0,-rvec(1); -rvec(2) rvec(1) 0];

CurldyadG=zeros(3,3,numpoints);
%mat(1,1,:)=F.*0; No need!
CurldyadG(1,2,:)=-rvec(:,3).*F;
CurldyadG(1,3,:)=rvec(:,2).*F;
CurldyadG(2,1,:)=rvec(:,3).*F;
%CurldyadG(2,2,:)=F.*0; No need!
CurldyadG(2,3,:)=-rvec(:,1).*F;
CurldyadG(3,1,:)=-rvec(:,2).*F;
CurldyadG(3,2,:)=rvec(:,1).*F;
%CurldyadG(3,3,:)=0;
  

 end