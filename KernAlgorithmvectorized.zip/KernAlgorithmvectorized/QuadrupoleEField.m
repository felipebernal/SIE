function valfunEQuadrupole= QuadrupoleEField(omega,~,Q,rtoeval,rsource,muv,epsilonv,sourceinout)
% omega is the frequency at which the quadrupole radiates..
%Q is the quadrupole traceless matrix of3x3
%direction is not used at all...
%rtoeval is the position at which we want to find the E field.
%rsource is the position of the quadrupole
numpoints=size(rtoeval,1);
mu0=1;
eps0=1;
c=1;
epsilon=epsilonv(sourceinout);
mu=muv(sourceinout);
k=omega*sqrt(eps0*epsilon*mu0*mu)/c;
Z0=sqrt(mu0*mu/(eps0*epsilon));
r=rtoeval-repmat(rsource,numpoints,1);
rmag=sqrt(sum(r.^2,2));
rdirect=r./repmat(rmag,1,3);
valfunEQuadrupole=mu*Z0*cross(QuadrupoleHField(omega,1,Q,rtoeval,rsource,muv,epsilonv,sourceinout),rdirect,2);
end