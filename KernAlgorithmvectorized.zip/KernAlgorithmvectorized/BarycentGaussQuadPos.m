%Points in the Barycentric reference frame for doing the quadrature. 
%r=beta_1*v_1+beta_2*v_2+beta_3*v_3
function [rpos1 , rpos2] = BarycentGaussQuadPos(node,SPQ,LineNodes,triangle,positions)

%This are the positions (three coordinates)of the nodes of the triangle

% posnod1=positions(TriToInt(1),:);
% posnod2=positions(TriToInt(2),:);
% posnod3=positions(TriToInt(3),:);
% rpos=SPQ(:,1,:)*posnod1+SPQ(:,2,:)*posnod2+SPQ(:,3,:)*posnod3;

%rpt is 7 Given that SPQ is a 7 position list of 3-vectors 
rpt=size(SPQ,1);
nodenmr=size(node,1);
tri1=LineNodes(node,1);
tri2=LineNodes(node,2);
%%Original version

% p1p=positions(triangle(tri1,1),:);
% p2p=positions(triangle(tri1,2),:);
% p3p=positions(triangle(tri1,3),:);
% 
% p1m=positions(triangle(tri2,1),:);
% p2m=positions(triangle(tri2,2),:);
% p3m=positions(triangle(tri2,3),:);
% 
% 
% P1P=VECrpt3D(p1p,rpt);
% P2P=VECrpt3D(p2p,rpt);
% P3P=VECrpt3D(p3p,rpt);
% 
% P1M=VECrpt3D(p1m,rpt);
% P2M=VECrpt3D(p2m,rpt);
% P3M=VECrpt3D(p3m,rpt);

%%Second version of P1P

% P1P=VECrpt3D(positions(triangle(tri1,1),:),rpt);
% P2P=VECrpt3D(positions(triangle(tri1,2),:),rpt);
% P3P=VECrpt3D(positions(triangle(tri1,3),:),rpt);
% 
% P1M=VECrpt3D(positions(triangle(tri2,1),:),rpt);
% P2M=VECrpt3D(positions(triangle(tri2,2),:),rpt);
% P3M=VECrpt3D(positions(triangle(tri2,3),:),rpt);

%rpt is 7 Given that SPQ is a 7 position list of 3-vectors 
%(SPQ is the matrix that gives the barycentric positions) 

% b1=SPQ(:,1);
% b2=SPQ(:,2);
% b3=SPQ(:,3);
% b1=b1(:,(ones(nodenmr,1)));
% b2=b2(:,(ones(nodenmr,1)));
% b3=b3(:,(ones(nodenmr,1)));
% b1=b1(:);
% b2=b2(:);
% b3=b3(:);
% 
% rpos1=b1(:,ones(3,1)).*P1P+b2(:,ones(3,1)).*P2P+b3(:,ones(3,1)).*P3P;
% rpos2=b1(:,ones(3,1)).*P1M+b2(:,ones(3,1)).*P2M+b3(:,ones(3,1)).*P3M;
% 
% rpos1=repmat(SPQ(:,1),nodenmr,3).*P1P+repmat(SPQ(:,2),nodenmr,3).*P2P+repmat(SPQ(:,3),nodenmr,3).*P3P;
% rpos2=repmat(SPQ(:,1),nodenmr,3).*P1M+repmat(SPQ(:,2),nodenmr,3).*P2M+repmat(SPQ(:,3),nodenmr,3).*P3M;

rpos1=repmat(SPQ(:,1),nodenmr,3).*VECrpt3D(positions(triangle(tri1,1),:),rpt)+...
    repmat(SPQ(:,2),nodenmr,3).*VECrpt3D(positions(triangle(tri1,2),:),rpt)+...
    repmat(SPQ(:,3),nodenmr,3).*VECrpt3D(positions(triangle(tri1,3),:),rpt);
rpos2=repmat(SPQ(:,1),nodenmr,3).*VECrpt3D(positions(triangle(tri2,1),:),rpt)+...
    repmat(SPQ(:,2),nodenmr,3).*VECrpt3D(positions(triangle(tri2,2),:),rpt)+...
    repmat(SPQ(:,3),nodenmr,3).*VECrpt3D(positions(triangle(tri2,3),:),rpt);












