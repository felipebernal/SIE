% This function finds the value of the integral K^{1}_{1} from the paper
% PIER 63, 243-278, 2006

function valKp1p1=Kp1p1(r,node,rpt,LineNodes,triangle,positions)

node=VECrpt1D(node,rpt);

tri1=LineNodes(node,1);
tri2=LineNodes(node,2);

p1p=positions(triangle(tri1,1),:);
p2p=positions(triangle(tri1,2),:);
p3p=positions(triangle(tri1,3),:);
p1m=positions(triangle(tri2,1),:);
p2m=positions(triangle(tri2,2),:);
p3m=positions(triangle(tri2,3),:);

Area1=LineNodes(node,6);
Area2=LineNodes(node,7);
Lshared=LineNodes(node,5);


valKp1p1=...
   (Lshared./(Area1)).*ISp1(r,p1p,p2p,p3p)...
    -(Lshared./(Area2)).*ISp1(r,p1m,p2m,p3m);

%valKp1p1=(3/2)*((Lshared./(Area1)).*ISp1(r,p1p,p2p,p3p)-(Lshared./(Area2)).*ISp1(r,p1m,p2m,p3m));
%This one is wrong cause it doesn't take into account that the divergence
%is only valid in the plane of the triangle, and therefore it has to be
%divergence in the plane and not outside