function valFieldEfinder = FieldEfinder(icon,scattstr,nearfieldstr,rtoeval,omega,epsilonv,muv,direction,pol,rsource,funE,funH,VECQ,matM,LineNodes,triangle,positions,sourceinout)

%Icon tell where to evaluate, if inside of the scatterer or outside of it.
%so far can only be 1 or 2...1 is outside and 2 is inside.
%scatt tells the program whether to find the total field 1 or only the
%scattered field=2.
%Nearfield tells the program to use  a near field propagation of the
%currents to find the field=1 or a farfield one=2

if strcmpi(scattstr,'scatt')
    scatt=2;
else
 if strcmpi(scattstr,'total')
     scatt=1;
 end

end

if strcmpi(nearfieldstr,'near')
    nearfield=1;
else
 if strcmpi(nearfieldstr,'far')
     nearfield=2;
 end

end

 

mu=muv(icon);
epsilon=epsilonv(icon);
k=Ki(icon,omega,epsilonv,muv);

totalnumr=size(rtoeval,1);
totalnumnodes=(size(LineNodes,1));
prefactor=((omega*mu)/(1i));
node=[1:size(LineNodes,1)]';
%Although it looks like the square bracket is not necessary it is 
                            %otherwise we don't get a column vector

%VECQ=TheVectorFiller(omega,direction,pol,rsource,funE,funH,LineNodes,triangle,positions);
alphasbetas=matM\VECQ;
totalnodes=size(alphasbetas,1)/2;
alphas=repmat(alphasbetas(1:totalnodes),totalnumr);
betas=repmat(alphasbetas(totalnodes+1:end),totalnumr);                           
   
%nearfield=2;

if nearfield==1
    
    term1 =-prefactor*alphas(:,ones(3,1)).*EHInt1(k,rtoeval,node,LineNodes,triangle,positions);
    term2=betas(:,ones(3,1)).* EHInt2(k,rtoeval,node,LineNodes,triangle,positions);
    totsum=reshape(sum(reshape(term1+term2,totalnumnodes,[]),1),totalnumr,[]);
    
    
    if icon==1
        if scatt==1
            valFieldEfinder=totsum+funE(omega,direction,pol,rtoeval,rsource,muv,epsilonv,sourceinout);
        else
            valFieldEfinder=totsum;
        end
    else
        valFieldEfinder=-totsum;
    end
    
else
   
    
    
    term1 =-prefactor*alphas(:,ones(3,1)).*EHInt1farfield(k,rtoeval,node,LineNodes,triangle,positions);
    term2=betas(:,ones(3,1)).* EHInt2farfield(k,rtoeval,node,LineNodes,triangle,positions);
    totsum=reshape(sum(reshape(term1+term2,totalnumnodes,[]),1),totalnumr,[]);
    
    
    if icon==1
        if scatt==1
            valFieldEfinder=totsum+funE(omega,direction,pol,rtoeval,rsource,muv,epsilonv,sourceinout);
        else
            valFieldEfinder=totsum;
        end
    else
        valFieldEfinder=-totsum;
    end

    
end
    