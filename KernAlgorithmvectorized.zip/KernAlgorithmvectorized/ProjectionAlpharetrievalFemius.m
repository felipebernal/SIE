function []=ProjectionAlpharetrievalFemius()
%% test program for paper by Rockstuhl
%Metamaterials 5 page 64
%Intended to retrieve dipole moments from radiated cartesian fielods on a
%sphere of arbitrary radius concentric with the origin to which the moments
%are referenced

% sample points - make sure you don't use the north and southpole of the
% unit sphere, there is a 1/sin(theta) in some places

% do not double count along the phi axis
% The result is pretty insensitive against number of sample points (in
% numerical sims you have to worry about noise though)

Nth=25;
Nphi=75;
theta=[1:Nth]/(Nth+1)*pi;
phi=[1:Nphi]/Nphi*2*pi;
[theta phi]=meshgrid(theta,phi);
thetalist=reshape(theta,1,prod(size(theta)));
philist=reshape(phi,size(thetalist));


% test dipole moments -  I use the free dyadic green function
pdips=[ 1 2*i -3 4 -5 2*i ].';k=2*pi/800e-9; r=10e-6;
%pdips=[1 0 1   1 2 3 ].'

% inelegant way to fill up the fields
for p=1:length(thetalist),
    [a G]=FreeDyadG(k,r*[cos(philist(p))*sin(thetalist(p)), sin(philist(p))*sin(thetalist(p)), cos(thetalist(p))]);
     field=G*pdips;
     Efield.x(p)=field(1); Efield.y(p)=field(2); Efield.z(p)=field(3);
end
  
[p m]=retrievedipole(Efield,k,r,thetalist,philist);%
pdips
retrieved=[p m].' 

%end
function [ p m ] = retrievedipole(Efield,k,r,thetalist,philist)
% convert a and b coefficients to cartesian dipole moments
% I tried Rockstuhl Eq. 8 nd then needed to permute his result. Where is
% the i -error in my vector spherical harmonic definition?
%routine works up to a scaling factor thatis unknown
%
n=1 % dipole means retrieve n=1, m=-1,0,1
disp('function retrieveddipole: compared to Metamaterials 5 (2011) 64�73 I do')
disp('not understand the prefactor, nor an 1i, nor a swap of x and y in the definitions')
disp('Possibly: unit system is different. My vector spher harm may be different ?')
disp('If you want to find quadrupole moments too you need to worry a lot about the correct prefactors')
[a b]=retrieveab(n,k,r,Efield,thetalist,philist);
C0=1;
C0=sqrt(2)/(20*k^3);%*sqrt(8*pi/3)*pi^2)  prefactor is bizarre. How can 10 appear as a prefactor ? Works anyway
 
p=C0*[-1i*(a(3)+a(1)),(a(3)-a(1)), -1i*sqrt(2)*a(2)];
m=C0*[-(b(3)+b(1)),-1i*(b(3)-b(1)), -b(2)*sqrt(2)] ;
 

function [a b]=retrieveab(n,k,r,Efield,thetalist,philist)
% Rockstuhl Eq. 7 with crappiest and slowest poossible integration routine
% returns a and b coefficients

% run with n=1 for dipole 
% run with n=2 for quadrupole

integr=0;
integr2=0;
normaliz1=0;
normaliz2=0;
size(Efield.x)
size(thetalist)
for p=1:length(philist)
    [ M N]=CarstenSpherical(n,k,r,thetalist(p),philist(p));
  
    %overlap integral with M functions
    ovrlapr=Efield.x(p)*conj(M(:,1))+Efield.y(p)*conj(M(:,2))+Efield.z(p)*conj(M(:,3));
    ovrlapr=ovrlapr*sin(thetalist(p));
    integr=integr+ovrlapr;
 
    % normalization integral
    ovrlapr=M(:,1).*conj(M(:,1))+M(:,2).*conj(M(:,2))+M(:,3).*conj(M(:,3));  
    normaliz1=normaliz1+ovrlapr*sin(thetalist(p));
    
    
    %overlap integral with N functions
    ovrlapr=Efield.x(p)*conj(N(:,1))+Efield.y(p)*conj(N(:,2))+Efield.z(p)*conj(N(:,3));
    ovrlapr=ovrlapr*sin(thetalist(p));
    integr2=integr2+ovrlapr;
    
    %normaqlization integral
    ovrlapr=N(:,1).*conj(N(:,1))+N(:,2).*conj(N(:,2))+N(:,3).*conj(N(:,3));
     normaliz2=normaliz2+ovrlapr*sin(thetalist(p));
    
end
b =integr./normaliz1;
a =integr2./normaliz2;


function [M N]=AlternativeVectorSpherical(n,k,r,theta,phi)
%% attempt to copy Carsten Rockstuhl from scratch. Does not give the same
%% as attempting to construct the Carsten complex VSH from my original real
%% VSH (See below)
[pnm,dpnm]=PnmAnddPnmvec(n,theta);

bh=Bh(n,k*r);
onrdxi=1./(k*r).*dxi(n,k*r);
mlist=[-n:1:n];
%prefac=sqrt((2*n+1)*factorial(n-abs(mlist))./factorial(n+abs(mlist))).*i.^(n+2*mlist-1)/(2*sqrt(pi));
prefac=1i.^(n+2*mlist-1);
pnm=(exp(1i*mlist*phi).*pnm(abs(mlist)+1)).'*[1 1 1 ];dpnm=(exp(1i*mlist*phi).*dpnm(abs(mlist)+1)).'*[1 1 1 ];
pinm=pnm.*(mlist.'*[1 1 1 ])/sin(theta);taunm=dpnm;
A=unitvectors(theta,phi);
rhat=ones(2*n+1,1)*A(:,1).';

thetahat=ones(2*n+1,1)*A(:,2).';phihat=ones(2*n+1,1)*A(:,3).';

size(rhat)
size(pinm)

M=(1i*pinm.*thetahat-taunm.*phihat)*bh.*(1./prefac.'*[1 1 1 ]);
N=(n*(n + 1)*pnm*bh.*rhat +(taunm.*thetahat+1i*pinm.*phihat)*onrdxi).*(1./prefac.'*[1 1 1 ]);

%%%%%%%%%%%%%%%%%%%% VECTORIZED ME MO NE NO, that do ALL m at once
function [ M N]=CarstenSpherical(n,k,r,theta,phi)
%metamaterials 5 page 65 (2011) paper
% my vector spherical harmonics are real. For m=0 to n, I have two real basis functions (even and odd).
%Those of Rockstuhl are complex, from -n:.. n 
% note that m only sits in the cos mphi, sin mphi. You can debate however
% about the prefactor. IS that defined with |m| or with m ?

% make the complex ones in Rockstuhl Eq. 3
[me1, mo1, ne1, no1,expofac ]=Me1Mo1Ne1No1vec(n,k,r,theta,phi);
M=me1+1i*mo1;
N=ne1+1i*no1;
% rockstuhl proposes to adjust the prefactor. as in Rockstuhl Eq. 5
mlist=[0:n];
prefact=sqrt(factorial(n-mlist)./factorial(n+mlist)).*i.^(n+2*mlist-1);%/(2*sqrt(pi)); 
 
%prefact=1+0*mlist;
Mplus=M.*(prefact.'*[1 1 1 ]);
Nplus=N.*(prefact.'*[1 1 1 ]);

mlist=[0:-1:-n];
% I assume that Rockstuhl doesnt really mean to take factorials with
% negative m, but that he means an absolute sign around the m.
% so do not use the following:

%prefact=sqrt((2*n+1)*factorial(n-mlist)./factorial(n+mlist)).*i.^(n+2*mlist-1)/(2*sqrt(pi));
%p
M=me1-1i*mo1;
N=ne1-1i*no1;

M=M.*(prefact.'*[1 1 1 ]);
N=N.*(prefact.'*[1 1 1 ]);

M=[flipud(M); Mplus(2:n+1,:)];  % don't take the m=0 one twice, so start at index=2
N=[flipud(N); Nplus(2:n+1,:)];

% nowthe M and N are still in rhat, thetahat and phihat coordinates
% I want to insert Cartesian fields to analyze.
% map the M and N through basis transform.

    A=(unitvectors(theta,phi));
    for  m=1:2*n+1,
        M(m,1:3)=A*M(m,1:3).';
        N(m,1:3)=A*N(m,1:3).';

    end



%  end

function [me1, mo1, ne1, no1,expofac ]=Me1Mo1Ne1No1vec(n,k,r,theta,phi)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%Start low-level mathematical functions

%vector spherical harmonics.
%These expressions for the spherical harmonics agree with the expressions in Bohren and Huffman on p. 89.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% The  functions with 1 at end of name are defined in Tai by eq. between
%%% 10.22 and 10.23  This definition is like 10.5 ane 10.6 except that now
%%% psi is not in terms of j (bessel) but in terms of h (Hankel
%%%
%%%  Going from 10.5, 10.6 to 10.9 and 10.10 uses no mathematics specific
%%%  for j or h, but only for the curl in spherical coordinates, and the
%%%  fact that the functions are derived from a psi * Rvec, i.e. a vector
%%%  function with only component along rhat
%%%
%%% the functions with and without 1 are hence just identical except for
%%% the substitution of j's and h's

%% CHECKED as the same but 4 times quicker than separate fctions.

[pnm,dpnm]=PnmAnddPnmvec(n,theta);


bh=Bh(n,k*r);
onrdxi=1./(k*r).*dxi(n,k*r);
m=[0:n];

expofac=floor(log10(max(abs(dpnm)))+log10(max(abs(onrdxi)))) ;
expofac=1;
bh=bh*10^(-expofac);
onrdxi=onrdxi*10^(-expofac);


me1(1:n+1,1)=0*m;    %% rhat component
me1(1:n+1,2)=-m.*pnm.*bh.*sin(m*phi)./sin(theta);   %% thetahat
me1(1:n+1,3)=-bh.*dpnm.*cos(m*phi);   %% phihat

mo1(1:n+1,1)=0*m;
mo1(1:n+1,2)=m.*pnm.*bh.*cos(m*phi)./sin(theta);
mo1(1:n+1,3)=-bh.*dpnm.*sin(m*phi);

ne1(1:n+1,1)=n*(n+1)./(k*r).*bh.*pnm.*cos(m*phi);   %% rhat component
ne1(1:n+1,2)=onrdxi*dpnm.*cos(m*phi);       %% thethat
ne1(1:n+1,3)=-onrdxi*m.*pnm./sin(theta).*sin(m*phi); %% phihat

no1(1:n+1,1)=n*(n+1)./(k*r).*bh.*pnm.*sin(m*phi);
no1(1:n+1,2)=onrdxi*dpnm.*sin(m*phi);
no1(1:n+1,3)=onrdxi*m.*pnm./sin(theta).*cos(m*phi);



function [me1, mo1, ne1, no1 ]=Me1Mo1Ne1No1(m,n,k,r,theta,phi)
%% CHECKED as the same but 4 times quicker than separate fctions.

pnm=Pnm(n,m,theta);
dpnm=dPnm(n,m,theta);
bh=Bh(n,k*r);
onrdxi=1./(k*r).*dxi(n,k*r);

me1(1)=0;    %% rhat component
me1(2)=-m*pnm.*bh.*sin(m*phi)./sin(theta);   %% thetahat
me1(3)=-bh.*dpnm.*cos(m*phi);   %% phihat

mo1(1)=0;
mo1(2)=m*pnm.*bh.*cos(m*phi)./sin(theta);
mo1(3)=-bh.*dpnm.*sin(m*phi);

ne1(1)=n*(n+1)./(k*r).*bh.*pnm.*cos(m*phi);   %% rhat component
ne1(2)=onrdxi*dpnm.*cos(m*phi);       %% thethat
ne1(3)=-onrdxi*m.*pnm./sin(theta).*sin(m*phi); %% phihat

no1(1)=n*(n+1)./(k*r).*bh.*pnm.*sin(m*phi);
no1(2)=onrdxi*dpnm.*sin(m*phi);
no1(3)=onrdxi*m.*pnm./sin(theta).*cos(m*phi);



function [out]=Me1(m,n,k,r,theta,phi) %S1   %% FEMIUS checked against Eq. 10.9 Tai, Ed. 2, subst Bj and Bh
%Expression for the vector spherical harmonics '1' in terms of spherical Hankel function of the first kind h_n.
out(1)=0;
out(2)=-m*Pnm(n,m,theta).*Bh(n,k*r).*sin(m*phi)./sin(theta);
out(3)=-Bh(n,k*r).*dPnm(n,m,theta).*cos(m*phi);

function [out]=Mo1(m,n,k,r,theta,phi) %S2  %% FEMIUS checked against Eq. 10.9 Tai, Ed. 2, subst Bj and Bh
%Expression for the vector spherical harmonics '2' in terms of spherical Hankel function of the first kind h_n.
out(1)=0;
out(2)=m*Pnm(n,m,theta).*Bh(n,k*r).*cos(m*phi)./sin(theta);
out(3)=-Bh(n,k*r).*dPnm(n,m,theta).*sin(m*phi);

function [out]=Ne1(m,n,k,r,theta,phi) %S3  %% FEMIUS checked against Eq. 10.9 Tai, Ed. 2, subst Bj and Bh
%Expression for the vector spherical harmonics '3' in terms of spherical Hankel function of the first kind h_n.
out(1)=n*(n+1)./(k*r).*Bh(n,k*r).*Pnm(n,m,theta).*cos(m*phi);
out(2)=1./(k*r).*dxi(n,k*r)*dPnm(n,m,theta).*cos(m*phi);
out(3)=-1./(k*r).*dxi(n,k*r)*m.*Pnm(n,m,theta)./sin(theta).*sin(m*phi);

function [out]=No1(m,n,k,r,theta,phi) %S4  %% FEMIUS checked against Eq. 10.9 Tai, Ed. 2, subst Bj and Bh
%Expression for the vector spherical harmonics '4' in terms of spherical Hankel function of the first kind h_n.
out(1)=n*(n+1)./(k*r).*Bh(n,k*r).*Pnm(n,m,theta).*sin(m*phi);
out(2)=1./(k*r).*dxi(n,k*r)*dPnm(n,m,theta).*sin(m*phi);
out(3)=1./(k*r).*dxi(n,k*r)*m.*Pnm(n,m,theta)./sin(theta).*cos(m*phi);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [me, mo, ne, no ]=MeMoNeNo(m,n,k,r,theta,phi)
%% CHECKED as the same but 4 times quicker than separate fctions.
pnm=Pnm(n,m,theta);
dpnm=dPnm(n,m,theta);
bj=Bj(n,k*r);
onrdpsi=1./(k*r).*dpsi(n,k*r);

me(1)=0;    %% rhat component
me(2)=-m*pnm.*bj.*sin(m*phi)./sin(theta);   %% thetahat
me(3)=-bj.*dpnm.*cos(m*phi);   %% phihat

mo(1)=0;
mo(2)=m*pnm.*bj.*cos(m*phi)./sin(theta);
mo(3)=-bj.*dpnm.*sin(m*phi);

ne(1)=n*(n+1)./(k*r).*bj.*pnm.*cos(m*phi);   %% rhat component
ne(2)=onrdpsi*dpnm.*cos(m*phi);       %% thethat
ne(3)=-onrdpsi*m.*pnm./sin(theta).*sin(m*phi); %% phihat

no(1)=n*(n+1)./(k*r).*bj.*pnm.*sin(m*phi);
no(2)=onrdpsi*dpnm.*sin(m*phi);
no(3)=onrdpsi*m.*pnm./sin(theta).*cos(m*phi);



function [out]=Me(m,n,k,r,theta,phi) %S5    %% FEMIUS checked against Eq. 10.9 Tai, Ed. 2
%Expression for the vector spherical harmonics '1' in terms of spherical Bessel function of the first kind j_n.
out(1)=0;    %% rhat component
out(2)=-m*Pnm(n,m,theta).*Bj(n,k*r).*sin(m*phi)./sin(theta);   %% thetahat
out(3)=-Bj(n,k*r).*dPnm(n,m,theta).*cos(m*phi);   %% phihat
Me=out;

function [out]=Mo(m,n,k,r,theta,phi) %S6   %% FEMIUS checked against Eq. 10.9 Tai, Ed. 2
%Expression for the vector spherical harmonics '2' in terms of spherical Bessel function of the first kind j_n.
out(1)=0;
out(2)=m*Pnm(n,m,theta).*Bj(n,k*r).*cos(m*phi)./sin(theta);
out(3)=-Bj(n,k*r).*dPnm(n,m,theta).*sin(m*phi);

function [out]=Ne(m,n,k,r,theta,phi) %S7   %% FEMIUS checked against Eq. 10.10 Tai, Ed. 2
%Expression for the vector spherical harmonics '3' in terms of spherical Bessel function of the first kind j_n.
%
% Note: here Tai speaks of 1/(kappa R)* D[R*jn(kappa*R],R]. The Chain rule
% says that this is 1/(kappa R)*dpsi(x=kappaR) with dpsi(x)=D[x*jn[x],x]
out(1)=n*(n+1)./(k*r).*Bj(n,k*r).*Pnm(n,m,theta).*cos(m*phi);   %% rhat component
out(2)=1./(k*r).*dpsi(n,k*r)*dPnm(n,m,theta).*cos(m*phi);       %% thethat
out(3)=-1./(k*r).*dpsi(n,k*r)*m.*Pnm(n,m,theta)./sin(theta).*sin(m*phi); %% phihat


function [out]=No(m,n,k,r,theta,phi) %S8   %% FEMIUS checked against Eq. 10.10 Tai, Ed. 2
%Expression for the vector spherical harmonics '4' in terms of spherical Bessel function of the first kind j_n.
out(1)=n*(n+1)./(k*r).*Bj(n,k*r).*Pnm(n,m,theta).*sin(m*phi);
out(2)=1./(k*r).*dpsi(n,k*r)*dPnm(n,m,theta).*sin(m*phi);
out(3)=1./(k*r).*dpsi(n,k*r)*m.*Pnm(n,m,theta)./sin(theta).*cos(m*phi);


%Next six functions: Legendre, Bessel, and Hankel.
function [out]=Pnm(n,m,x)   %LBH1
%Expression for the associated Legendre function of the first kind of order (n,m) P_nm, Tai, p. 199.
%This function is based on the Matlab function 'Legendre'.
if(m>n), %% can happen in dPnm, in which case you should get 0.
    out=0*x;
else
    A=legendre(n,cos(x));
    %Legendre exports data for m'=0, m'=1, ..., m'=m. Subsequently m'=m is selected:
    out=A(m+1,:); %% FEMIUS 28 sep 2006 OK. SHIFT by 1 for array index starting at 1 not at 0
end

function [out]=dPnm(n,m,x)  %LBH2  %% FEMIUS 28 sep 2006 OK
%Expression for the first-order derivative of the associated Legendre function of the first kind of order (n,m) P_nm.
out=(-(m+n)*Pnm(n-1,m,x)+n*cos(x).*Pnm(n,m,x))./sin(x);%


%function [out]=Pnmvec(n,x)
%out=legendre(n,cos(x)).';

%function [out]=dPnmvec(n,x)
%mlist=[0:n];
%out=(-(mlist+n).*[Pnmvec(n-1,x), 0]+n*cos(x).*Pnmvec(n,x))./sin(x);



function [out1,out2]=PnmAnddPnmvec(n,x)
mlist=[0:n];
out1=legendre(n,cos(x)).';
out2=[legendre(n-1,cos(x)).',0];
out2=(-(mlist+n).*out2+n*cos(x).*out1)./sin(x);


function [out]=Bj(n,x)      %LBH3  %% FEMIUS CHECKED 28-9-2006
%Expression for the spherical Bessel function j_n of order n in terms of the half-order cylindrical Bessel function.
%(Tai, p. 199)
out=sqrt(pi./(2*x)).*besselj(n+0.5,x); %% FEMIUS 28 sep 2006 OK

function [out]=dBj(n,x)      %LBH4  %% FEMIUS CHECKED 28-9-2006
%Expression for the first-order derivative of the spherical Bessel function j_n of order n.
%%Directly from Mathematica
out=-0.5*sqrt(pi/2)*(1./x).^(3/2).*besselj(n+0.5,x)+0.5*sqrt(pi/2)*(1./x).^(1/2).*(besselj(n-0.5,x)-besselj(n+1.5,x));

function [out]=Bh(n,x)      %LBH5  %% FEMIUS CHECKED 28-9-2006
%Expression for the spherical Hankel function h_n of the first kind of order n in terms of the half-order cylindrical Bessel function.
%(Tai, p. 199 combined with Wolfram Mathworld 'Hankel function of the first kind')
out=sqrt(pi./(2*x)).*(besselj(n+0.5,x)+i*bessely(n+0.5,x)); %% FEMIUS 28 sep 2006 OK

function [out]=dBh(n,x)     %LBH6  %% FEMIUS CHECKED 28-9-2006
%Expression for the first-order derivative of the spherical Hankel function h_n of the first kind of order n.
%% FEMIUS 28/9/2006
out=0.5*sqrt(pi/2.0).*((1./x).^(1.5)).*(...
    -besselj(0.5 + n, x) - i* bessely(0.5+ n, x) + x.*(besselj(-0.5 + n, x) -...
    besselj(1.5 + n, x) + i*(...
    bessely(-0.5 + n, x) - bessely(1.5 + n, x))));


%Next four functions: 'Riccati-Bessel functions' (Bohren and Huffman, p. 101)
%Equations 4.19 and 4.20 in Bohren and Huffman on page 89 explain the role of psi, xi, dpsi, and dxi:
function [out]=psi(n,x)   %RB1  %% FEMIUS CHECKED 28-9-2006
%Expression for Riccati-Bessel function '1'
out=x.*Bj(n,x);

function [out]=xi(n,x)    %RB2 %% FEMIUS CHECKED 28-9-2006
%Expression for Riccati-Bessel function '2'
out=x.*Bh(n,x);

function [out]=dpsi(n,x)  %RB3 %% FEMIUS CHECKED 28-9-2006
%Expression for the first-order derivative of Riccati-Bessel function '1'
out=0.5*sqrt(pi/2)*sqrt(1./x).* (x.*besselj( -0.5 + n, x) + besselj(0.5+ n,x)...
    - x.*besselj(1.5 + n, x));   %% OLDER VERSION NOT SIMPLIFIED
%out=(sqrt(pi/2.)*sqrt(1./x).*besselj(0.5 + n,x))/2. + ...
%   (sqrt(pi/2.)*(besselj(-0.5 + n,x) - besselj(1.5 + n,x)))./(2.*sqrt(1./x));

function [out]=dxi(n,x)   %RB4  %% FEMIUS CHECKED 28-9-2006
%Expression for the first-order derivative of Riccati-Bessel function '2'
out=0.5*sqrt(pi/2)*sqrt(1./x).*(x.*besselj(n-0.5,x)+besselj(n+0.5,x)-x.*besselj(n+1.5,x)+...
    i*x.*bessely(n-0.5,x)+i*bessely(n+0.5,x)-i*x.*bessely(n+1.5,x));

function [out]=mycross(a,b)

out=zeros(size(a));
out(1)=a(2)*b(3)-a(3)*b(2);
out(2)=a(3)*b(1)-a(1)*b(3);
out(3)=a(1)*b(2)-a(2)*b(1);

function [out]=mydot(a,b);
out=a(1)*b(1)+a(2)*b(2)+a(3)*b(3);

function [A]=unitvectors(theta,phi)  %% FEMIUS CHECKED 28-9-2006
%Expression for the unit vectors in spherical coordinates.
%See for example Tai p.3 or Wolfram Mathworld (Spherical coordinates).
%Watch out!: theta and phi are interchanged in Mathworld compared to
%the Tai. The definitions in Bohren and Huffman (p. 85) are the same as in Tai
%%  FEMIUS: physicists have theta from 0 to pi polar angle and phi from 0 to 2*pi azimuthal
%%  mathematicians and mathworld like to reverse symbols, and shift angle
%%  over pi/2. We are physicists.
A=[cos(phi)*sin(theta), sin(phi)*sin(theta), cos(theta);...
    cos(theta)*cos(phi),cos(theta)*sin(phi),-sin(theta);...
    -sin(phi),cos(phi),0]';



%columns 1 is rhat (easy check)
%column 2 is thetahat (is along r-comp in xy plane and points downward
%when theta is pi/2, points to x when theta=0.
%column3 is phihat.   Indeed: phihat is in the xy plane, while thetahat
%(easy check)


%%End low-level mathematical functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

