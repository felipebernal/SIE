% this function is the first notsmooth term of the first integral for
% finding the Total electric or magnetic field.

function valEHInt1_1NTSMTH= EHInt1_1NTSMTH(K,rtri,node,LineNodes,triangle,positions)

totalnodes=size(node,1);
totalr=size(rtri,1);
rtrirpt=VECrpt3D(rtri,totalnodes);
nodesrpt=repmat(node,totalr,1);

tri1=LineNodes(nodesrpt,1);
tri2=LineNodes(nodesrpt,2);

p1p=positions(triangle(tri1,1),:);
p2p=positions(triangle(tri1,2),:);
p3p=positions(triangle(tri1,3),:);
p1m=positions(triangle(tri2,1),:);
p2m=positions(triangle(tri2,2),:);
p3m=positions(triangle(tri2,3),:);

Lshared=LineNodes(nodesrpt,5);
Area1=LineNodes(nodesrpt,6);
Area2=LineNodes(nodesrpt,7);

%prefactout=((3*Lshared)/(8*pi*K^2));
%Checking this prefactor cause given tthat RWG is a picewise function it is possible
%that the divergence must be only taken over the plane and therefore the 3/2 factor wouldn't be correct
prefactout=((2*Lshared)/(8*pi*K^2));
prefact1=(1./Area1);
prefact2=(1./Area2);

valEHInt1_1NTSMTH=prefactout(:,ones(3,1)).*(prefact1(:,ones(3,1)).*(((K^2)/2)* Kp1p3(rtrirpt,p1p,p2p,p3p)- Km1p3(rtrirpt,p1p,p2p,p3p))...
                     -prefact2(:,ones(3,1)).*(((K^2)/2)* Kp1p3(rtrirpt,p1m,p2m,p3m)- Km1p3(rtrirpt,p1m,p2m,p3m)));
