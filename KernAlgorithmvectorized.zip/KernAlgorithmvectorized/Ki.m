function valK=Ki(i,omega,epsilon,mu)

%This function will define the valuo of k which is the most important when
%defining the index i in Gi and Dmni and Kmni...(see reference paper)
%Now up to here it is only defined for only two materials, but in principle
%it should be possible to define more than 2....not yet sure how though.


valK=sqrt(omega^2*epsilon(i)*mu(i));
    