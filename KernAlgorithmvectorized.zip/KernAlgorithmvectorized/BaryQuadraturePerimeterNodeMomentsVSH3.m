%%Quadrature based on the positions, weights and functions
%This function does the quadrature of the fnction "funcion" over the region
%made by the two triangles in the node list.
%it requires the positions in both triangles rpos1 and rpos2 which com from
%the function "BarycentGaussQuadPos(node,SPQ,LineNodes,triangle,positions)"


%This quadrature is useful for getting the third and the second integrals
%a3 and a2 necessary to retrieve the values of the electric and magnetic
%moments from the currents.
function quadval= BaryQuadraturePerimeterNodeMomentsVSH3(l,m,k,rposPer1,rposPer2,lenghts1,lenghts2,funcion,noderpt,rpt,LineNodes,triangle,positions,dimfun)



%Area1=LineNodes(noderpt,6);
%Area2=LineNodes(noderpt,7);

reptnmr=dimfun;

nodeevalnumbrpt=6*size(noderpt,1);


%Since we are only doing a single node gaussian quadrature then the weigths
%are equal to one in this case.

weigthsrep=0.5;
%valTerm1=funcion(l,m,rposPer1,noderpt,rpt,k,1,LineNodes,triangle,positions).*weigthsrep(:,ones(reptnmr,1));
%valTerm2=funcion(l,m,rposPer2,noderpt,rpt,k,2,LineNodes,triangle,positions).*weigthsrep(:,ones(reptnmr,1));


valTerm1=funcion(l,m,rposPer1,noderpt,rpt,k,1,LineNodes,triangle,positions).*weigthsrep;
valTerm2=funcion(l,m,rposPer2,noderpt,rpt,k,2,LineNodes,triangle,positions).*weigthsrep;


quadval=...
 reshape((sum( reshape( lenghts1(:,ones(reptnmr,1)).*reshape(sum(reshape(valTerm1,rpt,[]),1),nodeevalnumbrpt,[]),6,[]),1)+...
   sum( reshape( lenghts2(:,ones(reptnmr,1)).*reshape(sum(reshape(valTerm2,rpt,[]),1),nodeevalnumbrpt,[]),6,[]),1)),[],dimfun);


%%Quadrature based on the positions, weights and functions
%This function does the quadrature of the fnction "funcion" over the region
%made by the two triangles in the node list.
%it requires the positions in both triangles rpos1 and rpos2 which com from
%the function "BarycentGaussQuadPos(node,SPQ,LineNodes,triangle,positions)"


