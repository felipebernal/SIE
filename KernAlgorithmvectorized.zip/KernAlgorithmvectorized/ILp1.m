% This function finds the value of the integral I^{L}_{1} from the paper
% PIER 63, 243-278, 2006

function valIL =ILp1(r,pa,pb)

numr=size(r,1);
%Pb=pb(ones(numr,1),:);
%Pa=pa(ones(numr,1),:);
%this is tony's trick to transform pa and b in a column of 3-vectors
%of pa and b with size of size(r,1) positions.

Rp=sqrt(sum((r-pb).^2,2));
Rm=sqrt(sum((r-pa).^2,2));
%sqrt(sum((A).^2,2)) is the vectorized norm of a a column of vectors


norms=sqrt(sum((pb-pa).^2,2));
s=(pb-pa)./norms(:,ones(3,1));
%S=s(ones(numr,1),:);
sp= sum((pb-r).*s,2);
sm= sum((pa-r).*s,2);


R02=Rm.^2-sm.^2;



valIL=zeros(numr,1);
firstpart=(1/2)*(sp.*Rp-sm.*Rm);
combinedpart=(R02/2).*ILm1(r,pa,pb)+(1/2)*(sp.*Rp-sm.*Rm);
valIL(logical(R02<=1e-15))=firstpart(logical(R02<=1e-15));
valIL(logical(R02>1e-15))=combinedpart(logical(R02>1e-15));

%This part uses logical indexing to do the following if
%but vectorized. it is not R02==0 but <1e-15 in order to avoid problems.
%if R02==0
%    
%    valIL=(1/2)*(sp.*Rp-sm.*Rm);
%else
%    valIL=(R02/2).*ILm1(r,pa,pb)+(1/2)*(sp.*Rp-sm.*Rm);
%end


%%Semi Checked


