function valepsilon=epsilonPd(lambda)

%lambda=1239.84187/omega;%with this number we pass from eV to nm

Palladiumrefractiveindex=load('palladiumNK.mat');
nt=Palladiumrefractiveindex.palladiumNK;
Lambdatable=nt(:,1)*1000;
n=nt(:,2)+1i*nt(:,3);
ninter=interp1(Lambdatable,n,lambda);
valepsilon=ninter.^2;

end
