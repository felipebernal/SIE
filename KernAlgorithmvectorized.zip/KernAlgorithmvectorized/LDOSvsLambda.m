function  LDOSline=LDOSvsLambda(name)

%___________Important_____Is the plane or line close or far from the
%scatterer?

howclose='near';%It can also be 'far' this one will change the way the field is calculated.

vectorfillernear=1; %This is just a variable to check two different ways to fill TheVector.
%In the first one the smooth and not smooth part of the dipole fieldare separated '1' and for
%'2' this is not separated.

Position=[10,0,0];
minlambda=15000;
maxlambda=20000;
numpoints=20;
lambdas=linspace(minlambda, maxlambda,numpoints).';

%omega=2*pi/(10000/1000); %1microns wavelength
%omega=0.10;

%omega=2*pi/(10000/1000); %Minisphere 10 nm
%omega=2*pi/(1507/1000); %SplitRing
%omega=2*pi/(1528/1000); %SplitRingRefined



%omega=2*pi/(1544.3/1000); %SplitRingCurved
%omega=2*pi/7; %test bigsphere
%omega=2*pi/0.5; %test smallsphere


%omega=2*pi/(62500/1000); %DSRR
%omega=2*pi/(16500/1000); %DGSRR px electric resonance
%omega=2*pi/(25000/1000); %DGSRR py resonance
%omega=2*pi/(23250/1000); %DGSRR  resonance

%omega=2*pi/(18000/1000); %Omega
%omega=2*pi/(2500/1000); %CasimirOmega

%omega=2*pi/(15404/1000); %Omega1
%omega=2*pi/(16803/1000); %Omega2
%omega=2*pi/(16063/1000); %Omega3
%omega=2*pi/(16411/1000); %Omega4
%omega=2*pi/(15475/1000); %Omega5
%omega=2*pi/(15559/1000); %OmegaSmothedMedium

%lambda=(2*pi/omega)*1000;
%omega=0.1;

c=1;

epsilonv=[1;3];
%epsilonv=[1;Gold(1000*(2*pi)/omega)]; %This one suposes that a=1micron (the unit of lenght)
%epsilonv=[1;2];
muv=[1;1];
%muv=[1;1+100i];

%dipole characteristics
direction=[0 1 0];
%pol=[0 0 1]; These two are looped inside the program.
%rsource=[0 0.2 0];
sourceinout=1;%1 is out 2 is in.


%Radius=1.00000;
numberofpoints=100;
numberoftilesMatrix=2;
icont=1;
z=0;
numberoftiles=10;
xmin=-1;
xmax=1;
xstep=0.1;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
%dia=date; %This is done so that if the simulation takes more than a day then you don't have problems saving the data.
dia='14-Mar-2012';


poldipolevector=[1,0,0;0,1,0;0,0,1];
LDOSline=zeros(numpoints,3);
LDOSlinetemp=zeros(1,3);
mu=muv(sourceinout);
mu0=1;
c=1;


for cont=1:numpoints
    cont
    omega=2*pi/(lambdas(cont)/1000);
    k=omega/c;
    
    
    if exist([directory, dia,'\',name,'_',int2str(lambdas(cont)),'.mat'])==0
        
        [LineNodes,triangle,positions]= reader(name);
        TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
        save([directory, dia,'\',name,'_',int2str(lambdas(cont)),'.mat'],'TheMat','LineNodes','triangle','positions');
        
    else
        Struct=load([directory, dia,'\',name,'_',int2str(lambdas(cont)),'.mat']);
        TheMat=Struct.TheMat;
        % LineNodes=Struct.LineNodes;
        %triangle=Struct.triangle;
        %positions=Struct.positions;
        [LineNodes,triangle,positions]= reader(name);
        clear('Struct');
        
    end
    
    
    
    for contpoldipole=1:3
        contpoldipole
        pol=poldipolevector(contpoldipole,:);
        rsource=Position;
        if vectorfillernear==1
            TheV=TheVectorFillerForLDOS(omega, direction,pol,rsource,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
        else
            TheV=TheVectorFiller(omega,direction,pol,rsource,@DipoleEField,@DipoleHField,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
        end
        fieldsourceposition=FieldEfinder(1,'scatt',howclose,rsource,omega,epsilonv,muv,direction,pol,rsource,@DipoleEField,@DipoleHField,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
        %LDOSlinetemp(contpos)=(6*omega/(pi*c^2))*imag((1/(mu0*mu*omega^2))*sum(fieldsourceposition.*pol,2));
        %LDOSlinetemp(1,contpoldipole)=(6*pi/(omega/c))*(1/(mu0*mu*omega^2))*imag(sum(fieldsourceposition.*pol,2))+1/3;
        LDOSlinetemp(1,contpoldipole)=(6*pi/(omega/c))*(1/(mu0*mu*omega^2))*imag(sum(fieldsourceposition.*pol,2))+1;
    end
    LDOSline(cont,:)=LDOSlinetemp(:);
end
LDOSline=[lambdas,LDOSline];
save([directory, dia,'\',name,'LDOSline.mat'],'LDOSline','minlambda','maxlambda','numpoints');



   
   
   
   
   
  