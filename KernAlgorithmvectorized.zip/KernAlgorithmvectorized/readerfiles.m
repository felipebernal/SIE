function matrixvalues=readerfiles
matrixvalues=zeros(1801,4,20);
cont=1;
%read the mie files

for l=10:10:200
matrixvalues(:,:,cont)=load(['\\nanorfsrv\Users\Bernal\Simulations\31-Mar-2011\MIEFILESR0.009964\',int2str(l),'nm.txt'],'-ascii');
%load([directory, dia,'\',name,'_',int2str(lambda),'_Matrix','.mat']);
matrixvalues(:,2:4,cont)=matrixvalues(:,2:4,cont)*((l/1000)^2)/pi;
matrixvalues(:,1,cont)=matrixvalues(:,1,cont)*(pi)/180;
cont=cont+1;

end

%create with TheMat and TheV the bistatic thingy.
