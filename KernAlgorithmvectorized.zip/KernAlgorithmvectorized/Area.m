%This function gves the area of the triangle by getting the number of the
%triangle, the matrix with the nodes of the triangle and the position of
%the nodes.

function valarea=Area(ntria,triangle,positions)
p1=positions(triangle(ntria,1),:);
p2=positions(triangle(ntria,2),:);
p3=positions(triangle(ntria,3),:);
valarea=(1/2)*norm(cross((p2-p1),(p3-p1)));