% this function is the sum of the terms in the first integral for
% finding the Total electric or magnetic field.

function valEHInt1SMTH= EHInt1SMTH(k,rtoeval,node,LineNodes,triangle,positions)

valEHInt1SMTH= EHInt1_1SMTH(k,rtoeval,node,LineNodes,triangle,positions)+EHInt1_2SMTH(k,rtoeval,node,LineNodes,triangle,positions);

