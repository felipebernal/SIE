function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
            ...[sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
        ...   [Totalelectricdipole,Totalmagneticdipole,alpha,NeeONhh,fvaltol,moments]=runnerBistatic(Radius,name)
            [Totalelectricdipole,Totalmagneticdipole,Dipoles,Quadrupoles,alpha]=runnerBistaticAluKerker(Radius)

        
name0='minispherefinefineLambdaO100';
%name='minisphererefinedIII';  
name='minispherefinefine';  

%omega=2*pi/(10000/1000); %1microns wavelength
%omega=0.10;

%omega=2*pi/(10000/1000); %Minisphere 10 nm
%omega=2*pi/(1507/1000); %SplitRing
%omega=2*pi/(1528/1000); %SplitRingRefined
omega=2*pi/(1000/1000); 

%omega=2*pi/(62500/1000); %DSRR
%omega=2*pi/(16500/1000); %DGSRR px electric resonance
%omega=2*pi/(25000/1000); %DGSRR py resonance
%omega=2*pi/(23250/1000); %DGSRR  resonance

%omega=2*pi/(18000/1000); %Omega
%omega=2*pi/(2500/1000); %CasimirOmega

%omega=2*pi/(15404/1000); %Omega1
%omega=2*pi/(16803/1000); %Omega2
%omega=2*pi/(16063/1000); %Omega3
%omega=2*pi/(16411/1000); %Omega4
%omega=2*pi/(15475/1000); %Omega5
%omega=2*pi/(15559/1000); %OmegaSmothedMedium

lambda=(2*pi/omega)*1000;


%omega=0.1;
c=1;
k=omega/c;
%epsilonv=[1;12];
%epsilonv=[1;0.142857];%Lambda/100
%epsilonv=[1;0.315];%Lambda/4
%epsilonv=[1;0.121];%Lambda/20
epsilonv=[1;0.143];%Lambda/100

muv=[1;3];

%epsilonv=[1;1];
%muv=[1;1];

direction=[0 1 0];
pol=[1 0 0];

% direction=[1 0 0];
% pol=[0 1 0];


rsource=[0 0 0];


%Radius=1.00000;
numberofpoints=100;
numberoftilesMatrix=2;

icont=1;
z=0;
numberoftiles=10;
xmin=-1;
xmax=1;
xstep=0.1;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date; %This is done so that if the simulation takes more than a day then you don't have problems saving the data.
%dia='28-Oct-2011';
if exist([directory, dia])==0
    mkdir([directory, dia]);
    [LineNodes,triangle,positions]= reader(name);
    TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
   save([directory, dia,'\',name0,'.mat'],'TheMat','LineNodes','triangle','positions');
    TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
     [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);
else
    if exist([directory, dia,'\',name0,'.mat'])==0
    
        [LineNodes,triangle,positions]= reader(name);
        TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
        save([directory, dia,'\',name0,'.mat'],'TheMat','LineNodes','triangle','positions');
        TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
       [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);
    
    else
        Struct=load([directory, dia,'\',name0,'.mat']);
        TheMat=Struct.TheMat;
       % LineNodes=Struct.LineNodes;
        %triangle=Struct.triangle;
        %positions=Struct.positions;
         [LineNodes,triangle,positions]= reader(name);
        
        clear('Struct');
               
       TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
       [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);
   end
end
    
     
     
     Escatsqrparallel=sum(vecplotparallel.*conj(vecplotparallel),2);%sum(abs(vecplotparallel).^2,2);
     sigmascatparallel=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2*Escatsqrparallel];
     
     Escatsqrperpendm=sum(vecplotperpedicular.*conj(vecplotperpedicular),2);    %sum(abs(vecplotperpedicular),2);
     sigmascatperpend=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* Escatsqrperpendm];
     
          
    save([directory, dia,'\',name0,'DrawingparallelperpendMatrix.mat'],'sigmascatparallel','sigmascatperpend'); 
    
    %polar(sigmascatparallel(:,1),sigmascatparallel(:,2));
    %polar(sigmascatperpend(:,1),sigmascatperpend(:,2));
    figure(1);
    polar([sigmascatparallel(:,1);NaN;sigmascatperpend(:,1)],[sigmascatparallel(:,2);NaN;sigmascatperpend(:,2)]); 
    figure(2);
     polar(sigmascatparallel(:,1),sigmascatparallel(:,2)); 
     figure(3)
      polar(sigmascatperpend(:,1),sigmascatperpend(:,2)); 
      [Totalelectricdipole,Totalmagneticdipole]=effectivedipolecalculator(k,epsilonv,muv,TheMat,TheV,name);
       abtotma=abs(Totalmagneticdipole);
abtotel=abs(Totalelectricdipole);
abtot=[abtotel;abtotma];
dipotot=[Totalelectricdipole;Totalmagneticdipole];
figure(4)
quiver3([0;0],[0;0],[0;0],abtot(:,1),abtot(:,2),abtot(:,3))
%           [alpha,NeeONhh,fvaltol]=PolarizabilityTensorCalculator(k,epsilonv,muv,TheMat,name);    
  alpha=PolarizabilityTensorCalculator(k,epsilonv,muv,TheMat,name);    
savefiles=0;


[Dipoles,Quadrupoles]=VectorSphericalHarmonicsMultipoleRetrieval(k,epsilonv,muv,TheMat,TheV,direction,pol,rsource,name);

if savefiles==0

else
    alphaReal=real(alpha);
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\PolarizabilityReal',name0,'_',num2str(lambda) ,'.txt'], 'alphaReal','-ascii');
alphaIm=imag(alpha);
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\Polarizability',name0,'_',num2str(lambda) ,'.txt'], 'alphaIm','-ascii');
end
    
    

    