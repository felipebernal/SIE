% This function finds the value of the integral K^{-1}_{4} from the paper
% PIER 63, 243-278, 2006

function valKm1p4=Km1p4(r,node,rpt,LineNodes,triangle,positions)


node=VECrpt1D(node,rpt);
tri1=LineNodes(node,1);
tri2=LineNodes(node,2);


nshnode1=positions(triangle(sub2ind(size(triangle), LineNodes(node,1), LineNodes(node,3))),:);
nshnode2=positions(triangle(sub2ind(size(triangle), LineNodes(node,2), LineNodes(node,4))),:);

p1p=positions(triangle(tri1,1),:);
p2p=positions(triangle(tri1,2),:);
p3p=positions(triangle(tri1,3),:);
p1m=positions(triangle(tri2,1),:);
p2m=positions(triangle(tri2,2),:);
p3m=positions(triangle(tri2,3),:);

Area1=LineNodes(node,6);
Area2=LineNodes(node,7);
Lshared=LineNodes(node,5);

%Checked

%%The integral val is:
%terms for the first triangle
T1T1=r-nshnode1;
T1T2=Km1p3(r,p1p,p2p,p3p);

%terms for the second triangle
T2T1=r-nshnode2;
T2T2=Km1p3(r,p1m,p2m,p3m);


prefactor1=-(Lshared./(2*Area1));
prefactor2=(Lshared./(2*Area2));
valKm1p4=prefactor1(:,ones(3,1)).*(cross(T1T1,T1T2,2))+prefactor2(:,ones(3,1)).*(cross(T2T1,T2T2,2));

%Checked