function [dipoles,Quadrupoles]=currents2MomentsVSH(k,epsilonv,muv,TheMat,TheV,name)

%Medium radius is good to find dipoles without numerical noise
%Short radius is better to find quadrupoles.
[LineNodes,triangle,positions]= reader(name);

node=[1:size(LineNodes,1)]'; %this part says to take all the nodes but if changed you can decide wich nodes to take into account fro the moments calculation



%Radius=10*2*pi/k;
c=1;
Zo=sqrt(muv(1)/epsilonv(2));
omega=k*c;
%k=sqrt(epsilonv(2)*muv(2))*k;

%numberofpoints=10;


alphasbetas=TheMat\TheV;
totalnodes=size(alphasbetas,1)/2;
alphas=alphasbetas(1:totalnodes);
betas=alphasbetas(totalnodes+1:end);


%px=-1i*(sqrt(3*pi)/(c*k^3))*(aE(1,1)-aE(1,-1));
px=-1i*(sqrt(12*pi)/(4*c*k^3))*(aE(1,1)-aE(1,-1));
%py=(sqrt(3*pi)/(c*k^3))*(aE(1,1)+aE(1,-1));
py=(sqrt(12*pi)/(4*c*k^3))*(aE(1,1)+aE(1,-1));
%pz=(1i*sqrt(6*pi)/(c*k^3))*aE(1,0);  
pz=(1i*sqrt(24*pi)/(4*c*k^3))*aE(1,0);  

%mx=c*1i*(sqrt(3*pi)/(c*k^3))*(aM(1,1)-aM(1,-1));
%my=-c*(sqrt(3*pi)/(c*k^3))*(aM(1,1)+aM(1,-1));
%mz=-c*(1i*sqrt(6*pi)/(c*k^3))*aM(1,0);  
mx=1i*c*1i*(sqrt(12*pi)/(4*c*k^4))*(aM(1,1)-aM(1,-1));
my=-1i*c*(sqrt(12*pi)/(4*c*k^4))*(aM(1,1)+aM(1,-1));
mz=-1i*c*(1i*sqrt(24*pi)/(4*c*k^4))*aM(1,0);  


dipoles=[px;py;pz;mx;my;mz];


prefact1=6*1i*sqrt(5*pi)/(c*k^4);
prefact2=1i*sqrt(30*pi)/(c*k^4);
prefact3=6*sqrt(5*pi)/(c*k^4);
Q11=prefact1*(aE(2,2)+aE(2,-2))-2*prefact2*aE(2,0);
Q22=-prefact1*(aE(2,2)+aE(2,-2))-2*prefact2*aE(2,0);
Q33=4*prefact2*aE(2,0);
Q12=-prefact3*(aE(2,2)-aE(2,-2));
Q13=-prefact1*(aE(2,1)-aE(2,-1));
Q23=prefact3*(aE(2,1)+aE(2,-1));

Quadrupoles=[Q11,Q12,Q13;Q12,Q22,Q23;Q13,Q23,Q33];




function valaE=aE(l,m)
valaE=sum(1/(1i*sqrt(l*(l+1)))*(c*1i*omega*alphas.*MomentsIntVSH1(l,m,k,node,LineNodes,triangle,positions)+...
1i*k*alphas.*MomentsIntVSH2(l,m,k,node,LineNodes,triangle,positions)-...
1i*k*betas.*MomentsIntVSH3(l,m,k,node,LineNodes,triangle,positions)),1);

%),1);
end

function valaM=aM(l,m)
valaM=sum(k^2/(1i*sqrt(l*(l+1)))*(betas.*MomentsIntVSH1(l,m,k,node,LineNodes,triangle,positions)-...
    k^2*betas.*MomentsIntVSH2(l,m,k,node,LineNodes,triangle,positions)+...
    alphas.*MomentsIntVSH3(l,m,k,node,LineNodes,triangle,positions)),1);
 end
end
