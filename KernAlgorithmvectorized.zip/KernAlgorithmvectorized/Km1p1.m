% This function finds the value of the integral K^{-1}_{1} from the paper
% PIER 63, 243-278, 2006

function valKm1p1=Km1p1(r,node,rpt,LineNodes,triangle,positions)

node=VECrpt1D(node,rpt);

tri1=LineNodes(node,1);
tri2=LineNodes(node,2);

p1p=positions(triangle(tri1,1),:);
p2p=positions(triangle(tri1,2),:);
p3p=positions(triangle(tri1,3),:);
p1m=positions(triangle(tri2,1),:);
p2m=positions(triangle(tri2,2),:);
p3m=positions(triangle(tri2,3),:);

Area1=LineNodes(node,6);
Area2=LineNodes(node,7);
Lshared=LineNodes(node,5);

valKm1p1=(Lshared./(Area1)).*ISm1(r,p1p,p2p,p3p)-(Lshared./(Area2)).*ISm1(r,p1m,p2m,p3m);
%Checked!!!
