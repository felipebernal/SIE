function valZ=Zi(in,epsilon,mu)

%This function will define the valuo of Z which is the other most 
%important (after Ki ;))when defining the index i in Gi and Dmni and Kmni...(see reference paper)
%Now up to here it is only defined for only two materials, but in principle
%it should be possible to define more than 2....not yet sure how though.
valZ=sqrt(mu(in)/epsilon(in));
    