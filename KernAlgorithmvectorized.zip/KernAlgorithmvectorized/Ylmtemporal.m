function valYlm=Ylmtemporal(l,m,theta,phi)

LegeCosthetaLM=legendre(l,cos(theta));
valYlm=sqrt(((2*l+1)/(4*pi))*factorial(l-m)/factorial(l+m)).*LegeCosthetaLM(m+1,:).*exp(1i*m*phi);
end