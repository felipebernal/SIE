% this function is the product of the functions in the term 1_1 of the
% integral 35 in reference A.Kern  in pag 736

function funMomentsIntVSH2val= funMomentsIntVSH2(l,m,rtri,nodetri,rpt,k,pm,LineNodes,triangle,positions)

theta=atan2(sqrt(rtri(:,1).^2+rtri(:,2).^2),rtri(:,3));
phi=atan2(rtri(:,2),rtri(:,1));
kr=k*sqrt(rtri(:,1).^2+rtri(:,2).^2+rtri(:,3).^2);

funMomentsIntVSH2val=conj(Ylm(l,m,theta,phi)).*jl(l,kr).*(sum(rtri.*RWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions),2));
 
% function valYlm=Ylm(l,m,theta,phi)
% LegeCosthetaLM=legendre(l,cos(theta));
% if m>=0
% 
% valYlm=sqrt(((2*l+1)/(4*pi))*factorial(l-m)/factorial(l+m)).*LegeCosthetaLM(m+1,:)'.*exp(1i*m*phi);
% else
%    absm=abs(m);
%  valYlm=(-1)^(absm)*conj(sqrt(((2*l+1)/(4*pi))*factorial(l-absm)/factorial(l+absm)).*LegeCosthetaLM(absm+1,:)'.*exp(1i*absm*phi));  
% end
%end   

function valYlm=Ylm(l,m,theta,phi)
LegeCosthetaLM=legendre(l,cos(theta));
if m>=0&&m<=l
valYlm=sqrt(((2*l+1)/(4*pi))*factorial(l-m)/factorial(l+m)).*LegeCosthetaLM(m+1,:)'.*exp(1i*m*phi);
elseif m<0&&m<=l
   absm=abs(m);
 valYlm=(-1)^(absm)*conj(sqrt(((2*l+1)/(4*pi))*factorial(l-absm)/factorial(l+absm)).*LegeCosthetaLM(absm+1,:)'.*exp(1i*absm*phi));  
elseif m>l
    valYlm=zeros(size(theta,1),1);
end
end



function valsphehank=h1l(n,x)
valsphehank=sqrt(pi./(2*x)).* besselh(n+1/2,1,x);
end


function valsphebessel=jl(l,x)
valsphebessel=sqrt(pi./(2*x)).* besselj(l+1/2,x);
end

function valspheDEVbessel=devjl(l,x)
        if l==1
            valspheDEVbessel=(sin(x)-2*jl(1,x))./x;
        elseif l==2
           valspheDEVbessel=(jl(1,x)-3*jl(2,x)./x);
            
        elseif l==3
            valspheDEVbessel=(jl(2,x)-4*jl(3,x)./x);
                    
        elseif l==4
               valspheDEVbessel=(jl(3,x)-5*jl(4,x)./x);
            
        end
end

end