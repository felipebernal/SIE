function  runnerCircularyPolarizeScattcrossAngleOmega5
% [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]=
    %[sigmascatparallel, sigmascatperpend]=
   
name='Omega5';
%omega=pi;
omega=2*pi/(17575/1000);
epsilonv=[1;Gold(1000*(2*pi)/omega)]; %This one suposes that a=1micron (the unit of lenght)
muv=[1;1];





%numberofpoints=100;
numberoftilesMatrix=1;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date; %This is done so that if the simulation takes more than a day then you don't have problems saving the data.

if exist([directory, dia])==0
    mkdir([directory, dia]);
    [LineNodes,triangle,positions]= reader(name);
    TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
    save([directory, dia,'\',name,'.mat'],'TheMat','LineNodes','triangle','positions');
 else
    if exist([directory, dia,'\',name,'.mat'])==0
    
        [LineNodes,triangle,positions]= reader(name);
        TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
        save([directory, dia,'\',name,'.mat'],'TheMat','LineNodes','triangle','positions');
    
    else
        Struct=load([directory, dia,'\',name,'.mat']);
        TheMat=Struct.TheMat;
         [LineNodes,triangle,positions]= reader(name);
        %LineNodes=Struct.LineNodes;
        %triangle=Struct.triangle;
        %positions=Struct.positions;
        clear('Struct');
     end
end

Radius=10;
numberofpoints=10;

thetapoints=[0:pi/(numberofpoints-1):pi]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';

alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];



anglemin=-90*pi/180;
anglemax=90*pi/180;
deltaangle=1*pi/180;
vecplotsigmaplus=zeros(size([anglemin:deltaangle:anglemax]',1),1);
vecplotsigmaminus=zeros(size([anglemin:deltaangle:anglemax]',1),1);

phi=0; %Given that the arms of the splitring are pointing in the y 
       %direction and we need to rotate the direction only perpendicular to the arms then direction in the y direction is 0
cont=1;
for Angle=anglemin:deltaangle:anglemax
    
    direction=[cos(phi)*sin(Angle) sin(phi)*sin(Angle) -cos(Angle)];
    v1=[-sin(phi)  cos(phi) 0];
    v2=[cos(phi)*cos(Angle) sin(phi)*cos(Angle) sin(Angle)];%   
    sigmaplus=1/sqrt(2)*(v1-1i*v2);
    sigmaminus=1/sqrt(2)*(v1+1i*v2);
    rsource=[0 0 0];


    
    TheV=TheVectorFiller(omega,direction,sigmaplus,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
    valE=FieldEfinder(1,'scatt','far',positionsphere,omega,epsilonv,muv,direction,sigmaplus,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions);
    vecplotsigmaplus(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);
    
    clear('TheV');
    
    TheV=TheVectorFiller(omega,direction,sigmaminus,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
    valE=FieldEfinder(1,'scatt','far',positionsphere,omega,epsilonv,muv,direction,sigmaminus,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions);
    vecplotsigmaminus(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);
    
    
    cont=cont+1;
    
    
end


tosavevecplotsigmaplus=[[anglemin:deltaangle:anglemax]',vecplotsigmaplus];
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\TotalScattCrossSecvsAngleSigmaPlus.txt'], 'tosavevecplotsigmaplus','-ascii');

tosavevecplotsigmaminus=[[anglemin:deltaangle:anglemax]',vecplotsigmaminus];
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\TotalScattCrossSecvsAngleSigmaminus.txt'], 'tosavevecplotsigmaminus','-ascii');



figure(3)
scatter([anglemin*180/pi:deltaangle*180/pi:anglemax*180/pi]',vecplotsigmaplus);
figure(4)
scatter([anglemin*180/pi:deltaangle*180/pi:anglemax*180/pi]',vecplotsigmaminus);


end

