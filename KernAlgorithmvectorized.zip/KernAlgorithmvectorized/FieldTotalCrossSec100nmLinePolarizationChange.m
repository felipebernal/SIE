function vecplot=FieldTotalCrossSec100nmLinePolarizationChange

Radius=10;
numberofpoints=10;

muv=[1;1];
direction=[0 0 -1];

pol=[1 0 0];

rsource=[0 0 0];
name='100nmLine';
[LineNodes,triangle,positions]= reader('100nmLine');

thetapoints=[0:pi/(numberofpoints-1):pi]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';

alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];

directory='\\nanorfsrv\Users\Bernal\Simulations\';
minlam=400;
maxlam=1000;
deltalam=10;

vecplot=zeros(size([minlam:deltalam:maxlam]',1),1);
cont=1;
dia='20-Oct-2011';

dia2=date;
for c=minlam:deltalam:maxlam
    matrix=load(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\',name,'_',int2str(c),'_Matrix','.mat']);
    TheMat=matrix.TheMat;
    
     omega=1000*(2*pi)/c;
    epsilonv=[1;Gold(1000*(2*pi)/c)]; %This one suposes that a=1micron (the unit of lenght)
    
    TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
    save([directory, dia2,'\',name,'_',int2str(c),'_','Vector_.mat'],'TheV');
    % clear('matrix','vector');
    
    valE=FieldEfinder(1,'scatt','far',positionsphere,(2*pi/(c/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions);
    vecplot(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);
    cont=cont+1;
end
a=[[minlam:deltalam:maxlam]',vecplot];
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia2,'\TotalScattCrossSec100nmLinediffpolarization.txt'], 'a','-ascii');
 save([directory, dia2,'\',name,'polarizationRangesandsoon.mat'],'minlam','maxlam','pol','direction');

plot([minlam:deltalam:maxlam]',vecplot);
end