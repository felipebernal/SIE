function divfvec = DivRWGfunction(r,node,rpt,pm,LineNodes,triangle,positions)


%r is a vector that belongs to the surface and therefore it is assumed that
%it belongs to a certain triangle. ie. RWG function is only defined for R
%that lie on the surface and not for any other point in space. (in this
%case)In general it would be zero outside, but that is not coded here.
%pm is plus or minus and is another index for the function, which defines
%on which triangle are we working with.
%%version 2 starting from scratch to make it vectorized not only for r but
%also for the triangles.
%node is the sharedlinenode list , r is the list of positions for
%each triangle, pm is the first or second triangle.
%rpn is the number of r per sharednode 
%n has to be a column vector!!!
%numnodes=size(n,1);
%numr=size(r,1);


%node=VECrpt1D(node,rpt);%Depending on the use and which nodes 
%are given to the function consider to take this repetition of nodes out!
%This part takes nodes and repeats it rpt times

% if pm==1
%    divfvec=3*(LineNodes(node,5)./(2*LineNodes(node,6)));
% else
%     if pm==2
%       divfvec=(-3)*(LineNodes(node,5)./(2*LineNodes(node,7)));
%     else
%         return
%     end
% end



if pm==1
   divfvec=(LineNodes(node,5)./(LineNodes(node,6)));
else
    if pm==2
      divfvec=(-1)*(LineNodes(node,5)./(LineNodes(node,7)));
    else
        return
    end
end
