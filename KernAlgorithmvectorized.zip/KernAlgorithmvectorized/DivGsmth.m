%This is the divergence of the smoothed green's function found in page 735 of Vol 26, No 4
%April 2009/J.Opt.SocAm.A Kern and Martin.


%This one is the gradient of the green's function with respect to r
%prime!!!!!!

function valDivGsmth=DivGsmth(r,rp,k)
%r and rp can be a list of 3-vectors, but the list should have the same number of
%positions.
numr=size(r,1);
R=sqrt(sum((r-rp).^2,2));
prefactor=(1/(4*pi))*((exp(1i*k*R)-ones(numr,1))./(R.^3)-(1i*k*exp(1i*k*R))./(R.^2)-k^2./(2*R));

aproximatedfactor=(1/(4*pi))*(((1i*k^3)/3)-((k^4*R)/8)-((1i*(k^5)*R.^2)/30)+(((k^6)*R.^3)/144)+(1i*(k^7)*R.^4)/840-(((k^8)*R.^5)/5760)-((1i*(k^9)*(R.^6))/45360)+(((k^10)*R.^7)/403200));
% valDivGsmth=prefactor(:,ones(3,1)).*(r-rp);

valDivGsmth=zeros(numr,3);

firstpart=prefactor(:,ones(3,1)).*(r-rp);

secondaproximated=aproximatedfactor(:,ones(3,1)).*(r-rp);

valDivGsmth(logical(k*R<1e-5),:)=secondaproximated(logical(k*R<1e-5),:);
valDivGsmth(logical(k*R>1e-5),:)=firstpart(logical(k*R>1e-5),:);

%Checked