function fvec = curlRWGfunction(r,node,pm,LineNodes,triangle,positions)

tri1=LineNodes(node,1);
tri2=LineNodes(node,2);

p1p=positions(triangle(tri1,1),:);
p2p=positions(triangle(tri1,2),:);
p3p=positions(triangle(tri1,3),:);
p1m=positions(triangle(tri2,1),:);
p2m=positions(triangle(tri2,2),:);
p3m=positions(triangle(tri2,3),:);

Area1=LineNodes(node,6);
Area2=LineNodes(node,7);
Lshared=LineNodes(node,5);

pplus=positions(triangle(sub2ind(size(triangle), LineNodes(node,1), LineNodes(node,3))),:);
pminus=positions(triangle(sub2ind(size(triangle), LineNodes(node,2), LineNodes(node,4))),:);

index1sharedP=mod(LineNodes(node,3),3)+1;
index2sharedP=mod(LineNodes(node,3)+1,3)+1;
p1=positions(triangle(sub2ind(size(triangle), LineNodes(node,1), index1sharedP)),:);
p2=positions(triangle(sub2ind(size(triangle), LineNodes(node,1), index2sharedP)),:);



SPQ=[0.333333333333333 0.333333333333333 0.333333333333333];
weigths=[1];
rpt=1;
nodenmr=size(node,1);
centroidrpos1=repmat(SPQ(:,1),nodenmr,3).*VECrpt3D(positions(triangle(tri1,1),:),rpt)+...
    repmat(SPQ(:,2),nodenmr,3).*VECrpt3D(positions(triangle(tri1,2),:),rpt)+...
    repmat(SPQ(:,3),nodenmr,3).*VECrpt3D(positions(triangle(tri1,3),:),rpt);
centroidrpos2=repmat(SPQ(:,1),nodenmr,3).*VECrpt3D(positions(triangle(tri2,1),:),rpt)+...
    repmat(SPQ(:,2),nodenmr,3).*VECrpt3D(positions(triangle(tri2,2),:),rpt)+...
    repmat(SPQ(:,3),nodenmr,3).*VECrpt3D(positions(triangle(tri2,3),:),rpt);


%This is the definition of the height of the triangle in both
%trianlges...the problem is that h1xh2 will always be perpendicular in the
%plane of the triangles...this will not give us a good number for the curl
%then.

%h1=(pplus-p1)-repmat((sum((pplus-p1).*(p2-p1),2)./sqrt(sum((p2-p1).^2,2))),1,3).*(p2-p1)./repmat(sqrt(sum((p2-p1).^2,2)),1,3);
%h2=(pminus-p1)-repmat((sum((pminus-p1).*(p2-p1),2)./sqrt(sum((p2-p1).^2,2))),1,3).*(p2-p1)./repmat(sqrt(sum((p2-p1).^2,2)),1,3);

h1=(pplus-(p1-p2)/2);
h2=(pminus-(p1-p2)/2);

dirRot=cross(h1,-h2,2);




cond1=logical(sqrt(sum(dirRot.^2,2))./(sqrt(sum(h1.^2,2)).*sqrt(sum(h2.^2,2)))>=10^-10);


fvec=zeros(size(node,1),3);
if isempty(Lshared(cond1))
else
fvec(cond1,:)=2*repmat(((Lshared(cond1)./(2*Area1(cond1))).*sum((centroidrpos1(cond1,:)-pplus(cond1,:)).*h1(cond1,:),2)+(Lshared(cond1)./(2*Area2(cond1))).*sum((centroidrpos2(cond1,:)-pminus(cond1,:)).*h2(cond1,:),2)),1,3).*(dirRot(cond1,:)./repmat((sum(dirRot(cond1,:).^2,2)),1,3) );
end




%This is another way to find the curl
 
% 
% F1=RWGfunction(centroidrpos1,node,rpt,1,LineNodes,triangle,positions);
% F2=RWGfunction(centroidrpos2,node,rpt,2,LineNodes,triangle,positions);
% 
% unix=repmat([1 0 0],size(node,1),1);
% uniy=repmat([0 1 0],size(node,1),1);
% uniz=repmat([0 0 1],size(node,1),1);
% fvecx=sum((F1-F2).*uniz,2)./sum((centroidrpos1-centroidrpos2).*uniy,2)-sum((F1-F2).*uniy,2)./sum((centroidrpos1-centroidrpos2).*uniz,2);
% fvecy=-sum((F1-F2).*uniz,2)./sum((centroidrpos1-centroidrpos2).*unix,2)+sum((F1-F2).*unix,2)./sum((centroidrpos1-centroidrpos2).*uniz,2);
% fvecz=sum((F1-F2).*uniy,2)./sum((centroidrpos1-centroidrpos2).*unix,2)-sum((F1-F2).*unix,2)./sum((centroidrpos1-centroidrpos2).*uniy,2);
% fvec=[fvecx,fvecy,fvecz];
