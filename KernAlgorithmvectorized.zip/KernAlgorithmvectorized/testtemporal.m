name='splitring'
%name='SplitRingSym';
%name='minisphererefined';
omega=2*pi/(1500/1000); %SplitRing
lambda=(2*pi/omega)*1000;


%omega=0.1;
c=1;
k=omega/c;
%epsilonv=[1;12];
epsilonv=[1;Gold(1000*(2*pi)/omega)]; %This one suposes that a=1micron (the unit of lenght)
%epsilonv=[1;1];
%muv=[1;1];
muv=[1;1];

direction=[0 0 1];

pol=[1 0 0];

rsource=[0 0 0];


%Radius=1.00000;
numberofpoints=100;
numberoftilesMatrix=1;

icont=1;
z=0;
numberoftiles=10;
xmin=-1;
xmax=1;
xstep=0.1;
directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date; %This is done so that if the simulation takes more than a day then you don't have problems saving the data.
 Struct=load([directory, dia,'\',name,'.mat']);
        TheMat=Struct.TheMat;
       % LineNodes=Struct.LineNodes;
        %triangle=Struct.triangle;
        %positions=Struct.positions;
         [LineNodes,triangle,positions]= reader(name);
          TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
[Totalelectricdipole,Totalmagneticdipole]=effectivedipolecalculator(k,epsilonv,muv,TheMat,TheV,name)
c=1;
omega=k*c;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date;

[LineNodes,triangle,positions]= reader(name);
rsource=[0,0,0];

%
positioncenterstructure=[0,0,0];
%

directionmatrix=[1 0 0;0 1 0;0 0 1];
polarizationmatrix=[0 1 0;0 0 1;1 0 0;0 0 1;1 0 0;0 1 0];
orderer=[1,1; 1,2; 2,3; 2,4; 3,5; 3,6];

rpt=5;
theta=linspace(0, pi, rpt).';
phi=linspace(0, pi, rpt).';

theta=repmat(theta,rpt,1);
phi=VECrpt1D(phi,rpt);

% directionmatrixHalf=[cos(phi).*sin(theta), sin(phi).*sin(theta), -cos(theta)];
% polarizationmatrix1=[-sin(phi),  cos(phi) 0*sin(theta)];
% polarizationmatrix2=[cos(phi).*cos(theta),  sin(phi).*cos(theta), sin(theta)];
% 
% directionmatrix=repmat(directionmatrixHalf,2,1);
% polarizationmatrix=[polarizationmatrix1;polarizationmatrix2];
%sizeN=size(directionmatrix,1);
sizeN=6;

MatP=zeros(6,sizeN);
MatE=zeros(6,sizeN);
for dircont=1:sizeN
    
    direction=directionmatrix(orderer(dircont,1),:);
    pol=polarizationmatrix(orderer(dircont,2),:);
%     direction=directionmatrix(dircont,:);
%     pol=polarizationmatrix(dircont,:);
    
    
    TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
    [Totalelectricdipole,Totalmagneticdipole]=effectivedipolecalculator(k,epsilonv,muv,TheMat,TheV,name);
    E=PlaneWaveE(k,direction,pol,positioncenterstructure);
    H=PlaneWaveH(k,direction,pol,positioncenterstructure);
    MatP(:,dircont)=[Totalelectricdipole,Totalmagneticdipole].';
    MatE(:,dircont)=[E,H].';    
end

alpha=MatP/MatE %This is the same as MatP*inv(MatE)

%%%%Here we have another solution for alpha which preconditions the stuff
minimizefunct= @(x) OptiAlpha(x,MatP,MatE);
[Xmin,fvaltol]=fminsearch(minimizefunct,alpha(:),optimset('PlotFcns',@optimplotfval,'TolX',1e-8));
%[Xmin,fvaltol]=fminsearch(minimizefunct,alpha(:));
fvaltol
alphafinal=zeros(6,6);
alphafinal=etafromx(Xmin)
 NeeONhh=norm(trace(alphafinal(1:3,1:3))/trace(alphafinal(4:6,4:6)));



         