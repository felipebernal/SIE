function magvectoplot=FieldPlotZYLine(i,z,y,xmin,xmax,xstep,TheV,TheMat,LineNodes,triangle,positions)


%now we define the rtoeval list of 3-vectors.
xvec=[xmin:xstep:xmax]';
sizex=size(xvec,1);
yvec=y*ones(sizex,1);
zvec=z*ones(sizex,1);
%repx=VECrpt1D(xvec,sizey);
%repy=repmat(yvec,sizex,1);
rtoeval=[xvec,yvec,zvec];

omega=2*pi/(540/1000);
epsilonv=[1;Gold(1000*(2*pi)/omega)]; %This one suposes that a=1micron (the unit of lenght)
%omega=pi;

%epsilonv=[1;12];
muv=[1;1];
direction=[0 1 0];
pol=[1 0 0];
rsource=[0 0 0];

vectoplot=FieldEfinder(i,'total','near',rtoeval,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions);
          
%%%%%vectoplot=PlaneWaveE(omega,direction,pol,rtoeval,rsource);
%magvectoplot=sum(vectoplot.*conj(vectoplot),2);
%magvectoplot=sqrt(sum(repmat([0,1,0],sizex,1).*vectoplot.*conj(vectoplot),2));

%magvectoplot=real(sum(repmat([0,0,1],sizex,1).*vectoplot,2));
magvectoplot=imag(sum(repmat([1,0,0],sizex,1).*vectoplot,2));
plot(xvec,magvectoplot);
magvectoplot=[xvec,magvectoplot];

% fieldnoscatter=contourf(reshape(magvectoplot,sizey,[]));


