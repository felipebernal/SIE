function TheVector = TheVectorFillerForLDOS(omega, ~,pol,rsource,LineNodes,triangle,positions,muv,epsilonv,sourceinout)%,numberoftiles)

%This one is a change from the vectorfiller function for findiong the LDOS
%of different scatterers. Teh froblem of the normal function was that it
%needed the integral of E.fn for the LDOS E is the field of a dipole which
%has a singular behaviour when R is close to 0...for LDOS close to the
%structure this condition is met and therefore this function divedes the
%integral in two parts, the singular and the smooth part, it does the
%smooth part numerically and the singular part it does it analiticaly.
%pol is the polarization of the source.
% This function fills up the big vector which should be
% qm={Int_{S_m} f_m(r)\dot E^inc(r) for m=1:N
% and {Int_{S_m-N} f_(m-N)(r)\dot H^inc(r) for m=N+1:2N

%I do not think that for filling up this vector the computer will hang...so
%I will not introduce the number of tiles solution unless absolutely
%necessary.

barycentryctable;
node=[1:size(LineNodes,1)]';%All the nodes in one shot...if it cannot with it the program is not good enough!:)
mu=muv(sourceinout);
epsilon=epsilonv(sourceinout);
k=omega*sqrt(mu*epsilon);
%Although it seems that the square parenthesis above it's not needed...it
%is...becasue we want a column vector!
%[rpos1,rpos2]=BarycentGaussQuadPos(node,SPQ,LineNodes,triangle,positions);
%q1half=BaryQuadratureTheVector(omega,direction,pol,rsource,rpos1,rpos2, weigths,funE,node,1,rpt,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
%q2half=BaryQuadratureTheVector(omega,direction,pol,rsource,rpos1,rpos2, weigths,funH,node,1,rpt,LineNodes,triangle,positions,muv,epsilonv,sourceinout);

q1half=(omega^2)*muv(1)*sum(EHInt1(k,rsource,node,LineNodes,triangle,positions).*repmat(pol,size(node,1),1),2);
q2half=-1i*omega*sum(EHInt2(k,rsource,node,LineNodes,triangle,positions).*repmat(pol,size(node,1),1),2);

%      BaryQuadratureTheVector(omega,direction,pol,rsource,rpos1,rpos2,weigths,funcion,nodem,dimfun,rpt,LineNodes,triangle,positions)

%Somehow I needed to add the conjugate to make the imaginary part negative
%because otherwise the number would be different when compared to the
%vector created by an electric dipole....I do not understand why...
TheVector=conj([q1half; q2half]);