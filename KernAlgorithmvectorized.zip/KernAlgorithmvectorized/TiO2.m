function epsilon=TiO2(lambda)
%this is in units of nanometers so that is is the same as how we use gold,
%silver, aluminium, and silicon....Just for historical facts....

epsilon=5.913+0.2441/(((lambda/1000)^2)-0.0803);
