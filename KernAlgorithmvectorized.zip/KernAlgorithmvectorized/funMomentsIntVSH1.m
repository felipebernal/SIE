% this function is the product of the functions in the term 1_1 of the
% integral 35 in reference A.Kern  in pag 736

function funMomentsIntVSH1val= funMomentsIntVSH1(l,m,rtri,nodetri,rpt,k,pm,LineNodes,triangle,positions)


theta=atan2(sqrt(rtri(:,1).^2+rtri(:,2).^2),rtri(:,3));
phi=atan2(rtri(:,2),rtri(:,1));


r=sqrt(rtri(:,1).^2+rtri(:,2).^2+rtri(:,3).^2);
kr=k*r;
node=VECrpt1D(nodetri,rpt);
tri1=LineNodes(node,1);
tri2=LineNodes(node,2);
p1p=positions(triangle(tri1,1),:);
p2p=positions(triangle(tri1,2),:);
p3p=positions(triangle(tri1,3),:);
p1m=positions(triangle(tri2,1),:);
p2m=positions(triangle(tri2,2),:);
p3m=positions(triangle(tri2,3),:);
if pm==1
bp=cross((p2p-p1p),(p3p-p1p),2);
normbp=sqrt(sum(bp.^2,2));
npoint=bp./normbp(:,ones(3,1));
elseif pm==2
bm=cross((p2m-p1m),(p3m-p1m),2);
normbm=sqrt(sum(bm.^2,2));
npoint=bm./normbm(:,ones(3,1));
end

%%%%%DivRWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions)=Ln/An--->Q=DivRWGfunction/2
funMomentsIntVSH1val=conj(Ylm(l,m,theta,phi)).*(devRjlkr(l,kr)).*2.*DivRWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions)+...
                    sum(npoint.*RWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions),2).*sum(npoint.*gradYlm(l,m,theta,phi),2).*devRjlkr(l,kr)+... %this is the second part   
                    sum(npoint.*RWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions),2).*sum(npoint.*rtri,2).*conj(Ylm(l,m,theta,phi)).*(dev2Rjlkr(l,kr));

  % funMomentsIntVSH1val=conj(Ylm(l,m,theta,phi)).*(devRjlkr(l,kr)).*2.*DivRWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions);                













    
    function valdevRjlkr=devRjlkr(l,kr)
        valdevRjlkr=jl(l,kr)+kr.*devjl(l,kr);
    end
               
function valdev2Rjlkr=dev2Rjlkr(l,kr)
        valdev2Rjlkr=2*k*devjl(l,kr)+k*kr.*dev2jl(l,kr);
    end       


function valYlm=Ylm(l,m,theta,phi)
LegeCosthetaLM=legendre(l,cos(theta));
if m>=0&&m<=l
valYlm=sqrt(((2*l+1)/(4*pi))*factorial(l-m)/factorial(l+m)).*LegeCosthetaLM(m+1,:)'.*exp(1i*m*phi);
elseif m<0&&m<=l
   absm=abs(m);
 valYlm=(-1)^(absm)*conj(sqrt(((2*l+1)/(4*pi))*factorial(l-absm)/factorial(l+absm)).*LegeCosthetaLM(absm+1,:)'.*exp(1i*absm*phi));  
elseif m>l
    valYlm=zeros(size(theta,1),1);
end
end




function valgradYlm=gradYlm(l,m,theta,phi)%This is the gradient of the conjugate of Ylm not delYlm
    thetapointer=[cos(theta).*cos(phi),cos(theta).*sin(phi),-sin(theta)];
    phipointer=[-sin(phi),cos(phi),zeros(size(phi,1),1)];
  
valgradYlm=((-1)^m).*repmat(((1./r).*(-m.*cot(theta).*Ylm(l,-m,theta,phi)+exp(-1i*m*phi).*(sqrt(factorial(1+l+m)*factorial(2+l-m)./(sqrt(factorial(l+m).*factorial(1+l-m))))).*Ylm(l,1-m,theta,phi))),1,3).*thetapointer...
    -repmat(1i*m*Ylm(l,-m,theta,phi),1,3).*phipointer;     %here 1i has a minus cause it is the gradient of the conjugate of ylm...       
end




function valsphehank=h1l(n,x)
valsphehank=sqrt(pi./(2*x)).* besselh(n+1/2,1,x);
end


function valsphebessel=jl(l,x)
valsphebessel=sqrt(pi./(2*x)).* besselj(l+1/2,x);
end

function valspheDEVbessel=devjl(l,x)
        if l==1
            valspheDEVbessel=(sin(x)-2*jl(1,x))./x;
        elseif l==2
           valspheDEVbessel=(jl(1,x)-3*jl(2,x)./x);
            
        elseif l==3
            valspheDEVbessel=(jl(2,x)-4*jl(3,x)./x);
                    
        elseif l==4
               valspheDEVbessel=(jl(3,x)-5*jl(4,x)./x);
            
        end
end



function valspheDEVbessel=dev2jl(l,x)
        if l==1
            valspheDEVbessel=((x.^3-6*x).*cos(x)-(3*x.^2-6).*sin(x))./x.^4;
        elseif l==2
           valspheDEVbessel=((5*x.^3-36*x).*cos(x)-(x.^4-17*x.^2+36).*sin(x))./x.^5;
%Since we only need l=1 and 2 for the dipoles and quadrupoles I don't write the other functions here...no need.
%if needed just use mathematica and find them...easy peacy...
       end
end








end