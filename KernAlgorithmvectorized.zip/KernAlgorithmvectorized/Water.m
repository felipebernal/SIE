function epsilon=Water(lambda)
%The units of Lambda are in nanometers!!!


Waterrefractiveindex=load('Waterrefractiveindex.mat');
nt=Waterrefractiveindex.Waterrefractiveindex;
Lambdatable=nt(:,1)*1000;
n=nt(:,2);
ninter=interp1(Lambdatable,n,lambda);
epsilon=ninter.^2;