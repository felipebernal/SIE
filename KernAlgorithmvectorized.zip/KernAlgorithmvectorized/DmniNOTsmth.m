function inteTrian = DmniNOTsmth(omega,k,mu,nodem,noden,LineNodes,triangle,positions)
% This function makes the integration over the triangle m the not smooth green's function. 
%c=299792458;
barycentryctable;

[rtrim1, rtrim2]=BarycentGaussQuadPos(nodem,SPQ,LineNodes,triangle,positions);
%This function findss the positions for the plus 1 and minus 2 triangles
%for the list of nodes gven in nodem.


%The DmniNotsmth value is composed by four integrals, each one of which is
%calculated over a node region composed by two triangles.
%this two triangles are calculated in baryquadrature and the integration 
%is done in there. Here we only need  to sum the different terms

Intterm1=BaryQuadrature(rtrim1,rtrim2,weigths,@funDmni1NoTSMTHterm,nodem,noden,1,rpt,LineNodes,triangle,positions);
Intterm2=BaryQuadrature(rtrim1,rtrim2,weigths,@funDmni2NoTSMTHterm,nodem,noden,1,rpt,LineNodes,triangle,positions);
%First two termsChecked
Intterm3=BaryQuadrature(rtrim1,rtrim2,weigths,@funDmni3NoTSMTHterm,nodem,noden,1,rpt,LineNodes,triangle,positions);
Intterm4=BaryQuadrature(rtrim1,rtrim2,weigths,@funDmni4NoTSMTHterm,nodem,noden,1,rpt,LineNodes,triangle,positions);
%SecondAlsoChecked...there is a small difference to the mathematica result,
%and it decreases with a higher number of integration points...from 7 to 13
%it improves 3 orders of magnitude.
inteTrian=(omega*mu/1i)*(...
            (-1/(k^2))*(1/(4*pi))*(Intterm1-((k^2)/2)*Intterm2)...
            +(1/(4*pi))*(Intterm3-((k^2)/2)*Intterm4)...
            );