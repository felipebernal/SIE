% this function is the product of the functions in the first term of the
% integral Dmni, i.e. div f *G* div' f

function funDmni1termval= funDmni1term(rtri,rtrip, nodetri,nodetrip,rpt,k,pm,pmp,LineNodes,triangle,positions)


%In this case p means prime. 
funDmni1termval=DivRWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions).*...
    Gsmth(rtri,rtrip,k).*DivRWGfunction(rtrip,nodetrip,rpt,pmp,LineNodes,triangle,positions);
