function inteTrianK = KmniNOTsmth(k,mu,nodem,noden,LineNodes,triangle,positions)
% This function makes the integration over the triangle m the not smooth green's function. 
%c=299792458;
%c=1;
%omega=c*k;
barycentryctable;

[rtrim1, rtrim2]=BarycentGaussQuadPos(nodem,SPQ,LineNodes,triangle,positions);
%This function findss the positions for the plus 1 and minus 2 triangles
%for the list of nodes gven in nodem.


%The KmniNotsmth value is composed by two integrals, each one of which is
%calculated over a node region composed by two triangles.
%this two triangles are calculated in baryquadrature and the integration 
%is done in there. Here we only need  to sum the different terms

% Intterm1=BaryQuadrature(rtrim1,rtrim2,weigths,@funKmni1NoTSMTHterm,nodem,noden,1,rpt,LineNodes,triangle,positions);
% Intterm2=BaryQuadrature(rtrim1,rtrim2,weigths,@funKmni2NoTSMTHterm,nodem,noden,1,rpt,LineNodes,triangle,positions);
% 
% inteTrianK=(1/(4*pi))*(Intterm1-((k^2)/2)*Intterm2);

inteTrianK=(1/(4*pi))*(BaryQuadrature(rtrim1,rtrim2,weigths,@funKmni1NoTSMTHterm,nodem,noden,1,rpt,LineNodes,triangle,positions)...
    -((k^2)/2)*BaryQuadrature(rtrim1,rtrim2,weigths,@funKmni2NoTSMTHterm,nodem,noden,1,rpt,LineNodes,triangle,positions));

%Checked but still there is a big difference with the otherone!!

