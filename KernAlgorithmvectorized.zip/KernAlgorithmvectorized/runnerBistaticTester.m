function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
    [sigmascatparallel, sigmascatperpend]=runnerBistaticTester(Radius,lambda,name,LineNodes,positions,triangle)

omega=2*pi/(lambda/1000);
%omega=pi;

%epsilonv=[1;(4)^2];
epsilonv=[1;Gold(1000*(2*pi)/omega)]; %This one suposes that a=1micron (the unit of lenght)
muv=[1;1];
direction=[0 1 0];
pol=[1 0 0];
rsource=[0 0 0];


%Radius=1.00000;
numberofpoints=100;
numberoftilesMatrix=4;

icont=1;
z=0;
numberoftiles=10;
xmin=-1;
xmax=1;
xstep=0.1;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia='07-Apr-2011';%date; %This is done so that if the simulation takes more than a day then you don't have problems saving the data.


       Structmat=load([directory, dia,'\',name,'_',int2str(lambda),'_Matrix','.mat']);
       TheMat=Structmat.TheMat;
       clear('Structmat');
       Structvec=load([directory, dia,'\',name,'_',int2str(lambda),'_Vector_','.mat']);
       TheV=Structvec.TheV;
       clear('Structvec');
       [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);

    
     
     
     Escatsqrparallel=sum(vecplotparallel.*conj(vecplotparallel),2);%sum(abs(vecplotparallel).^2,2);
     sigmascatparallel=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2*Escatsqrparallel];
     
     Escatsqrperpendm=sum(vecplotperpedicular.*conj(vecplotperpedicular),2);    %sum(abs(vecplotperpedicular),2);
     sigmascatperpend=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* Escatsqrperpendm];
  
     polar([sigmascatparallel(:,1);NaN;sigmascatperpend(:,1)],[sigmascatparallel(:,2);NaN;sigmascatperpend(:,2)]); 

    