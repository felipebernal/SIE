% this function is the product of the functions in the first 
%integral not-smooth Kmni, i.e.  f dot Kp1p4

function funKmni2NoTSMTHtermval= funKmni2NoTSMTHterm(rtri,nodetri,nodetrip,rpt,pm,LineNodes,triangle,positions)
%In this case p means prime. 

%Given that RWGfunction and DivRWGfunction need two lists with the same
%seze where the node list is one to one with the r-position list then we
%need to modify the nodtri list.

nodetrimod=VECrpt1D(nodetri,rpt);

funKmni2NoTSMTHtermval=sum(RWGfunction(rtri,nodetrimod,rpt,pm,LineNodes,triangle,positions).*...
  Kp1p4(rtri,nodetrip,rpt,LineNodes,triangle,positions),2);
