%this function takes any list of 1-vectors and repeats them n(rpt) times in
%groups of m(grp)

%v=[1 2 3 4 5 6] if m=2 and n=3;

%v=[1 2 1 2 1 2 3 4 3 4 3 4 5 6 5 6 5 6]

function valgrprptvec= repmatdiferent1D(vec,grp,rpt)
% line1=vec(:,1);
% line2=vec(:,2);
% line3=vec(:,3);
valgrprptvec=reshape(repmat(reshape(vec,grp,[]),rpt,1),[],1);
