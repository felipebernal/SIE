% This function finds the value of the integral K^{1}_{2} from the paper
% PIER 63, 243-278, 2006

function valKp1p2=Kp1p2(r,node,rpt,LineNodes,triangle,positions)



node=VECrpt1D(node,rpt);


tri1=LineNodes(node,1);
tri2=LineNodes(node,2);



nshnode1=positions(triangle(sub2ind(size(triangle), LineNodes(node,1), LineNodes(node,3))),:);
nshnode2=positions(triangle(sub2ind(size(triangle), LineNodes(node,2), LineNodes(node,4))),:);

p1p=positions(triangle(tri1,1),:);
p2p=positions(triangle(tri1,2),:);
p3p=positions(triangle(tri1,3),:);
p1m=positions(triangle(tri2,1),:);
p2m=positions(triangle(tri2,2),:);
p3m=positions(triangle(tri2,3),:);

Area1=LineNodes(node,6);
Area2=LineNodes(node,7);
Lshared=LineNodes(node,5);

%Checked
%%For the first triangle

bp=cross((p2p-p1p),(p3p-p1p),2);
normbp=sqrt(sum(bp.^2,2));
np=bp./normbp(:,ones(3,1));


normp2pp1p=sqrt(sum((p2p-p1p).^2,2));
normp3pp2p=sqrt(sum((p3p-p2p).^2,2));
normp1pp3p=sqrt(sum((p1p-p3p).^2,2));


m1p=cross((p2p-p1p)./normp2pp1p(:,ones(3,1)),np);
m2p=cross((p3p-p2p)./normp3pp2p(:,ones(3,1)),np);
m3p=cross((p1p-p3p)./normp1pp3p(:,ones(3,1)),np);

%dP1 boundary of the triangle defined by the pa and pb nodes
pa1p=p1p;
pb1p=p2p;
%t1p=sum(m1p.*(r-pA1p),2);
%vectorized inner product sum(a1.*a2,2) for a list of vectors

%dP2
pa2p=p2p;
pb2p=p3p;
%M2p=m2p(ones(numr,1),:);
%t2p=sum(M2p.*(r-PA2p),2);

%dP3
pa3p=p3p;
pb3p=p1p;
%M3p=m3p(ones(numr,1),:);
%t3p=sum(M3p.*(r-PA3p),2);

%%For the second triangle
bm=cross((p2m-p1m),(p3m-p1m),2);
normbm=sqrt(sum(bm.^2,2));
nm=bm./normbm(:,ones(3,1));

normp2mp1m=sqrt(sum((p2m-p1m).^2,2));
normp3mp2m=sqrt(sum((p3m-p2m).^2,2));
normp1mp3m=sqrt(sum((p1m-p3m).^2,2));

m1m=cross((p2m-p1m)./normp2mp1m(:,ones(3,1)),nm);
m2m=cross((p3m-p2m)./normp3mp2m(:,ones(3,1)),nm);
m3m=cross((p1m-p3m)./normp1mp3m(:,ones(3,1)),nm);

%Checked so far

%dP1 boundary of the triangle defined by the pa and pb nodes
pa1m=p1m;
pb1m=p2m;
%t1m=sum(m1m.*(r-pA1m),2);
%vectorized inner product sum(a1.*a2,2) for a list of vectors

%dp2
pa2m=p2m;
pb2m=p3m;
%t2m=sum(m2m.*(r-pA2m),2);

%dP3
pa3m=p3m;
pb3m=p1m;
%t3m=sum(m3m.*(r-pA3m),2);

%%The integral val is:
%terms for the first triangle
T1T1=(1/3)*ILp3(r,pa1p,pb1p);
T1T2=(1/3)*ILp3(r,pa2p,pb2p);
T1T3=(1/3)*ILp3(r,pa3p,pb3p);
%terms for the second triangle
T2T1=(1/3)*ILp3(r,pa1m,pb1m);
T2T2=(1/3)*ILp3(r,pa2m,pb2m);
T2T3=(1/3)*ILp3(r,pa3m,pb3m);

%NSHNODE1=nshnode1(ones(numr,1),:);

projectr1=sum(np.*(r-nshnode1),2);
rho1=(r-projectr1(:,ones(3,1)).*np);

projectr2=sum(nm.*(r-nshnode2),2);
rho2=(r-projectr2(:,ones(3,1)).*nm);

T1T2S=ISp1(r,p1p,p2p,p3p);
T2T2S=ISp1(r,p1m,p2m,p3m);

prefactor1=(Lshared./(2*Area1));
prefactor2=(Lshared./(2*Area2));

valKp1p2=prefactor1(:,ones(3,1)).*((m1p.*T1T1(:,ones(3,1))+m2p.*T1T2(:,ones(3,1))+m3p.*T1T3(:,ones(3,1)))+(rho1-nshnode1).*T1T2S(:,ones(3,1)))...
        -prefactor2(:,ones(3,1)).*((m1m.*T2T1(:,ones(3,1))+m2m.*T2T2(:,ones(3,1))+m3m.*T2T3(:,ones(3,1)))+(rho2-nshnode2).*T2T2S(:,ones(3,1)));
    
%valKp1p2=prefactor1(:,ones(3,1)).*(T1T1(:,ones(3,1)).*(m1p+m2p.*(T1T2(:,ones(3,1))./T1T1(:,ones(3,1)))+m3p.*(T1T3(:,ones(3,1))./T1T1(:,ones(3,1))))+(rho1-nshnode1).*T1T2S(:,ones(3,1)))...
%        -prefactor2(:,ones(3,1)).*(T2T1(:,ones(3,1)).*(m1m+m2m.*(T2T2(:,ones(3,1))./T2T1(:,ones(3,1)))+m3m.*(T2T3(:,ones(3,1))./T2T1(:,ones(3,1))))+(rho2-nshnode2).*T2T2S(:,ones(3,1)));
    
%valKp1p2=prefactor1(:,ones(3,1)).*((rho1-nshnode1).*T1T2S(:,ones(3,1))).*((T1T1(:,ones(3,1))./((rho1-nshnode1).*T1T2S(:,ones(3,1)))).*(m1p+m2p.*(T1T2(:,ones(3,1))./T1T1(:,ones(3,1)))+m3p.*(T1T3(:,ones(3,1))./T1T1(:,ones(3,1))))+1)...
%        -prefactor2(:,ones(3,1)).*((rho2-nshnode2).*T2T2S(:,ones(3,1))).*((T2T1(:,ones(3,1))./((rho2-nshnode2).*T2T2S(:,ones(3,1)))).*(m1m+m2m.*(T2T2(:,ones(3,1))./T2T1(:,ones(3,1)))+m3m.*(T2T3(:,ones(3,1))./T2T1(:,ones(3,1))))+1);
     

 
%Checked