function valfunHQuadrupole= QuadrupoleHField(omega,~,Q,rtoeval,rsource,muv,epsilonv,sourceinout)
% omega is the frequency at which the quadrupole radiates..
%Q is the quadrupole traceless matrix of3x3
%direction is not used at all...
%rtoeval is the position at which we want to find the H field.
%rsource is the position of the quadrupole



numpoints=size(rtoeval,1);

mu0=1;
eps0=1;
c=1;
epsilon=epsilonv(sourceinout);
mu=muv(sourceinout);
k=omega*sqrt(eps0*epsilon*mu0*mu)/c;

r=rtoeval-repmat(rsource,numpoints,1);
rmag=sqrt(sum(r.^2,2));
rdirect=r./repmat(rmag,1,3);


factor1=-(mu0/mu)*((1i*(1/sqrt(mu*epsilon))*c*(k^3))/(24*pi))*(exp(1i*k*rmag)./(rmag));
QDotrdirect=multiprod(Q,rdirect.',[1,2],[1]).';
factor2=cross(rdirect,QDotrdirect,2);
valfunHQuadrupole=repmat(factor1,1,3).*factor2;

end