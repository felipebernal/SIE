%you need to save the .msh file from gmsh in the version 1 that is given
%in save as....version two does not work!!!!

function [LineNodes,triangle,positions]= reader(name)

%STRUCTURE DEFINITIONS
%%load the values and get the nodes and triangles
struct=load_gmsh2( ['/home2/fabernalarango/Desktop/codes/Simulations/Meshes/',name,'.msh'], 2);
%struct=load_gmsh2( 'twospheresII.msh', 2);
positions=struct.POS;
triangle=struct.TRIANGLES;
%%define the shared lines (LineNodes)
numtri=size(triangle,1);

 %temporal shift
 % positions=positions+repmat([0,0,100000],size(positions,1),1);

LineNodes=zeros(1,7);

firstterm=zeros(size(triangle));
secondterm=zeros(size(triangle));
thirdterm=zeros(size(triangle));
%lengthnodes=zeros(size(triangle,1),3)

p1=positions(triangle(:,1),:);
p2=positions(triangle(:,2),:);
p3=positions(triangle(:,3),:);
l1=sqrt(sum((p3-p2).^2,2));%We choose it in this one to make 
%easier the choice later of which one is the line that is shared and the one that is not shared.
l2=sqrt(sum((p1-p3).^2,2));
l3=sqrt(sum((p2-p1).^2,2));
lengthnodes=[l1,l2,l3];
clear('l1','l2','l3');
valarea=(1/2)*sqrt(sum((cross((p2-p1),(p3-p1),2)).^2,2));
starter=1;
for n=1:numtri
    
    final=size(LineNodes,1);
    firstterm(n+1:end,:)=(triangle(n,1)==triangle(n+1:end,:));
    %the first node in triangle (T) n is shared in which triangles?
    secondterm(n+1:end,:)=(triangle(n,2)==triangle(n+1:end,:));
    %the second node in Tn is shared in which triangles?
    thirdterm(n+1:end,:)=(triangle(n,3)==triangle(n+1:end,:));
    %the third node is shared in which triangles?
    elements=find(sum(firstterm+secondterm+thirdterm,2)==2);
    %which triangles share exactly 2 nodes with triangle n
    sumterms=firstterm(elements,:)+secondterm(elements,:)+thirdterm(elements,:);
    %small logical matrix that shows which elements are shared between the tirangles first second or third
    %
    LineNodes(final+1:final+size(elements,1),1)=n;
    %start filling the matrix Linenodes with the index of tirangle n for as many as triangles it is sharing in position 1
    %
    LineNodes(final+1:final+size(elements,1),2)=elements;
    %in position 2 put the index of the triangles with which it is sharing 2 nodes
    %
    [ind3i,ind3j]=find([sum(firstterm(elements,:),2),sum(secondterm(elements,:),2),sum(thirdterm(elements,:),2)]==0);
    tempmatrixnod1=zeros(size(elements,1),1);
    tempmatrixnod1(ind3i)=ind3j;
    LineNodes(final+1:final+size(elements,1),3)=tempmatrixnod1;
    %first we find which one is the node that is not shared from T1 and then we
    %fill them into position 3
    %
    [ind4i,ind4j]=ind2sub([size(elements,1),4],find(sumterms(:,1:3)==0));
    tempmatrixnod2=zeros(size(elements,1),1);
    tempmatrixnod2(ind4i)=ind4j;
    LineNodes(final+1:final+size(elements,1),4)=tempmatrixnod2;
    % first find which node is not shared from Triangle 2 T2 and then we
    %fill them into position 4
    LineNodes(final+1:final+size(elements,1),5)=lengthnodes(sub2ind(size(lengthnodes),elements,tempmatrixnod2));
    %
    LineNodes(final+1:final+size(elements,1),6)=valarea(n);
    %
    LineNodes(final+1:final+size(elements,1),7)=valarea(elements);
    %
    
    firstterm=zeros(size(triangle));
    secondterm=zeros(size(triangle));
    thirdterm=zeros(size(triangle));
    
end
LineNodes(1,:)=[];
end
    %LineNodes is composed by:
    %[T1,T2,NotSharedNodeT1,NotSharedNodeT2,Ln,AnT1,AnT2]
    %
    %
    %the index of the two triangles that share a
    %line and the two indexes of the nodes of each triangle that are not
    %shared the last value is the length of the shared linenode