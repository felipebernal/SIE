% this function is the sum of the terms smooth and not smooth in the second integral for
% finding the Total electric or magnetic field.

function valEHInt2= EHInt2(k,rtoeval,node,LineNodes,triangle,positions)

valEHInt2= EHInt2SMTH(k,rtoeval,node,LineNodes,triangle,positions)+EHInt2NTSMTH(k,rtoeval,node,LineNodes,triangle,positions);
