function vecplot=FieldTotalCrossSecSpinelliCilinder



%global struct;
%global t;  

struct=[[1;12.25;12.25],[1;1;1]];
%t=0;

Radius=1000000;
 numberofpoints=10;

epsilonv=[struct(1,1);1];
muv=[struct(1,2);1];
direction=[0 0 -1];
pol=[1 0 0];
rsource=[0 0 0];


[LineNodes,triangle,positions]= reader('SpinelliCilinder');

thetapoints=[0:pi/(numberofpoints-1):pi]';

phipoints=[0:2*pi/(numberofpoints-1):2*pi]';

alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];


%closespherepoints=[100*sin(alltheta).*cos(allphi),100*sin(alltheta).*sin(allphi),100*cos(alltheta)];


lambdafirst=300;
lamdafinal=1100;
deltalambda=10;

vecplot=zeros(size([lambdafirst:deltalambda:lamdafinal]',1),1);
cont=1;
for c=lambdafirst:10:lamdafinal
    matrix=load(['\\nanorfsrv\Users\Bernal\Simulations\05-Aug-2011\SpinelliCilinder_',int2str(c),'_Matrix','.mat']);
    TheMat=matrix.TheMat;
    vector=load(['\\nanorfsrv\Users\Bernal\Simulations\05-Aug-2011\SpinelliCilinder_',int2str(c),'_Vector_','.mat']);
    TheV=vector.TheV;
   % clear('matrix','vector');
    valE=FieldEfinder(1,'scatt','far',positionsphere,(2*pi/(c/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions);
    %valEinc=sum(PlaneWaveELayered((2*pi/(c/1000)),direction,pol,0*positionsphere),1);
    %vecplot(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2))./(sum(valEinc.*conj(valEinc),2)),1);
    
    vecplot(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);
    cont=cont+1;
end
a=[[lambdafirst:deltalambda:lamdafinal]',vecplot];
save('\\nanorfsrv\Users\Bernal\Simulations\05-Aug-2011\TotalScattCrossSecSpinelliCilinder.txt', 'a','-ascii');
figure(1)
plot([lambdafirst:deltalambda:lamdafinal]',vecplot);
figure(2)
plot([lambdafirst:deltalambda:lamdafinal]',vecplot,'.');
end