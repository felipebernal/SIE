function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]= 
            ...[sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
        ...   [Totalelectricdipole,Totalmagneticdipole,alpha,NeeONhh,fvaltol,moments]=runnerBistatic(Radius,name)
        ...    [Totalelectricdipole,Totalmagneticdipole,Dipoles,Quadrupoles,alpha]
            [Dipoles,Quadrupoles,alpha]=runnerBistaticMagnena

        Radius=10;
name='Magnena';
 omega=2*pi/(1194/1000);%Magnena second resonantpeak
        
        %omega=2*pi/(10000/1000); %1microns wavelength
%omega=0.10;

%omega=2*pi/(10000/1000); %Minisphere 10 nm
%omega=2*pi/(1507/1000); %SplitRing
%omega=2*pi/(1528/1000); %SplitRingRefined
%omega=2*pi/(1544.3/1000); %SplitRingRefined

%omega=2*pi/(2*pi*1000/1000); %test

%omega=2*pi/(62500/1000); %DSRR
%omega=2*pi/(16500/1000); %DGSRR px electric resonance
%omega=2*pi/(25000/1000); %DGSRR py resonance
%omega=2*pi/(23250/1000); %DGSRR  resonance

%omega=2*pi/(18000/1000); %Omega
%omega=2*pi/(2500/1000); %CasimirOmega

%omega=2*pi/(15404/1000); %Omega1
%omega=2*pi/(16803/1000); %Omega2
%omega=2*pi/(16063/1000); %Omega3
%omega=2*pi/(16411/1000); %Omega4
%omega=2*pi/(15475/1000); %Omega5
%omega=2*pi/(15559/1000); %OmegaSmothedMedium

lambda=(2*pi/omega)*1000;


%omega=0.1;
c=1;
k=omega/c;
%epsilonv=[1;12];

epsilonv=[1;Gold(1000*(2*pi)/omega)]; %This one suposes that a=1micron (the unit of lenght)BORISPROBE

%epsilonv=[1;Gold(1000*(2*pi)/omega)]; %This one suposes that a=1micron (the unit of lenght)
%epsilonv=[1;2];
muv=[1;1];
%muv=[1;1+100i];

direction=[0 0 -1];
pol=[1 0 0];

% direction=[1 0 0];
% pol=[0 1 0];


rsource=[0 0 0];
sourceinout=1;

%Radius=1.00000;
numberofpoints=100;
numberoftilesMatrix=2;

icont=1;
z=0;
numberoftiles=10;
xmin=-1;
xmax=1;
xstep=0.1;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia=date; %This is done so that if the simulation takes more than a day then you don't have problems saving the data.
%dia='28-Oct-2011';
if exist([directory, dia])==0
    mkdir([directory, dia]);
    [LineNodes,triangle,positions]= reader(name);
    TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
   save([directory, dia,'\',name,'.mat'],'TheMat','LineNodes','triangle','positions');
    TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
     [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions,sourceinout);
else
    if exist([directory, dia,'\',name,'.mat'])==0
    
        [LineNodes,triangle,positions]= reader(name);
        TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
        save([directory, dia,'\',name,'.mat'],'TheMat','LineNodes','triangle','positions');
        TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
       [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions,sourceinout);
    
    else
        Struct=load([directory, dia,'\',name,'.mat']);
        TheMat=Struct.TheMat;
       % LineNodes=Struct.LineNodes;
        %triangle=Struct.triangle;
        %positions=Struct.positions;
         [LineNodes,triangle,positions]= reader(name);
        
        clear('Struct');
        
         
         TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
       [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions,sourceinout);
    end
end
    
     
     
     Escatsqrparallel=sum(vecplotparallel.*conj(vecplotparallel),2);%sum(abs(vecplotparallel).^2,2);
     sigmascatparallel=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2*Escatsqrparallel];
     
     Escatsqrperpendm=sum(vecplotperpedicular.*conj(vecplotperpedicular),2);    %sum(abs(vecplotperpedicular),2);
     sigmascatperpend=[[0:2*pi/(numberofpoints-1):2*pi]',4*pi*Radius^2* Escatsqrperpendm];
     
 % [dipoles1,Quadrupoles1]=currents2MomentsVSH(k,epsilonv,muv,TheMat,TheV,name)%%ERASE!!! <--------------------------------------
%    valMomentsIntVSH1=MomentsIntVSH1(1,1,k,node,LineNodes,triangle,positions);%%ERASE!!! <--------------------------------------
     
    save([directory, dia,'\',name,'DrawingparallelperpendMatrix.mat'],'sigmascatparallel','sigmascatperpend'); 
    
    %polar(sigmascatparallel(:,1),sigmascatparallel(:,2));
    %polar(sigmascatperpend(:,1),sigmascatperpend(:,2));
    figure(1);
    polar([sigmascatparallel(:,1);NaN;sigmascatperpend(:,1)],[sigmascatparallel(:,2);NaN;sigmascatperpend(:,2)]); 
    figure(2);
     polar(sigmascatparallel(:,1),sigmascatparallel(:,2)); 
     figure(3)
      polar(sigmascatperpend(:,1),sigmascatperpend(:,2)); 
    % [Totalelectricdipole,Totalmagneticdipole]=effectivedipolecalculator(k,epsilonv,muv,TheMat,TheV,name);
    %       abtotma=abs(Totalmagneticdipole);
    %    abtotel=abs(Totalelectricdipole);
    %    abtot=[abtotel;abtotma];
    %     dipotot=[Totalelectricdipole;Totalmagneticdipole];
    %figure(4)
    %quiver3([0;0],[0;0],[0;0],abtot(:,1),abtot(:,2),abtot(:,3))
%           [alpha,NeeONhh,fvaltol]=PolarizabilityTensorCalculator(k,epsilonv,muv,TheMat,name);    
alpha=PolarizabilityTensorCalculator(k,epsilonv,muv,TheMat,name);    
savefiles=1;


[Dipoles,Quadrupoles]=VectorSphericalHarmonicsMultipoleRetrieval(k,epsilonv,muv,TheMat,TheV,direction,pol,rsource,name,sourceinout);

if savefiles==0

else
    alphaReal=real(alpha);
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\PolarizabilityReal',name,'_',num2str(lambda) ,'.txt'], 'alphaReal','-ascii');
alphaIm=imag(alpha);
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\Polarizability',name,'_',num2str(lambda) ,'.txt'], 'alphaIm','-ascii');
end
    
    

    