%%Quadrature based on the positions, weights and functions
%This function does the quadrature of the fnction "funcion" over the region
%made by the two triangles in the node list.
%it requires the positions in both triangles rpos1 and rpos2 which com from
%the function "BarycentGaussQuadPos(node,SPQ,LineNodes,triangle,positions)"



function quadval= BaryQuadratureSimpleOneNodeMomentsVSH1(l,m,k,rpos1rpt,rpos2rpt,weigthsrep,funcion,noderpt,rpt,LineNodes,triangle,positions,dimfun)


%rpt=7; Given that SPQ is a 7 position list of 3-vectors 

%nodenmr=size(node,1);
%weigths=weigths(:,(ones(nodenmr,1)));
%weigths=weigths(:);
%weigthsrep=repmat(weigths,nodenmr,1);


Area1=LineNodes(noderpt,6);
Area2=LineNodes(noderpt,7);

reptnmr=dimfun;

nodeevalnumbrpt=size(noderpt,1);

%this is the way to make the sum of 7  3-vectors in a list that contains 
%a 9 times repetition of the 7 3-vectors ,
%reshape(sum(reshape(t,7,[]),1),9,[]) by the way it also works with
%2-vector

valTerm1=funcion(l,m,rpos1rpt,noderpt,rpt,k,1,LineNodes,triangle,positions).*weigthsrep(:,ones(reptnmr,1));
valTerm2=funcion(l,m,rpos2rpt,noderpt,rpt,k,2,LineNodes,triangle,positions).*weigthsrep(:,ones(reptnmr,1));
quadval=...
   Area1(:,ones(reptnmr,1)).*reshape(sum(reshape(valTerm1,rpt,[]),1),nodeevalnumbrpt,[])+...
   Area2(:,ones(reptnmr,1)).*reshape(sum(reshape(valTerm2,rpt,[]),1),nodeevalnumbrpt,[]);


%%Quadrature based on the positions, weights and functions
%This function does the quadrature of the fnction "funcion" over the region
%made by the two triangles in the node list.
%it requires the positions in both triangles rpos1 and rpos2 which com from
%the function "BarycentGaussQuadPos(node,SPQ,LineNodes,triangle,positions)"


