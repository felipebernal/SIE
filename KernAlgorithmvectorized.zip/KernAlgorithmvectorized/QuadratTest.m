function valQuadratTest=QuadratTest(funcion,node,LineNodes,triangle,positions)

barycentryctable;
rpt=7;
[rpos1,rpos2]=BarycentGaussQuadPos(node,SPQ,LineNodes,triangle,positions);
valQuadratTest=BaryQuadrature(rpos1,rpos2, weigths,funcion,node,node,3,rpt,LineNodes,triangle,positions);
