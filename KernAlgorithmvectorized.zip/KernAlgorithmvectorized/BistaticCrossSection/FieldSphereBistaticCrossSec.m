function [vecplotparallel,vecplotperpedicular]=FieldSphereBistaticCrossSec(i,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions)


numberofpoints=100;
Radius=10;
center=[0,0,0];


thetapoints=[0:2*pi/(numberofpoints-1):2*pi]';

positionsphereparalel=[R*cos(thetapoints),0*thetapoints,R*sin(thetapoints)];
positionsphereperpedicular=[R*cos(thetapoints),R*sin(thetapoints),0*thetapoints];


% basepoints=[-R:(2*R/numberofpoints):R]';
% positionsphereparalel1=[basepoints,zeros(size(basepoints,1),1),sqrt(Radius^2-basepoints.^2)];%y=0
% positionssphereperpedicular1=[basepoints,sqrt(Radius^2-basepoints.^2),zeros(size(basepoints,1),1)];%z=0
% 
% basepoints=flipud(basepoints);
% positionsphereparalel2=[basepoints,zeros(size(basepoints,1),1),-sqrt(Radius^2-basepoints.^2)];%y=0
% positionssphereperpedicular2=[basepoints,-sqrt(Radius^2-basepoints.^2),zeros(size(basepoints,1),1)];%z=0
% 
% positionsphereparalel=[positionsphereparalel1;positionsphereparalel2];
% positionssphereperpedicular=[positionssphereperpedicular1;positionssphereperpedicular2];
% 


vecplotparallel=FieldEfinder(1,positionsphereparalel,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions);
vecplotperpedicular=FieldEfinder(1,positionsphereperpedicular,omega,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions);

% 
% MatPlot(indexm1:indexm2,indexn1:indexn2)=reshape(sqrt(sum(real(vectoplot).^2,2)),totalnodes/numblock,totalnodes/numblock);
% imagesc(real(MatPlot));
