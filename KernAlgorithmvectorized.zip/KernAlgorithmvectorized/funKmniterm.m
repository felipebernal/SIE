% this function is the product of the functions in the term of the
% integral Kmni, i.e.  f dot *div G cross f'

function funKmnitermval= funKmniterm(rtri,rtrip, nodetri,nodetrip,rpt,k,pm,pmp,LineNodes,triangle,positions)


%In this case p means prime. 
funKmnitermval=sum(RWGfunction(rtri,nodetri,rpt,pm,LineNodes,triangle,positions).*...
cross(DivGsmth(rtri,rtrip,k),RWGfunction(rtrip,nodetrip,rpt,pmp,LineNodes,triangle,positions),2),2);
