%%Double Quadrature based on the positions of two triangles for a 
%double quadrature. 
%This function does the double quadrature of the fnction "funcion" over the region
%made by the two triangles in rtri1 and rtri2.
%it requires the positions in both triangles rpos1 and rpos2 which may 
%come from the function "BarycentGaussQuadPos(node,SPQ,LineNodes,triangle,positions)"



function quadoubl= BaryDoubleTriQuadrature(tripm1,tripm2,rtri1,rtri2, weigths,funcion,nodetri1,nodetri2,k,rpt,LineNodes,triangle,positions)

%tripm1 and 2 defines if the double quadrature is being calculated for the
%combination triangle1+ triangle2+ , triangle1+ triangle2-, 
%triangle1-triangle2+,triangle1- triangle2- and therefore it is used to
%find the areas to use from LineNodes array.
% They can have values 1 for plus and 2 for minus
%
%The number of nodes for the function to calculate has to be the same for
%the tria1 than the tri2
%
nodenmr=size(nodetri1,1);
Rtri1=VECrpt3D(rtri1,rpt);
weigthTri1=repmat(VECrpt1D(weigths,rpt),nodenmr,1);
nodeListTri1=VECrpt1D(nodetri1,rpt^2);

Rtri2=repmatdiferent3D(rtri2,rpt,rpt);
weigthTri2=repmat(repmatdiferent1D(weigths,rpt,rpt),nodenmr,1); 


nodeListTri2=VECrpt1D(nodetri2,rpt^2);

%tripm1=tripm1+5;
%tripm2=tripm2+5;

Area1=LineNodes(nodetri1,tripm1+5);
Area2=LineNodes(nodetri2,tripm2+5);

termtosum=weigthTri1.*weigthTri2.*funcion(Rtri1,Rtri2,nodeListTri1,nodeListTri2,rpt,k,tripm1,tripm2,LineNodes,triangle,positions);


quadoubl=Area1.*Area2.*reshape(sum(reshape(termtosum,rpt^2,[]),1),nodenmr,[]);

%It is important to take into account that in order to make this double
%integral the function funcion, receives a list of the positions in
%triangle 1 and triangle 2 which are already permutated, together with a
%list of nodes wich tells the function to which node and triangle each pair
%of R's belongs to. this node list has the same dimensionality so the info
%is 1 to 1 and therefore rpt is not necesary. See that this is different
%than in the function Baryquadrature, where the list of nodes of the n
%triangle is not repeated and the info is given through rpt to the function funcion.