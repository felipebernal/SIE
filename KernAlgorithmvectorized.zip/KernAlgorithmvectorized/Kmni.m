function MatKmni = Kmni(i,omega,epsilonv,muv,LineNodes,triangle,positions,numberoftiles)
% This function sums the double integrations made in DmniNOTsmth 
%and Dmnismth.

%Just in case the memory is not enough to do all the computation 
%this function is in charge to fill the matrix by blocks...in that way we
%will be sure that there will be no problems for big structures.
%total number of nodes
epsilon=epsilonv(i);
mu=muv(i);
totalnodes=size(LineNodes,1);
%size of the blocks a divisor number of total nodes.
%This would be the maximum number of blocks that you would like to divide
%the matrix into...and it is using the great comon divisor of the number of
%nodes and a number specified by the user...here it will be 15. but
%depending on the size it can be bigger.
ndiv=numberoftiles; %If commented means that we want to do it ina single go.

%ndiv=1; %if comented it mwans that we want to divide the comput.
numblock=max(gcd(totalnodes,1:ndiv));
%nodeslist=1:totalnodes;
basenodelist=1:(totalnodes/numblock);
basenodelist=basenodelist';
%nodemlist=zeros(size(nodeslist,1),numblock^2);
%nodenlist=zeros(size(nodeslist,1),numblock^2);
%noden=VECrpt1D(basenodelist,totalnodes/numblock);
nodem=repmat(basenodelist,totalnodes/numblock,1);
MatDmni=zeros(totalnodes,totalnodes); 
for conta= 1:numblock
   noden=VECrpt1D(basenodelist,totalnodes/numblock); 
  for contb= 1:numblock
      indexn1=((contb-1)*(totalnodes/numblock)+1);
      indexn2=((contb)*(totalnodes/numblock));
      indexm1=((conta-1)*(totalnodes/numblock)+1); 
      indexm2=((conta)*(totalnodes/numblock));
      MatKmni(indexm1:indexm2,indexn1:indexn2)=reshape(...
           Kmnismth(Ki(i,omega,epsilonv,muv),mu,nodem,noden,LineNodes,triangle,positions)+...
         KmniNOTsmth(Ki(i,omega,epsilonv,muv),mu,nodem,noden,LineNodes,triangle,positions)...
         ,totalnodes/numblock,totalnodes/numblock);
    %Here we may have a problem of n and m indices I'm not sure if the reshaping is the one that we want.  
      %but it may very well be...chances...80% good 20% not good
     noden=(totalnodes/numblock)+noden;
     contb
  end
  nodem=(totalnodes/numblock)+nodem;
end