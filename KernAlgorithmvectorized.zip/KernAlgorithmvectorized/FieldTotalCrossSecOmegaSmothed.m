function vecplot=FieldTotalCrossSecOmegaSmothed

Radius=10;
numberofpoints=10;
epsilonv=[1;4];
muv=[1;1];
direction=[0 1 0];
pol=[1 0 0];
rsource=[0 0 0];
name='OmegaSmothedmedium';
[LineNodes,triangle,positions]= reader(name);

thetapoints=[0:pi/(numberofpoints-1):pi]';
phipoints=[0:2*pi/(numberofpoints-1):2*pi]';

alltheta=[0;VECrpt1D(thetapoints(2:(end-1)),(numberofpoints));pi];
allphi=[0;repmat(phipoints,(numberofpoints-2),1);0];
positionsphere=[Radius*sin(alltheta).*cos(allphi),Radius*sin(alltheta).*sin(allphi),Radius*cos(alltheta)];

dia='25-Oct-2011';
minlam=10000;
maxlam=36500;
deltalam=500;

vecplot=zeros(size([minlam:deltalam:maxlam]',1),1);
cont=1;

for c=minlam:deltalam:maxlam
    matrix=load(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\',name,'_',int2str(c),'_Matrix','.mat']);
    TheMat=matrix.TheMat;
    vector=load(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\',name,'_',int2str(c),'_Vector_','.mat']);
    TheV=vector.TheV;
   % clear('matrix','vector');
    
    valE=FieldEfinder(1,'scatt','far',positionsphere,(2*pi/(c/1000)),epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions);
    vecplot(cont)=(2*pi/(numberofpoints-1))*(pi/(numberofpoints-1))*(Radius^2)*sum(sin(alltheta).*(sum(valE.*conj(valE),2)),1);
    cont=cont+1;
end
a=[[minlam:deltalam:maxlam]',vecplot];
save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\TotalScattCrossSec.txt'], 'a','-ascii');

plot([minlam:deltalam:maxlam]',vecplot);
end