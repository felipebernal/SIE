function comparatorDipolevsSIEmoments

%%Maybe need a bit of work given that there was a change and I did not
%%tried it ever since,,,

ElectricOrMagnetoElectric=2;
name='minisphererefinedIII';
%name='minisphererefined';
%name='minisphere';




epsilonout=1;
muv=[1;4];

%Things used by dipole

mu0=muv(1);
musph=muv(2);

c=1;
center=[0,0,0];



directory='\\nanorfsrv\Users\Bernal\Simulations\';
%dia=date;
dia='22-May-2012';


%Things used by SIE
icont=1;
z=0;
numberoftiles=10;
xmin=-1;
xmax=1;
xstep=0.1;

sourceinout=1;
numberofpoints=100;
numberoftilesMatrix=1;



radiusbead=0.0099599;
%radiusbead=0.01;



Radius=10;


 [LineNodes,triangle,positions]= reader(name);
lowlim=50;
highlim=4000;
deltalim=100;

if ElectricOrMagnetoElectric==1
 %c
 compelectric=zeros(size([lowlim:deltalim:highlim]',1),4);

else
compelectric=zeros(size([lowlim:deltalim:highlim]',1),7);
compmagnetic=zeros(size([lowlim:deltalim:highlim]',1),7);

end

cont=1;
for lambda =lowlim:deltalim:highlim
    
    k=2*pi/(lambda/1000);
    omega=k*c;
    direction=[0 0 -1];
    pol=[1 0 0];
    rsource=[0 0 0];

epsilonv=[epsilonout;Gold(1000*(2*pi)/omega)];

%epsilonv=[epsilonout;-0.154+1i*5];

eps0=epsilonv(1);
eps=epsilonv(2);

if exist([directory, dia,'\',name,'_',num2str(lambda),'.mat'])==0
    
    [LineNodes,triangle,positions]= reader(name);
    TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
    
    TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
    save([directory, dia,'\',name,'_',num2str(lambda),'.mat'],'TheMat','TheV');
else
    Struct=load([directory, dia,'\',name,'_',num2str(lambda),'.mat']);
    TheMat=Struct.TheMat;
    TheV=Struct.TheV;
    %[LineNodes,triangle,positions]= reader(name);
    clear('Struct');
end


[Totalelectricdipole,Totalmagneticdipole]=effectivedipolecalculator(k,epsilonv,muv,TheMat,TheV,name);

%[Dipoles,Quadrupoles]=VectorSphericalHarmonicsMultipoleRetrieval(k,epsilonv,muv,TheMat,TheV,direction,pol,rsource,name,sourceinout);
%Totalelectricdipole=transpose(Dipoles(1:3));
%Totalmagneticdipole=transpose(Dipoles(4:6));




if ElectricOrMagnetoElectric==1 %justlectric otherwise magnetoelectric
 
    
    alphastatic=4*pi*((radiusbead)^3)*((eps-eps0)/(eps+2*eps0))*eye(3);  
    invalpha=inv(alphastatic)-(1i*(k)^3)/(6*pi)*eye(3);  
    %invalpha=inv(alphastatic)-(1i*(k)^3)/(6*pi)*eye(3)-((k^2)/(4*pi*(2*radiusbead)))*eye(3);  

    positioncenterbead=[0,0,0];
    E=PlaneWaveE(k,direction,pol,positioncenterbead);
    dipolemoment=E/invalpha;
   % compelectric(cont,:)=[lambda,Totalelectricdipole,dipolemoment];
     compelectric(cont,:)=[lambda,dipolemoment];
    
   cont=cont+1;
    
    
else
    
alphastaticelec=4*pi*((radiusbead)^3)*((eps-eps0)/(eps+2*eps0))*eye(3);
alphastaticmagnet=4*pi*((radiusbead)^3)*((musph-mu0)/(musph+2*mu0))*eye(3);
alphastatic=zeros(6,6);
alphastatic(1:3,1:3)=alphastaticelec;
alphastatic(4:6,4:6)=alphastaticmagnet;
invalpha=inv(alphastatic)-((1i*(k^3))/(6*pi))*eye(6);
positioncenterbead=[0,0,0];
E=PlaneWaveE(k,direction,pol,positioncenterbead);
H=PlaneWaveH(k,direction,pol,positioncenterbead);
dipolemoment=[E,H]/invalpha;
%dipolemoment=[dipolemoment(1:3);dipolemoment(4:6)];

compelectric(cont,:)=[lambda,Totalelectricdipole,dipolemoment(1:3)];
compmagnetic(cont,:)=[lambda,Totalmagneticdipole,dipolemoment(4:6)];
cont=cont+1;
end


end


if ElectricOrMagnetoElectric==1 %justlectric otherwise magnetoelectric
    
%     aux1=[compelectric(:,1),real(compelectric(:,2:7))];
%     aux2=[compelectric(:,1),imag(compelectric(:,2:7))];
%     save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleSIEvsDIPReal.txt'], 'aux1','-ascii');
%     save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleSIEvsDIPImag.txt'], 'aux2','-ascii');
%     
%     aux3=[compelectric(:,1),abs(compelectric(:,2:4)),abs(compelectric(:,5:7))];
%      save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleSIEvsDIPNORM.txt'], 'aux3','-ascii');
%      
%      
%      difelecdipole=compelectric(:,2:4)-compelectric(:,5:7);
%      auxerror=[compelectric(:,1),sqrt(sum(difelecdipole.*conj(difelecdipole),2)./(sum(compelectric(:,2:4).*conj(compelectric(:,2:4)),2)))];
%      save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleSIEvsDIPERROR.txt'], 'auxerror','-ascii');
%      
%     aux4=[compelectric(:,1),real(compelectric(:,2:4))];
%     aux5=[compelectric(:,1),imag(compelectric(:,2:4))];
%     save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleSIEReal.txt'], 'aux4','-ascii');
%     save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleSIEImag.txt'], 'aux5','-ascii');
    
    aux6=[compelectric(:,1),real(compelectric(:,2:4))];
    aux7=[compelectric(:,1),imag(compelectric(:,2:4))];
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleDIPReal.txt'], 'aux6','-ascii');
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleDIPImag.txt'], 'aux7','-ascii');
     
else
    aux1=[compelectric(:,1),real(compelectric(:,2:7))];
    aux2=[compelectric(:,1),imag(compelectric(:,2:7))];
    aux3=[compelectric(:,1),real(compmagnetic(:,2:7))];
    aux4=[compelectric(:,1),imag(compmagnetic(:,2:7))];
    
    aux5=[compelectric(:,1),abs(compelectric(:,2:4)),abs(compelectric(:,5:7))];
    aux6=[compmagnetic(:,1),abs(compmagnetic(:,2:4)),abs(compmagnetic(:,5:7))];
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleSIEvsDIPReal.txt'], 'aux1','-ascii');
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleSIEvsDIPImag.txt'], 'aux2','-ascii');
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\magneticdipoleSIEvsDIPReal.txt'], 'aux3','-ascii');
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\magneticdipoleSIEvsDIPImag.txt'], 'aux4','-ascii');
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleSIEvsDIPNORM.txt'], 'aux5','-ascii');
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\magneticdipoleSIEvsDIPNORM.txt'], 'aux6','-ascii');
    
    
    difelecdipole=compelectric(:,2:4)-compelectric(:,5:7);
    difmagdipole=compmagnetic(:,2:4)-compmagnetic(:,5:7);
    auxerror=[compelectric(:,1),sqrt(sum(difelecdipole.*conj(difelecdipole),2)./(sum(compelectric(:,2:4).*conj(compelectric(:,2:4)),2)))...
         ,sqrt(sum(difmagdipole.*conj(difmagdipole),2)./(sum(compmagnetic(:,2:4).*conj(compmagnetic(:,2:4)),2)))];
     save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\SIEvsDIPERROR.txt'], 'auxerror','-ascii');
    
    
    
end
    