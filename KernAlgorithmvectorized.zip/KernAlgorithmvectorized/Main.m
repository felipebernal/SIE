function [TheMat,TheV]=Main(omega,epsilonv,muv,direction,pol,rsource)

% omega=1;
% epsilonv=[1;15];
% muv=[1;1];
% direction=[1 1 0];
% pol=[0 0 1];
% rsource=[0 0 0];
reader;
TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions);
TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,1);



