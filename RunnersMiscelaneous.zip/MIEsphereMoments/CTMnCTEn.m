function [CTMn,CTEn]=CTMnCTEn(n,a,omega, epsilonv, muv)

%n is the index, a is the radius of the sphere, omega is the frequency,
%epsilon is the vector with the permeavility outside(2) and inside(1)
%mu is the vector with the permitivity % inside(2) and outside(1)
c=1;

k0=(omega/c)*sqrt(epsilonv(1)*muv(1));
k1=(omega/c)*sqrt(epsilonv(2)*muv(2));

eps0=epsilonv(1);
eps1=epsilonv(2);

mu0=muv(1);
mu1=muv(2);

CTMn=(eps1*jspbess(n,a*k1)*jp(n,a*k0)-eps0*jspbess(n,a*k0)*jp(n,a*k1))./(eps0*jp(n ,a*k1)*h(n,a*k0)-eps1*jspbess(n,a*k1)*hp(n,a*k0));
CTEn=(mu1*jspbess(n,a*k1)*jp(n,a*k0)-mu0*jspbess(n,a*k0)*jp(n,a*k1))./(mu0*jp(n,a*k1)*h(n,a*k0)-mu1*jspbess(n,a*k1)*hp(n,a*k0));

    function valj=jspbess(n,x)%spherical bessel function j
       valj=sqrt(pi/(2*x)).*besselj(n+1/2,x); 
    end
    function valjp=jp(n,x)%derivative of the spherical bessel by x
        %valjp=(n*jspbess(n,x))./x-jspbess(n+1,x);
        valjp=(n+1)*jspbess(n,x)-x.*jspbess(n+1,x);
    end

    function valh=h(n,x)%spherical hankel funciton of the first type
        valh=sqrt(pi/(2*x)).*besselh(n+1/2,1,x);  
    end
    function valhp=hp(n,x)%derivative of the spherical hankel function of the first type by x
      %valhp=(n*h(n,x))./x-h(n+1,x); 
            valhp=(n+1)*h(n,x)-x.*h(n+1,x); 
       end

end