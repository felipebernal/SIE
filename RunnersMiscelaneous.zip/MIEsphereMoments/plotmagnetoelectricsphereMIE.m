function [alfae,alfah,lislambda]=plotmagnetoelectricsphereMIE
% inside(2) and outside(1)

%radius=0.01;
radius=0.0099605;
%radius=0.01147;

c=1;

%numpoints=100;
numpoints=1000;
cont=1;
lislambda=linspace(100,4000,numpoints).';
%lislambda1=[25:25:500].';
%lislambda2=[550:100:4000].';
%lislambda=[lislambda1;lislambda2];
alfae=zeros(size(lislambda,1),1);
alfah=zeros(size(lislambda,1),1);


for lambda=lislambda.'
muv=[1,4];   
epsilonv=[1,Gold(lambda)];
omega=2*pi*c/(lambda/1000);
[alphaee,alphahh]=dipoleMomentMIE(radius,omega,epsilonv,muv);

alfae(cont)=alphaee;
alfah(cont)=alphahh;
cont=cont+1;
end

figure(1)
semilogx(lislambda,abs(alfae),'.',lislambda,abs(alfah),'.')
%plot(lislambda,abs(alfae),'.',lislambda,abs(alfah),'.')

figure(2)
semilogx(lislambda,angle(alfae),'.',lislambda,angle(alfah),'.')