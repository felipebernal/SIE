%function [total,vecheight]=volumefinder
p=path;
path(p,'\\nanorfsrv\Users\Bernal\Theory\KernAlgorithmvectorized');
[LineNodes,triangle,positions]=reader('minisphererefinedIII');

p1=positions(triangle(:,1),:);
p2=positions(triangle(:,2),:);
p3=positions(triangle(:,3),:);
b=cross((p2-p1),(p3-p1),2);
bnorm=sqrt(sum(b.^2,2));
Area=(0.5)*bnorm;
n=b./bnorm(:,ones(3,1));
vecheight=sum((p1).*n,2);
total=sum((Area.*vecheight)/3,1);