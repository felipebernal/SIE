
function  runnerscattcrossSphere4ComparisonFFTsphereVSHandCurrents
% [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]=
    %[sigmascatparallel, sigmascatperpend]=
   p=path;
path(p,'\\nanorfsrv\Users\Bernal\Theory\KernAlgorithmvectorized');
p=path;
path(p,'\\nanorfsrv\Users\Bernal\Theory\KernAlgorithmvectorized\MultipoleMomentsFFT');

%omega=pi;
muv=[1;4];
direction=[0 0 -1];
pol=[1 0 0];
rsource=[0 0 0];

sourceinout=1;

numberofpoints=100;
numberoftilesMatrix=1;

name='minisphererefinedIII';


directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia='22-May-2012';
if exist([directory, dia])==0
    mkdir([directory, dia]);
end
[LineNodes,triangle,positions]= reader(name);
%              sig=0;
%         sigmascat=0;
for lambda=25:25:500
    omega=1000*(2*pi)/lambda;
    epsilonv=[1;Gold(1000*(2*pi)/omega)]; %This one suposes that a=1micron (the unit of lenght)
    TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
    save([directory, dia,'\',name,'_',int2str(lambda),'_','Matrix.mat'],'TheMat');
    TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
    save([directory, dia,'\',name,'_',int2str(lambda),'_','Vector_.mat'],'TheV');
    %         vecplot=FieldTotalCrossSec(Radius,numberofpoints,icont,z,xmin,xmax,xstep,TheV,TheMat,numberoftiles,omega,epsilonv,muv,direction,pol,rsource,LineNodes,triangle,positions);
    %         EscatEnerDen=sum(vecplot.*conj(vecplot),2);
    %         sigmascat(end+sig)=4*pi*Radius^2*sum(Escatsqrparallel,1);
    %         sig=1;
    %          save([directory, date,'\',name,'_',int2str(omega*10),'_','sigmascat.mat'],'sigmascat');
end
%         save([directory, date,'\',name,'TOTALsigmascat.mat'],'sigmascat');
%
end

% plot(omega,sigmascat);