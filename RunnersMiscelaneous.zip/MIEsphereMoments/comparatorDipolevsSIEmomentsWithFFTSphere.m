function [compelectric,compmagnetic]=comparatorDipolevsSIEmomentsWithFFTSphere


p=path;
path(p,'\\nanorfsrv\Users\Bernal\Theory\KernAlgorithmvectorized');
p=path;
path(p,'\\nanorfsrv\Users\Bernal\Theory\KernAlgorithmvectorized\MultipoleMomentsFFT');

ElectricOrMagnetoElectric=2;
name='minisphererefinedIII';
%name='minisphererefined';
%name='minisphere';




epsilonout=1;
muv=[1;4];

%Things used by dipole

mu0=muv(1);
musph=muv(2);

c=1;
center=[0,0,0];



directory='\\nanorfsrv\Users\Bernal\Simulations\';
%dia=date;
dia='22-May-2012';


%Things used by SIE
icont=1;
z=0;
numberoftiles=10;
xmin=-1;
xmax=1;
xstep=0.1;

sourceinout=1;
numberofpoints=100;
numberoftilesMatrix=1;



%radiusbead=0.0099599;
radiusbead=0.01;



Radius=10;


[LineNodes,triangle,positions]= reader(name);



%lowlim=50;
%highlim=4000;
%deltalim=100;


lislambda1=[25:25:500].';
lislambda2=[550:100:4000].';
lislambda=[lislambda1;lislambda2];



compelectric=zeros(size(lislambda,1),4);
compmagnetic=zeros(size(lislambda,1),4);
    

cont=1;

for cont=1:size(lislambda,1)
    
    lambda=lislambda(cont);
      
    k=2*pi/(lambda/1000);
    omega=k*c;
    direction=[0 0 -1];
    pol=[1 0 0];
    rsource=[0 0 0];
    
    epsilonv=[epsilonout;Gold(1000*(2*pi)/omega)];
    
    %epsilonv=[epsilonout;-0.154+1i*5];
    
    eps0=epsilonv(1);
    eps=epsilonv(2);
    
    if exist([directory, dia,'\',name,'_',num2str(lambda),'.mat'])==0
        
        [LineNodes,triangle,positions]= reader(name);
        TheMat=TheMatrixFiller(omega,epsilonv,muv,LineNodes,triangle,positions,numberoftilesMatrix);
        
        TheV=TheVectorFiller(omega,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
        save([directory, dia,'\',name,'_',num2str(lambda),'.mat'],'TheMat','TheV');
    else
        
        if exist([directory, dia,'\',name,'_',num2str(lambda),'_Vector_.mat'])==0
        Struct=load([directory, dia,'\',name,'_',num2str(lambda),'.mat']);
        TheMat=Struct.TheMat;
        TheV=Struct.TheV;
        %[LineNodes,triangle,positions]= reader(name);
        clear('Struct');
    
        else
             Struct=load([directory, dia,'\',name,'_',num2str(lambda),'.mat']);
        TheMat=Struct.TheMat;
       TheVstruct=load([directory, dia,'\',name,'_',num2str(lambda),'_Vector_.mat']);
       TheV=TheVstruct.TheV;
        %[LineNodes,triangle,positions]= reader(name);
        clear('Struct');
        clear('TheVstruct');
               
        end
    
    FieldE=@(X)FieldEfinder(1,'scatt','near',X,k,epsilonv,muv,direction,pol,rsource,@PlaneWaveE,@PlaneWaveH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
    epsilon=epsilonv(1);
    mu=muv(1);
    [p,m,Q]=FFTDipolesandQuadrupoles(10,FieldE,omega,epsilon,mu);
    
    %[Totalelectricdipole,Totalmagneticdipole]=effectivedipolecalculator(k,epsilonv,muv,TheMat,TheV,name);
    %[Dipoles,Quadrupoles]=VectorSphericalHarmonicsMultipoleRetrieval(k,epsilonv,muv,TheMat,TheV,direction,pol,rsource,name,sourceinout);
    %Totalelectricdipole=transpose(Dipoles(1:3));
    %Totalmagneticdipole=transpose(Dipoles(4:6));
    
        compelectric(cont,:)=[lambda,p.'];
        compmagnetic(cont,:)=[lambda,m.'];
        cont=cont+1
      
    
end


    aux1=[compelectric(:,1),real(compelectric(:,2:4))];
    aux2=[compelectric(:,1),imag(compelectric(:,2:4))];
    aux3=[compelectric(:,1),real(compmagnetic(:,2:4))];
    aux4=[compelectric(:,1),imag(compmagnetic(:,2:4))];
    
    aux5=[compelectric(:,1),abs(compelectric(:,2:4))];
    aux6=[compmagnetic(:,1),abs(compmagnetic(:,2:4))];
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleSIEvsDIPReal.txt'], 'aux1','-ascii');
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleSIEvsDIPImag.txt'], 'aux2','-ascii');
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\magneticdipoleSIEvsDIPReal.txt'], 'aux3','-ascii');
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\magneticdipoleSIEvsDIPImag.txt'], 'aux4','-ascii');
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\electricdipoleSIEvsDIPNORM.txt'], 'aux5','-ascii');
    save(['\\nanorfsrv\Users\Bernal\Simulations\',dia,'\magneticdipoleSIEvsDIPNORM.txt'], 'aux6','-ascii');
    
   
       
    
end
