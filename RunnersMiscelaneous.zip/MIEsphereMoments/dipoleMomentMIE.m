function [alphaee,alphahh]=dipoleMomentMIE(radius,omega,epsilonv,muv)
% inside(2) and outside(1)

eps0=epsilonv(1);
eps1=epsilonv(2);

mu0=muv(1);
mu1=muv(2);

c=1;
k0=(omega/c)*sqrt(eps0*mu0);
[CTMn,CTEn]=CTMnCTEn(1,radius,omega, epsilonv, muv);
alphaee=-(6*pi*1i*eps0*CTMn)./(k0^3);
alphahh=-(6*pi*1i*CTEn)./(k0^3);
end