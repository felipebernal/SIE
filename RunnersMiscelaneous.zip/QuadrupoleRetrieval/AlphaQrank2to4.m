function Alphaijmn=AlphaQrank2to4(alphaQ)

%in this function we get the alphaQ given as a rank 2 tensor
%with the upper part of the symetric matrix and we convert it into a
%4th rank tensor ready for being corrected for the substrate.
Alphaijmn=zeros(3,3,3,3);
line1=alphaQ(1,:);
line2=alphaQ(2,:);
line3=alphaQ(3,:);
line4=alphaQ(4,:);
line5=alphaQ(5,:);
line6=alphaQ(6,:);
mat1=fromlinetosymMat(line1);
mat2=fromlinetosymMat(line2);
mat3=fromlinetosymMat(line3);
mat4=fromlinetosymMat(line4);
mat5=fromlinetosymMat(line5);
mat6=fromlinetosymMat(line6);

Alphaijmn(1:3,1:3,1,1)=mat1;
Alphaijmn(1:3,1:3,1,2)=mat2;
Alphaijmn(1:3,1:3,1,3)=mat3;
Alphaijmn(1:3,1:3,2,2)=mat4;
Alphaijmn(1:3,1:3,2,3)=mat5;
Alphaijmn(1:3,1:3,3,3)=mat6;
Alphaijmn(1:3,1:3,2,1)=Alphaijmn(1:3,1:3,1,2);
Alphaijmn(1:3,1:3,3,1)=Alphaijmn(1:3,1:3,1,3);
Alphaijmn(1:3,1:3,3,2)=Alphaijmn(1:3,1:3,2,3);


end

function Symmat=fromlinetosymMat(Line)
Symmat=zeros(3,3);
Symmat(1,1)=Line(1);
Symmat(1,2)=Line(2);
Symmat(1,3)=Line(3);
Symmat(2,2)=Line(4);
Symmat(2,3)=Line(5);
Symmat(3,3)=Line(6);
Symmat(2,1)=Symmat(1,2);
Symmat(3,1)=Symmat(1,3);
Symmat(3,2)=Symmat(2,3);
end