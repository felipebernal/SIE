function... [omega,epsilonv,muv,direction,pol,rsource,i,z,TheV,TheMat,LineNodes,triangle,positions]=
    ...[sigmascatparallel, sigmascatperpend,TheMat,TheV]=runnerBistatic(Radius,name)
    ...   [Totalelectricdipole,Totalmagneticdipole,alpha,NeeONhh,fvaltol,moments]=runnerBistatic(Radius,name)
    ...    [Totalelectricdipole,Totalmagneticdipole,Dipoles,Quadrupoles,alpha]
alphaQfinal=TestQuadrupolalphaSphereIII

p=path;
path(p,'\\nanorfsrv\Users\Bernal\Theory\KernAlgorithmvectorized');
p1=path;
path(p1,'\\nanorfsrv\Users\Bernal\Theory\KernAlgorithmvectorized\MultipoleMomentsFFT');


Radius=100;
name='minisphererefinedIII';



numberofpoints=100;
numberoftilesMatrix=2;

icont=1;
z=0;
numberoftiles=10;
xmin=-1;
xmax=1;
xstep=0.1;

directory='\\nanorfsrv\Users\Bernal\Simulations\';
dia='22-May-2012';
% minlambda=400;
% maxlambda=1000;
% deltalambda=5;

%vecwaveelengths=[minlambda:deltalambda:maxlambda].';
%numwavelengths=size(vecwaveelengths,1);
%alphavector=zeros(6,6,numwavelengths);
%cont=1;

%for lambda=minlambda:deltalambda:maxlambda

lambda=650;


surname=['_',int2str(lambda),'_Matrix'];
omega=2*pi/(lambda/1000); %ToonCylindercurved
%lambda=(2*pi/omega)*1000;
epsilonv=[1;Gold(lambda)]; %This one suposes that a=1micron (the unit of lenght)
muv=[1;1];
Struct=load([directory, dia,'\',name,'_',num2str(lambda),'.mat']);
TheMat=Struct.TheMat;
[LineNodes,triangle,positions]= reader(name);
clear('Struct');
shiftsphere=[0,0,0];
%        alphamat=PolarizabilityTensorCalculator(omega,epsilonv,muv,TheMat,name,shiftsphere);
alphaQfinal=QuadruPolarizabilityTensorCalculator(omega,epsilonv,muv,TheMat,name,shiftsphere);

%alphavector(:,:,cont)=alphamat(:,:);
%cont=cont+1;
%end
%save([directory, dia,'\',name,'_alphas.mat'],'alphavector','vecwaveelengths');

