
    function alphafinal=BackupSuperPolarizabilityTensorCalculator(omega,epsilonv,muv,TheMat,name,shiftedcentersphere)
        %This function retrieves the Quadrupolarizability tensor by doing six different
        %calculations over the system then it retrieves the quadrupole moments and we
        %know that the matrix Q made out the quadrupolee moment amde into a vector in columns of 6
        %simulations so 6 coulums multiplied by the inverse of the matrix (nabla E-E nabla)/2 made by
        %the six different input fields gives alphaQ which is the Quadrupolarizability
        %matrix.
        % In other words b dot inv((nabla E E nabla)/2)=alpha.
        sourceinout=1;
        c=1;
        k=(omega/c)*sqrt(epsilonv(1)*muv(1));
        
        %directory='\\nanorfsrv\Users\Bernal\Simulations\';
        %dia=date;
        
        [LineNodes,triangle,positions]= reader(name);
        rsource=[0,0,0];
        positioncenterstructure=[0,0,0];
        

% %original
% polarizationmatrix=[1,0,0;...%these are the excitations for the dipoles
%                     0,1,0;...
%                     0,0,1;...
%                     1,0,0;...
%                     0,1,0;...
%                     0,0,1;...
%                     1,0,0;...%these are the excitations for the quadrupoles
%                     0,1,0;...
%                     0,0,1;...
%                     1/sqrt(2),1/sqrt(2),0;...
%                     1/sqrt(2),0,1/sqrt(2);...
%                     0,1/sqrt(2),1/sqrt(2)];
%new
polarizationmatrix=[1,0,0;...%these are the excitations for the dipoles
                    0,1,0;...
                    0,0,1;...
                    1,0,0;...
                    0,1,0;...
                    0,0,1;...
                    1/sqrt(6),1/sqrt(6),-2/sqrt(6);...%these are the excitations for the quadrupoles
                    1/sqrt(6),-1/sqrt(6),-2/sqrt(6);...
                    1/sqrt(2),1/sqrt(2),0;...
                    1/sqrt(2),0,1/sqrt(2);...
                    0,1/sqrt(2),1/sqrt(2)];
   
                
 %%% the direction matrix is simply the k of the counterpropagating beams


% %%%original
%  directionmatrix=[0,1,0;...%these are the excitations for the dipoles
%                   1,0,0;...
%                   1,0,0;...
%                   0,1,0;...
%                   0,0,1;...
%                   1,0,0;...
%                   1,0,0;...%these are the excitations for the quadrupoles
%                   0,1,0;...
%                   0,0,1;...
%                   1/sqrt(2),-1/sqrt(2),0;...
%                   1/sqrt(2),0,-1/sqrt(2);...
%                   0,1/sqrt(2),-1/sqrt(2)]; 
  %%%new
 directionmatrix=[0,1,0;...%these are the excitations for the dipoles
                  1,0,0;...
                  1,0,0;...
                  0,1,0;...
                  0,0,1;...
                  1,0,0;...
                  1/sqrt(3),1/sqrt(3),1/sqrt(3);...%these are the excitations for the quadrupoles
                  1/sqrt(3),-1/sqrt(3),1/sqrt(3);...
                  1/sqrt(2),-1/sqrt(2),0;...
                  1/sqrt(2),0,-1/sqrt(2);...
                  0,1/sqrt(2),-1/sqrt(2)];           
        sizeN=size(directionmatrix,1);
        vectorDipQuad=zeros(12,1);
        vecExc=zeros(12,1);
        MatDipQ=zeros(12,sizeN);
        MatExc=zeros(12,sizeN);
        
        D0=1/(1i*k);%this is just a normalization constant.
       
        for dircont=1:sizeN
            
            direction=directionmatrix(dircont,:);
            pol=polarizationmatrix(dircont,:);
            
            if dircont<=3
                CounterpropE=@(om,di,po,reval,rso,m,ep,souinout) (1/2)*(PlaneWaveE(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveE(om,-1*di,po,reval,rso,m,ep,souinout));
                CounterpropH=@(om,di,po,reval,rso,m,ep,souinout) (1/2)*(PlaneWaveH(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveH(om,-1*di,po,reval,rso,m,ep,souinout));
                dxE=-sin(k*sum(direction.*positioncenterstructure,2))*k*direction(1)*pol;
                dyE=-sin(k*sum(direction.*positioncenterstructure,2))*k*direction(2)*pol;
                dzE=-sin(k*sum(direction.*positioncenterstructure,2))*k*direction(3)*pol;
%                 dxE=(CounterpropE(k,direction,pol,positioncenterstructure+[(1/k)*0.000001,0,0],0*positioncenterstructure,muv,epsilonv,1)-CounterpropE(k,direction,pol,positioncenterstructure-[(1/k)*0.000001,0,0],0*positioncenterstructure,muv,epsilonv,1))./((2/k)*0.000001);  
%                 dyE=(CounterpropE(k,direction,pol,positioncenterstructure+[0,(1/k)*0.000001,0],0*positioncenterstructure,muv,epsilonv,1)-CounterpropE(k,direction,pol,positioncenterstructure-[0,(1/k)*0.000001,0],0*positioncenterstructure,muv,epsilonv,1))./((2/k)*0.000001);      
%                 dzE=(CounterpropE(k,direction,pol,positioncenterstructure+[0,0,(1/k)*0.000001],0*positioncenterstructure,muv,epsilonv,1)-CounterpropE(k,direction,pol,positioncenterstructure-[0,0,(1/k)*0.000001],0*positioncenterstructure,muv,epsilonv,1))./((2/k)*0.000001);      
%              
                
            elseif dircont>3&&dircont<=6
                CounterpropE=@(om,di,po,reval,rso,m,ep,souinout) (1/2)*(PlaneWaveE(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveE(om,-1*di,-1*po,reval,rso,m,ep,souinout));
                CounterpropH=@(om,di,po,reval,rso,m,ep,souinout) (1/2)*(PlaneWaveH(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveH(om,-1*di,-1*po,reval,rso,m,ep,souinout));
                dxE=1i*cos(k*sum(direction.*positioncenterstructure,2))*k*direction(1)*pol;
                dyE=1i*cos(k*sum(direction.*positioncenterstructure,2))*k*direction(2)*pol;
                dzE=1i*cos(k*sum(direction.*positioncenterstructure,2))*k*direction(3)*pol;
                       % vecdExc=[D0*(-2*1i*k*direction(1)*pol(1))*cos(k*sum(direction.*positioncenterstructure,2));...
%                      D0*(-1i*k*(direction(2)*pol(1)+direction(1)*pol(2)))*cos(k*sum(direction.*positioncenterstructure,2));...
%                      D0*(-1i*k*(direction(3)*pol(1)+direction(1)*pol(3)))*cos(k*sum(direction.*positioncenterstructure,2));...
%                      D0*(-2*1i*k*direction(2)*pol(2))*cos(k*sum(direction.*positioncenterstructure,2));...
%                      D0*(-1i*k*(direction(3)*pol(2)+direction(2)*pol(3)))*cos(k*sum(direction.*positioncenterstructure,2));...
%                      D0*(-2*1i*k*direction(3)*pol(3))*cos(k*sum(direction.*positioncenterstructure,2))];
            elseif dircont>6&&dircont<=9
                CounterpropE=@(om,di,po,reval,rso,m,ep,souinout) D0*(PlaneWaveE(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveE(om,-1*di,-1*po,reval,rso,m,ep,souinout));
                CounterpropH=@(om,di,po,reval,rso,m,ep,souinout) D0*(PlaneWaveH(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveH(om,-1*di,-1*po,reval,rso,m,ep,souinout));
                dxE=D0*1i*cos(k*sum(direction.*positioncenterstructure,2))*k*direction(1)*pol;
                dyE=D0*1i*cos(k*sum(direction.*positioncenterstructure,2))*k*direction(2)*pol;
                dzE=D0*1i*cos(k*sum(direction.*positioncenterstructure,2))*k*direction(3)*pol;
            
            elseif dircont>9&&dircont<=12
                CounterpropE=@(om,di,po,reval,rso,m,ep,souinout) D0*(PlaneWaveE(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveE(om,-1*di,-1*po,reval,rso,m,ep,souinout));
                CounterpropH=@(om,di,po,reval,rso,m,ep,souinout) D0*(PlaneWaveH(om,di,po,reval,rso,m,ep,souinout)+PlaneWaveH(om,-1*di,-1*po,reval,rso,m,ep,souinout));
                dxE=D0*1i*cos(k*sum(direction.*positioncenterstructure,2))*k*direction(1)*pol;
                dyE=D0*1i*cos(k*sum(direction.*positioncenterstructure,2))*k*direction(2)*pol;
                dzE=D0*1i*cos(k*sum(direction.*positioncenterstructure,2))*k*direction(3)*pol;
                
                
                %                 vecdExc=[D0*(-2*1i*k*direction(1)*pol(1))*cos(k*sum(direction.*positioncenterstructure,2));...
%                      D0*(-1i*k*(direction(2)*pol(1)+direction(1)*pol(2)))*cos(k*sum(direction.*positioncenterstructure,2));...
%                      D0*(-1i*k*(direction(3)*pol(1)+direction(1)*pol(3)))*cos(k*sum(direction.*positioncenterstructure,2));...
%                      D0*(-2*1i*k*direction(2)*pol(2))*cos(k*sum(direction.*positioncenterstructure,2));...
%                      D0*(-1i*k*(direction(3)*pol(2)+direction(2)*pol(3)))*cos(k*sum(direction.*positioncenterstructure,2));...
%                      D0*(-2*1i*k*direction(3)*pol(3))*cos(k*sum(direction.*positioncenterstructure,2))];
           end
            




            TheV=TheVectorFiller(omega,direction,pol,rsource,CounterpropE,CounterpropH,LineNodes,triangle,positions,muv,epsilonv,sourceinout);
                        
            FieldE=@(X)FieldEfinder(1,'scatt','far',X,k,epsilonv,muv,direction,pol,rsource, CounterpropE,CounterpropH,TheV,TheMat,LineNodes,triangle,positions,sourceinout);
                    
            epsilon=epsilonv(1);
            mu=muv(1);
            radiusFFTsphere=1;
            [electricdipole,magneticdipole,Quadrupoles]=FFTDipolesandQuadrupoles(radiusFFTsphere,FieldE,omega,epsilon,mu,shiftedcentersphere);
            
            vectorDipQuad(1)=electricdipole(1);
            vectorDipQuad(2)=electricdipole(2);
            vectorDipQuad(3)=electricdipole(3);
            vectorDipQuad(4)=magneticdipole(1);
            vectorDipQuad(5)=magneticdipole(2);
            vectorDipQuad(6)=magneticdipole(3);
            vectorDipQuad(7)=Quadrupoles(1,1);
            vectorDipQuad(8)=Quadrupoles(1,2);
            vectorDipQuad(9)=Quadrupoles(1,3);
            vectorDipQuad(10)=Quadrupoles(2,2);
            vectorDipQuad(11)=Quadrupoles(2,3);
            vectorDipQuad(12)=Quadrupoles(3,3);
            MatDipQ(:,dircont)=vectorDipQuad;
            
           
            vecdExc=(1/2)*[2*dxE(1);...
                dxE(2)+dyE(1);...
                dxE(3)+dzE(1);...
                2*dyE(2);...
                dyE(3)+dzE(2);...
                2*dzE(3)];  
            
            E=CounterpropE(k,direction,pol,positioncenterstructure,0*positioncenterstructure,muv,epsilonv,1);%Here we put 1 toignore the values  sourceinout
            H=CounterpropH(k,direction,pol,positioncenterstructure,0*positioncenterstructure,muv,epsilonv,1);%Here we put 1 toignore the values  sourceinout
            MatExc(:,dircont)=[E.';H.';vecdExc];
         end
        alphafinal=MatDipQ/MatExc; %This is the same as MatP*inv(MatE)
       
    end

    
    
    function [p,m,Q]=FFTDipolesandQuadrupoles(radius,FieldE,omega,epsilon,mu,shiftsphere)
        
        %radius is how far from the center we want to make the projection
        %FieldE is a function that when given a (nx3) vector with [x,y,z] positions
        %gives the scattered electric field.
        
        %Get the points where the fields and functions need to be found
        %And do it for a maximum order nmax of your Ynm's
        c=1;
        k=(omega/c)*sqrt(epsilon*mu);
        nmax=6;
        %The weights and points are found with the gauss-legendre quadrature function
        %from numerical recipies
        [thetaspecial,phispecial,weights,thetagrid,phigrid]=sphergrid(nmax);
        
        %Now we evaluate our functions in these special points at a given radius.
        %the fucntions come from the paper of mhulig  and rokstuhl Metamaterials 5 (2011) 64�73
        %These functions are the eq 7 but with out the conjugate(Ynm)sin(theta).
        
        positions=[radius.*sin(thetaspecial).*cos(phispecial),radius.*sin(thetaspecial).*sin(phispecial),radius.*cos(thetaspecial)]+repmat(shiftsphere,size(thetaspecial,1),1);
        Exyz=FieldE(positions);
        Er=sin(thetaspecial).*cos(phispecial).*Exyz(:,1)+sin(thetaspecial).*sin(phispecial).*Exyz(:,2)+cos(thetaspecial).*Exyz(:,3);
        Etheta=cos(thetaspecial).*cos(phispecial).*Exyz(:,1)+cos(thetaspecial).*sin(phispecial).*Exyz(:,2)-sin(thetaspecial).*Exyz(:,3);
        Ephi=-sin(phispecial).*Exyz(:,1)+cos(phispecial).*Exyz(:,2);
        
        %First the a values
        
        n=1;m=0;
        a10=anm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        b10=bnm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        n=1;m=1;
        a11=anm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        b11=bnm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        n=1;m=-1;
        a1m1=anm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        b1m1=bnm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        
        n=2;m=0;
        a20=anm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        b20=bnm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        
        n=2;m=-1;
        a2m1=anm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        b2m1=bnm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        n=2;m=1;
        a21=anm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        b21=bnm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        n=2;m=-2;
        a2m2=anm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        b2m2=bnm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        n=2;m=2;
        a22=anm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        b22=bnm(thetaspecial,phispecial,radius,k,Er,Etheta,Ephi,weights,n,m);
        
        eps0=1;
        mu0=1;
        c=1;
        Z0=sqrt(mu0/eps0);
        %Z0=sqrt((mu0*mu)/(eps0*epsilon));
        
        %C0=(sqrt(6*pi)*1i)/(c*Z0*k);
        %C0=(2*sqrt(6)*pi*1i)/(c*Z0*k);%this fixes something
        C0=(2*sqrt(6)*pi*1i)/(c*Z0*k^3);%this fixes the k value problem
        %C0=(2*sqrt(6)*pi*1i)/(c*k^3)*Z0;%this fixes the k value problem
        %D0=6*sqrt(30)*pi/(1i*Z0*c*k^3);
        D0=-2*1i*6*sqrt(30)*pi/(1i*Z0*c*k^4);
        
        Px=epsilon*C0*(a11-a1m1);
        Py=epsilon*C0*1i*(a11+a1m1);
        Pz=epsilon*C0*(-sqrt(2)*a10);
        
        Mx=-(sqrt(mu)*sqrt(epsilon))*1i*c*C0*(b11-b1m1);
        My=-(sqrt(mu)*sqrt(epsilon))*1i*c*C0*1i*(b11+b1m1);
        Mz=-(sqrt(mu)*sqrt(epsilon))*1i*c*C0*(-sqrt(2)*b10);
        
        p=[Px;Py;Pz];
        m=[Mx;My;Mz];
        
      Qxx=(1/mu)*D0*(1i*(a22+a2m2)-1i*(sqrt(6)/2)*a20*2/3);
Qxy=(1/mu)*D0*(a2m2-a22);
Qxz=(1/mu)*D0*(1i*(a2m1-a21));
Qyx=(1/mu)*D0*(a2m2-a22);
Qyy=(1/mu)*D0*(-1i*(a22+a2m2)-1i*(sqrt(6)/2)*a20*2/3);
Qyz=(1/mu)*D0*(a2m1+a21);
Qzx=(1/mu)*D0*(1i*(a2m1-a21));
Qzy=(1/mu)*D0*(a2m1+a21);
Qzz=(1/mu)*D0*(1i*sqrt(6)*a20)*2/3;
Q=[Qxx,Qxy,Qxz;Qyx,Qyy,Qyz;Qzx,Qzy,Qzz];
        
        function vala=anm(theta,phi,radius,k,Fieldr,Fieldtheta,Fieldphi,w,n,m)
            
            weightint=VECrpt1D(w.',size(theta,1)/size(w,2));
            pnmval=Pnm(cos(theta),n,m);
            normalization=sqrt(pi*(2*n+1)*factorial(n-m)/factorial(n+m));
            normalizationplus1=sqrt(pi*(2*(n+1)+1)*factorial((n+1)-m)/factorial((n+1)+m));
            %         if m>=0
            %         normalization=((2*n+1)/2)*factorial(n-m)/factorial(n+m);
            %         normalizationplus1=((2*(n+1)+1)/2)*factorial((n+1)-m)/factorial((n+1)+m);
            %         elseif m<0
            %         normalization=(((2*n+1)/2));
            %         normalizationplus1=(((2*(n+1)+1)/2));
            %         end
            [valFAUpR,valFAUpPhi,valFAUpTheta1,valFAUpTheta2,valFABottR,valFABottPhi,valFABottTheta1,valFABottTheta2]=evalAfunctions(theta,phi,radius,k,Fieldr,Fieldtheta,Fieldphi,n,m);
            %integraltop=
            integralupnm=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmval*normalization.*(valFAUpR+valFAUpPhi+valFAUpTheta1);
            pnmvalplus1=Pnm(cos(theta),n+1,m);
            integralupnmplus1=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmvalplus1*normalizationplus1.*(valFAUpTheta2);
            integralup=sum(integralupnm+integralupnmplus1,1);
            %integralbottom=
            integralbottnm=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmval*normalization.*(valFABottR+valFABottPhi+valFABottTheta1);
            %integralbottnm=sum(weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmval*invF(n,m)*normalization.*(valFABottR),1);Rfunctionchecked
            %integralbottnm=sum(weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmval*invF(n,m)*normalization.*(valFABottPhi),1);PhifunctionChecked
            %integralbottnm=sum(weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmval*invF(n,m)*normalization.*(valFABottTheta1),1);Theta1Functionchecked
            %integralbottnmplus1=sum(weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmvalplus1*invF(n+1,m)*normalizationplus1.*(valFABottTheta2),1);Theta2Functionchecked
            integralbottnmplus1=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmvalplus1*normalizationplus1.*(valFABottTheta2);
            integralbott=sum(integralbottnm+integralbottnmplus1,1);
            vala=(integralup/integralbott)/Fix(n,m);
            
        end
        
        function valb=bnm(theta,phi,radius,k,Fieldr,Fieldtheta,Fieldphi,w,n,m)
            
            weightint=VECrpt1D(w.',size(theta,1)/size(w,2));
            pnmval=Pnm(cos(theta),n,m);
            
            normalization=sqrt(pi*(2*n+1)*factorial(n-m)/factorial(n+m));
            normalizationplus1=sqrt(pi*(2*(n+1)+1)*factorial((n+1)-m)/factorial((n+1)+m));
            
            %         if m>=0
            %         normalization=((2*n+1)/2)*factorial(n-m)/factorial(n+m);
            %         normalizationplus1=((2*(n+1)+1)/2)*factorial((n+1)-m)/factorial((n+1)+m);
            %
            %         elseif m<0
            %         normalization=(((2*n+1)/2));
            %         normalizationplus1=(((2*(n+1)+1)/2));
            %         end
            [valFBUpPhi1,valFBUpPhi2,valFBUpTheta,valFBBottTheta,valFBBottPhi1,valFBBottPhi2]=evalBfunctions(theta,phi,radius,k,Fieldr,Fieldtheta,Fieldphi,n,m);
            
            %integraltop=
            %%%
            %         integralupnm=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmval*invF(n,m)*normalization.*(valFBUpPhi1+valFBUpTheta);
            integralupnm=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmval*normalization.*(valFBUpPhi1+valFBUpTheta);
            pnmvalplus1=Pnm(cos(theta),n+1,m);
            %         integralupnmplus1=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmvalplus1*invF(n+1,m)*normalizationplus1.*(valFBUpPhi2);
            integralupnmplus1=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmvalplus1*normalizationplus1.*(valFBUpPhi2);
            integralup=sum(integralupnm+integralupnmplus1,1);
            
            %integralbottom=
            
            %        integralbottnm=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmval*invF(n,m)*normalization.*(valFBBottPhi1+valFBBottTheta);
            %        integralbottnmplus1=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmvalplus1*invF(n+1,m)*normalizationplus1.*(valFBBottPhi2);
            integralbottnm=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmval*normalization.*(valFBBottPhi1+valFBBottTheta);
            integralbottnmplus1=weightint.*(exp(-1i*phi*m)/(size(phi,1)/size(w,2))).*pnmvalplus1*normalizationplus1.*(valFBBottPhi2);
            integralbott=sum(integralbottnm+integralbottnmplus1,1);%checked
            valb=(integralup/integralbott)/Fix(n,m);
        end
        
        function [valFAUpR,valFAUpPhi,valFAUpTheta1,valFAUpTheta2,valFABottR,valFABottPhi,valFABottTheta1,valFABottTheta2]...
                =evalAfunctions(theta,phi,radius,k,Fieldr,Fieldtheta,Fieldphi,n,m)
            
            valFAUpR=AUpRFunc(theta,phi,radius,k,Fieldr,n,m);
            valFAUpPhi=AUpPhiFunc(theta,phi,radius,k,Fieldphi,n,m);
            valFAUpTheta1=AUpThetaFunc1(theta,phi,radius,k,Fieldtheta,n,m);
            valFAUpTheta2=AUpThetaFunc2(theta,phi,radius,k,Fieldtheta,n,m);
            valFABottR=ABottRFunc(theta,phi,radius,k,n,m);
            valFABottPhi=ABottPhiFunc(theta,phi,radius,k,n,m);
            valFABottTheta1=ABottThetaFunc1(theta,phi,radius,k,n,m);
            valFABottTheta2=ABottThetaFunc2(theta,phi,radius,k,n,m);
        end
        
        function   [valFBUpPhi1,valFBUpPhi2,valFBUpTheta,valFBBottTheta,valFBBottPhi1,valFBBottPhi2]...
                =evalBfunctions(theta,phi,radius,k,~,Fieldtheta,Fieldphi,n,m)
            valFBUpPhi1=BUpPhiFunc1(theta,phi,radius,k,Fieldphi,n,m);
            valFBUpPhi2=BUpPhiFunc2(theta,phi,radius,k,Fieldphi,n,m);
            valFBUpTheta=BUpThetaFunc(theta,phi,radius,k,Fieldtheta,n,m);
            valFBBottTheta=BBottThetaFunc(theta,phi,radius,k,n,m);
            valFBBottPhi1=BBottPhiFunc1(theta,phi,radius,k,n,m);
            valFBBottPhi2=BBottPhiFunc2(theta,phi,radius,k,n,m);
        end
        
        function [theta,phi,w,thetagrid,phigrid]=sphergrid(n)
            % create the grid of special points for the fast spher ham transform
            % based on the gauslegendre abscissa and weights
            [x,w]=gausleg(n);%this get us the points and weights in the interval -1 to 1;
            theta=acos(x);
            phi=2*pi*[0:2*n-1]/(2*n);%why is this choice?
            [thetagrid phigrid]=meshgrid(theta,phi);
            %theta=reshape(thetagrid,prod(size(thetagrid)),1);
            theta=thetagrid(:);
            %phi=reshape(phigrid,prod(size(thetagrid)),1);
            phi=phigrid(:);
        end
        
        
        function val=invF(n,m)
            val=1/(sqrt(((2*n+1)*factorial(n-m) )./(4*pi*factorial(n+m))));
            %         if m>=0
            %             val=1/(sqrt(((2*n+1)*factorial(n-m) )./(4*pi*factorial(n+m))));
            %
            %         elseif m<0
            %             %val=conj(1/(sqrt(((2*n+1)*factorial(n-abs(m)) )./(4*pi*factorial(n+abs(m))))));
            %              val=conj(1/(sqrt(((2*n+1)*factorial(n-m) )./(4*pi*factorial(n+m)))));
            %         end
        end
        
        function val=spherbesselh(n,s,X)
            %val=besselh(n,1,K*radi)+(1/2)*K*radi*(besselh(n-1,1,K.*radi)-besselh(n+1,1,K.*radi));
            val=sqrt(pi/(2*X)).*besselh(n+(1/2),s,X);
        end
        
        
        function val=ddrhankel(radi,K,n)
            %val=besselh(n,1,K*radi)+(1/2)*K*radi*(besselh(n-1,1,K.*radi)-besselh(n+1,1,K.*radi));
            %(1 + n) SphericalHankelH1[n, k r] - k r SphericalHankelH1[1 + n, k r]
            %val=K*radi*besselh(n-1,1,K*radi)-(n-1)*besselh(n,1,K*radi);
            val=(n+1)*spherbesselh(n,1,K*radi)-K*radi*spherbesselh(n+1,1,K*radi);
        end
        
        function val=Ynm(theta,phi,n,m)
            
            if m>=0
                val=sqrt(((2*n+1)*factorial(n-m))./(4*pi*factorial(n+m))).*Pnm(cos(theta),n,m).*exp(1i*m*phi);
            elseif m<0
                val=(-1)^abs(m)*conj(sqrt(((2*n+1)*factorial(n-abs(m)))./(4*pi*factorial(n+abs(m)))).*Pnm(cos(theta),n,abs(m)).*exp(1i*abs(m)*phi));
                
            end
            %Checked
            
        end
        
        
        function valfix=Fix(n,m)%since it was wrong in the equations of the paper of mhulig then we have to fix it! why people don't take the time to write stuff properly in their papers? this also goes to you Mr. Novotny
            %valfix=1i^(-(2*m-1))*sqrt((2*n+1)*(factorial(n-m)/factorial(n+m)));
            valfix=sqrt((2*n+1)*(factorial(n-m)/factorial(n+m)));
            %valfix=(1i^(-(2*m-1)))^2*(2*n+1)*(factorial(n-m)/factorial(n+m));
            %valfix=(2*n+1)*(factorial(n-m)/factorial(n+m));
        end
        
        
        function val=Pnm(x,n,m)
            if n==0
                val=legendre(n,x);%this is because if n is equal to zero then the function keep the orderthat the costheta had, otherwise it flips it.
            elseif(n>0),
                valvec=legendre(n,x).';
                if m>=0
                    val=valvec(:,m+1);
                elseif m<0
                    val=((-1)^abs(m))*factorial(n-abs(m))/factorial(n+abs(m))*valvec(:,abs(m)+1);
                end
            end
            %checked
        end
        
        function val=AUpRFunc(~,~,radi,K,Fieldr,n,m)
            val=Fieldr.*conj(n*(n+1).*invF(n,m).*spherbesselh(n,1,K.*radi)./(K*radi) );%checked
        end
        
        function val=AUpPhiFunc(theta,~,radi,K,Fieldphi,n,m)
            val=Fieldphi.*conj(1i*m.*csc(theta).*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m));
        end
        
        function val=AUpThetaFunc1(theta,~,radi,K,Fieldtheta,n,m)
            val=Fieldtheta.*conj(-(1+n)*cot(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m));
        end
        function val=AUpThetaFunc2(theta,~,radi,K,Fieldtheta,n,m)
            val=Fieldtheta.*conj((n-m+1)*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n+1,m));
        end
        
        function val=ABottRFunc(theta,phi,radi,K,n,m)
            val=Ynm(theta,phi,n,m).*( n*(n+1).*invF(n,m).*spherbesselh(n,1,K.*radi)./(K*radi))...
                .*conj(n*(n+1).*invF(n,m).*spherbesselh(n,1,K.*radi)./(K*radi) );
        end
        
        function val=ABottPhiFunc(theta,phi,radi,K,n,m)
            val=Ynm(theta,phi,n,m).*(1i*m*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m)).*conj(1i*m*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m));
        end
        function val=ABottThetaFunc1(theta,phi,radi,K,n,m)
            val=((-(1+n)*cot(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m)).*Ynm(theta,phi,n,m)+((n-m+1)*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n+1,m)).*Ynm(theta,phi,n+1,m))...
                .*conj(-(1+n)*cot(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m));
        end
        
        function val=ABottThetaFunc2(theta,phi,radi,K,n,m)
            val=((-(1+n)*cot(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n,m)).*Ynm(theta,phi,n,m)+((n-m+1)*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n+1,m)).*Ynm(theta,phi,n+1,m))...
                .*conj((n-m+1)*csc(theta)*(1/(K*radi))*ddrhankel(radi,K,n)*invF(n+1,m));
        end
        
        function val=BUpPhiFunc1(theta,phi,radi,K,Fieldphi,n,m)
            val=Fieldphi.*conj((1+n)*cot(theta).*spherbesselh(n,1,K.*radi).*invF(n,m));
        end
        function val=BUpPhiFunc2(theta,phi,radi,K,Fieldphi,n,m)
            val=Fieldphi.*conj(-(n-m+1)*csc(theta).*spherbesselh(n,1,K.*radi).*invF(n+1,m));
        end
        function val=BUpThetaFunc(theta,phi,radi,K,Fieldtheta,n,m)
            val=Fieldtheta.*conj(1i*m*(csc(theta))*spherbesselh(n,1,K.*radi)*invF(n,m));
        end
        
        function val=BBottThetaFunc(theta,phi,radi,K,n,m)
            val=(1i*m*(csc(theta))*spherbesselh(n,1,K.*radi)*invF(n,m).*Ynm(theta,phi,n,m)).*conj(1i*m*(csc(theta))*spherbesselh(n,1,K.*radi)*invF(n,m));
        end
        function val=BBottPhiFunc1(theta,phi,radi,K,n,m)
            
            val=(((1+n)*cot(theta).*spherbesselh(n,1,K.*radi).*invF(n,m)).*Ynm(theta,phi,n,m)+(-(n-m+1)*csc(theta).*spherbesselh(n,1,K.*radi).*invF(n+1,m)).*Ynm(theta,phi,n+1,m))...
                .*conj((1+n)*cot(theta).*spherbesselh(n,1,K.*radi).*invF(n,m));
        end
        function val=BBottPhiFunc2(theta,phi,radi,K,n,m)
            
            val=(((1+n)*cot(theta).*spherbesselh(n,1,K.*radi).*invF(n,m)).*Ynm(theta,phi,n,m)+(-(n-m+1)*csc(theta).*spherbesselh(n,1,K.*radi).*invF(n+1,m)).*Ynm(theta,phi,n+1,m))...
                .*conj(-(n-m+1)*csc(theta).*spherbesselh(n,1,K.*radi).*invF(n+1,m));
        end
        

    end

