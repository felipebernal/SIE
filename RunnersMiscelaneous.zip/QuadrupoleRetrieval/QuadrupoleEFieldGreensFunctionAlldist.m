function valfunEQuadrupole= QuadrupoleEFieldGreensFunctionAlldist(omega,~,Q,rtoeval,rsource,muv,epsilonv,sourceinout)
%CHECKED!!!!
p=path;
path(p,'\\nanorfsrv\Users\Bernal\Theory\RunnersMiscelaneous\QuadrupoleRetrieval\multialgebra');
% omega is the frequency at which the quadrupole radiates..
%Q is the quadrupole traceless matrix of3x3
%direction is not used at all...
%rtoeval is the position at which we want to find the E field.
%rsource is the position of the quadrupole




%Only for test pourposes
% omega=1;
% epsilonv=[1,1];
% muv=[1,1];
% rtoeval=[1,2,3;4,5,6;7,8,9;1,1,2;1,2,3];
% rsource=[1,2,1;0,0,0;3,4,5;1,1,1;1,2,1];
% Q=[0,1,0;1,0,0;0,0,0];
% sourceinout=1;

numpoints=size(rtoeval,1);
mu0=1;
eps0=1;
c=1;
epsilon=epsilonv(sourceinout);
mu=muv(sourceinout);
k=omega*sqrt(eps0*epsilon*mu0*mu)/c;
Z0=sqrt(mu0/eps0);

% r=rtoeval-rsource;
% rsource4G=rsource;

r=rtoeval-repmat(rsource,numpoints,1);
rsource4G=repmat(rsource,numpoints,1);

rmag=sqrt(sum(r.^2,2));
rdirect=r./repmat(rmag,1,3);

valfunEQuadrupole=mu*(k^2/eps0)*multiprod(multiprod(QuadrupolePropagatorFreeSpace(omega,epsilon,mu,rtoeval,rsource4G),repmat(Q,[1,1,numpoints]),[1,2],[1,2]),rdirect.',[1,2],[1]).';



%this is how you multiply two matrices 3x3xn where you need to contract the
%3x3 first
%multiprod(QuadrupolePropagatorFreeSpace(omega,epsilon,mu,rtoeval,rsource4G),repmat(Q,[1,1,numpoints]),[1,2],[1,2])



end