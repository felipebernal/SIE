
p=path;
path(p,'\\nanorfsrv\Users\Bernal\Theory\RunnersMiscelaneous\FarFieldGreensFunctionplusQuadrupole\multialgebra');
    
p1=path;
path(p1,'\\nanorfsrv\Users\Bernal\Theory\RunnersMiscelaneous\FarFieldGreensFunctionplusQuadrupole');


numberpoints=100;
theta1=linspace(0,pi,numberpoints).';
phi1=linspace(0,2*pi,numberpoints).';
[theta2 phi2]=meshgrid(theta1,phi1);
theta=theta2(:);
phi=phi2(:);

radius=0.20;
rtoeval=[sin(theta).*cos(phi)*radius,sin(theta).*sin(phi)*radius,cos(theta)*radius];
rsource=[0,0,0];
lambda=540/1000;
c=1;
omega=2*pi*c/lambda;
muv=[1,1];
epsilonv=[1,1];
%Q=[1,0,0;0,-0.5,0;0,0,-.5];
Q=[0,1,0;1,0,0;0,0,0];
%Q=[0,0,0;0,0,1;0,1,0];

%Q=[1,0,0;0,-1,0;0,0,0];

%Q=[-0.457815203485740 - 0.345686595460564i,0.00141249884477954 + 0.00263522624762707i,...
%    0.000300918579846913 + 0.000579299381747579i;0.00141249884477954 + 0.00263522624762707i,...
%    0.479248595107231 + 0.358111272823699i,0.347405093036489 + 0.123972515210833i;...
%    0.000300918579846913 + 0.000579299381747579i,0.347405093036489 + 0.123972515210833i...
%    ,-0.0214333916214913 - 0.0124246773631353i;];%this is the Q for 180nm cylinder at 540 nm wavelength excitation


sourceinout=1;
valfunEQuadrupole=QuadrupoleEField(omega,1,Q,rtoeval,rsource,muv,epsilonv,sourceinout);


x=sin(theta2).*cos(phi2);
y=sin(theta2).*sin(phi2);
z=cos(theta2);
rad=reshape(sqrt(sum(valfunEQuadrupole.*conj(valfunEQuadrupole),2)),size(x,1),[]);

%The efield multiplied by the rdirector and from there we get the phase;
%angles=reshape(angle(valfunEQuadrupole(:,2)),size(x,1),[]);
%Einrdirector=sin(theta).*cos(phi).*valfunEQuadrupole(:,1)+sin(theta).*sin(phi).*valfunEQuadrupole(:,2)+cos(theta).*valfunEQuadrupole(:,3);
Eintheta=cos(theta).*cos(phi).*valfunEQuadrupole(:,1)+cos(theta).*sin(phi).*valfunEQuadrupole(:,2)-sin(theta).*valfunEQuadrupole(:,3);

%angles=reshape(angle(Einrdirector),size(x,1),[]);
angles=reshape(angle(Eintheta),size(x,1),[]);
figure(1)
surf(rad.*x,rad.*y,rad.*z,angles);



%%%%%%%%%%Now the test for the efield found with the green's function near
%%%%%%%%%%field

valfunEQuadrupole=QuadrupoleEFieldGreensFunctionAlldist(omega,1,Q,rtoeval,rsource,muv,epsilonv,sourceinout);

x=sin(theta2).*cos(phi2);
y=sin(theta2).*sin(phi2);
z=cos(theta2);
rad=reshape(sqrt(sum(valfunEQuadrupole.*conj(valfunEQuadrupole),2)),size(x,1),[]);

%The efield multiplied by the rdirector and from there we get the phase;
%angles=reshape(angle(valfunEQuadrupole(:,2)),size(x,1),[]);
%Einrdirector=sin(theta).*cos(phi).*valfunEQuadrupole(:,1)+sin(theta).*sin(phi).*valfunEQuadrupole(:,2)+cos(theta).*valfunEQuadrupole(:,3);
Eintheta=cos(theta).*cos(phi).*valfunEQuadrupole(:,1)+cos(theta).*sin(phi).*valfunEQuadrupole(:,2)-sin(theta).*valfunEQuadrupole(:,3);

%angles=reshape(angle(Einrdirector),size(x,1),[]);
angles=reshape(angle(Eintheta),size(x,1),[]);
figure(2)
surf(rad.*x,rad.*y,rad.*z,angles);





%%%%%%%%%%Now the test for the efield found with the green's function

valfunEQuadrupole=QuadrupoleEFieldGreensFunction(omega,1,Q,rtoeval,rsource,muv,epsilonv,sourceinout);




x=sin(theta2).*cos(phi2);
y=sin(theta2).*sin(phi2);
z=cos(theta2);
rad=reshape(sqrt(sum(valfunEQuadrupole.*conj(valfunEQuadrupole),2)),size(x,1),[]);

%The efield multiplied by the rdirector and from there we get the phase;
%angles=reshape(angle(valfunEQuadrupole(:,2)),size(x,1),[]);
%Einrdirector=sin(theta).*cos(phi).*valfunEQuadrupole(:,1)+sin(theta).*sin(phi).*valfunEQuadrupole(:,2)+cos(theta).*valfunEQuadrupole(:,3);
Eintheta=cos(theta).*cos(phi).*valfunEQuadrupole(:,1)+cos(theta).*sin(phi).*valfunEQuadrupole(:,2)-sin(theta).*valfunEQuadrupole(:,3);

%angles=reshape(angle(Einrdirector),size(x,1),[]);
angles=reshape(angle(Eintheta),size(x,1),[]);
figure(3)
surf(rad.*x,rad.*y,rad.*z,angles);



