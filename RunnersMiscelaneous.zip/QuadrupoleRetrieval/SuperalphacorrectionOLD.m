
This is the old superalpha correction for 11x11 polarizability tensors

%function SuperAlphacorrected=Superalphacorrection(omega,rsource,SuperAlpha,struct,t)
%t=0;
%rsource=[0,0,0.05];

%p=path;
%path(p,'\\nanorfsrv\Users\Bernal\Theory\RunnersMiscelaneous\QuadrupoleRetrieval\waveguideGfunction6x6');
p1=path;
path(p1,'\\nanorfsrv\Users\Bernal\Theory\WaveguideGreensFunctionwCulrandwGrad');


c=1;
k=omega/c;
lambda=2*pi/k;
%then given a substrate structure we correct for self polarization
eps0=1;
mu0=1;
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);

SuperAlphacorrected=zeros(11,11);
Gchange=zeros(6,6);

rdetect=rsource;

a=omega^2*mu0*mu1;
b=omega^2*mu0*mu1/6;
c1=1i*omega*mu0*mu1;
d=omega^2*mu0*mu1*eps0*eps1;



dxGe=GradnGreenWaveguide(1,0,k,rdetect,rsource,struct,t);
dyGe=GradnGreenWaveguide(2,0,k,rdetect,rsource,struct,t);
dzGe=GradnGreenWaveguide(3,0,k,rdetect,rsource,struct,t);

dxpGe=GradnGreenWaveguide(1,1,k,rdetect,rsource,struct,t);
dypGe=GradnGreenWaveguide(2,1,k,rdetect,rsource,struct,t);
dzpGe=GradnGreenWaveguide(3,1,k,rdetect,rsource,struct,t);

% dxGm=GradnGreenWaveguide(1,0,k,rdetect,rsource,[struct(:,2),struct(:,1)],t);
% dyGm=GradnGreenWaveguide(2,0,k,rdetect,rsource,[struct(:,2),struct(:,1)],t);
% dzGm=GradnGreenWaveguide(3,0,k,rdetect,rsource,[struct(:,2),struct(:,1)],t);


dxdxpGe=GradnGradmGreenWaveguide(1,0,1,1,k,rdetect,rsource,struct,t);
dydxpGe=GradnGradmGreenWaveguide(2,0,1,1,k,rdetect,rsource,struct,t);
dzdxpGe=GradnGradmGreenWaveguide(3,0,1,1,k,rdetect,rsource,struct,t);

dxdypGe=GradnGradmGreenWaveguide(1,0,2,1,k,rdetect,rsource,struct,t);
dydypGe=GradnGradmGreenWaveguide(2,0,2,1,k,rdetect,rsource,struct,t);
dzdypGe=GradnGradmGreenWaveguide(3,0,2,1,k,rdetect,rsource,struct,t);

dxdzpGe=GradnGradmGreenWaveguide(1,0,3,1,k,rdetect,rsource,struct,t);
dydzpGe=GradnGradmGreenWaveguide(2,0,3,1,k,rdetect,rsource,struct,t);
dzdzpGe=GradnGradmGreenWaveguide(3,0,3,1,k,rdetect,rsource,struct,t);



dxdxGm=GradnGradmGreenWaveguide(1,0,1,0,k,rdetect,rsource,[struct(:,2),struct(:,1)],t);
dydxGm=GradnGradmGreenWaveguide(2,0,1,0,k,rdetect,rsource,[struct(:,2),struct(:,1)],t);
dzdxGm=GradnGradmGreenWaveguide(3,0,1,0,k,rdetect,rsource,[struct(:,2),struct(:,1)],t);

dxdyGm=GradnGradmGreenWaveguide(1,0,2,0,k,rdetect,rsource,[struct(:,2),struct(:,1)],t);
dydyGm=GradnGradmGreenWaveguide(2,0,2,0,k,rdetect,rsource,[struct(:,2),struct(:,1)],t);
dzdyGm=GradnGradmGreenWaveguide(3,0,2,0,k,rdetect,rsource,[struct(:,2),struct(:,1)],t);

dxdzGm=GradnGradmGreenWaveguide(1,0,3,0,k,rdetect,rsource,[struct(:,2),struct(:,1)],t);
dydzGm=GradnGradmGreenWaveguide(2,0,3,0,k,rdetect,rsource,[struct(:,2),struct(:,1)],t);
dzdzGm=GradnGradmGreenWaveguide(3,0,3,0,k,rdetect,rsource,[struct(:,2),struct(:,1)],t);


% dr=(10^(-4))*(1/k);
% dx=[dr,0,0];
% dy=[0,dr,0];
% dz=[0,0,dr];
% 
%  dxG=(GreenReflected6x6(k,rdetect+dx,rsource,struct,t)-GreenReflected6x6(k,rdetect-dx,rsource,struct,t))/(2*dr);
%  dyG=(GreenReflected6x6(k,rdetect+dy,rsource,struct,t)-GreenReflected6x6(k,rdetect-dy,rsource,struct,t))/(2*dr);
%  dzG=(GreenReflected6x6(k,rdetect+dz,rsource,struct,t)-GreenReflected6x6(k,rdetect-dz,rsource,struct,t))/(2*dr);
% 
% dxG=(CurlGreenWaveguide(k,rdetect+dx,rsource,[struct(:,2),struct(:,1)],t)-CurlGreenWaveguide(k,rdetect-dx,rsource,[struct(:,2),struct(:,1)],t))/(2*dr);
% dyG=(CurlGreenWaveguide(k,rdetect+dy,rsource,[struct(:,2),struct(:,1)],t)-CurlGreenWaveguide(k,rdetect-dy,rsource,[struct(:,2),struct(:,1)],t))/(2*dr);
% dzG=(CurlGreenWaveguide(k,rdetect+dz,rsource,[struct(:,2),struct(:,1)],t)-CurlGreenWaveguide(k,rdetect-dz,rsource,[struct(:,2),struct(:,1)],t))/(2*dr);
% dxCurlGm=dxG(1:3,4:6);
% dyCurlGm=dyG(1:3,4:6);
% dzCurlGm=dzG(1:3,4:6);

%CurlGreenDyad=CurlGreenWaveguide(k,rdetect,rsource,struct,t)
GE=GreenWaveguide(k,rdetect,rsource,[struct(:,1),struct(:,2)],t);
CurlGE=CurlGreenWaveguide(k,rdetect,rsource,[struct(:,1),struct(:,2)],t);
GM=GreenWaveguide(k,rdetect,rsource,[struct(:,2),struct(:,1)],t);
CurlGM=CurlGreenWaveguide(k,rdetect,rsource,[struct(:,2),struct(:,1)],t);

% test1=curlGE2
% test2=curlpGM2


Gchange(1:3,1:3)=a*GE;
Gchange(4:6,1:3)=(a/(1i*omega*mu0*mu1))*CurlGE;
Gchange(1:3,4:6)=c1*CurlGM;
Gchange(4:6,4:6)=d*GM;
                

% Gchange(1:3,1:3)=a*GreenDyad(1:3,1:3);
% Gchange(4:6,1:3)=(a/(1i*omega*mu0*mu1))*GreenDyad(4:6,1:3);
% Gchange(1:3,4:6)=c1*GreenDyad(1:3,4:6);
% Gchange(4:6,4:6)=d*GreenDyad(1:3,1:3);
Mat31=a*DiamondGe;
Mat32=c*DiamondCurlpGm;
Mat33=b*DiamondDiamondpGe;
Mat13=b*DiamondPGe;
Mat23=(b/(1i*omega*mu0*mu1))*CurldiamondpGe;

BigMac=zeros(11,11);

BigMac(1:6,1:6)=Gchange;
BigMac(7:11,1:3)=Mat31;
BigMac(7:11,4:6)=Mat32;
BigMac(7:11,7:11)=Mat33;
BigMac(1:3,7:11)=Mat13;
BigMac(4:6,7:11)=Mat23;



%InvertibleSuperAlpha=zeros(11,11);
%InvertibleSuperAlpha=SuperAlpha(1:11,1:11);

alphacorrectedtemp=pinv(SuperAlpha)-imag(BigMac);
%alphacorrectedtemp=pinv(SuperAlpha)-BigMac;
SuperAlphacorrected=pinv(alphacorrectedtemp);

    
    
function matrix=curlGE2
dxv1=dxGe(1,:);
dxv2=dxGe(2,:);
dxv3=dxGe(3,:);

dyv1=dyGe(1,:);
dyv2=dyGe(2,:);
dyv3=dyGe(3,:);

dzv1=dzGe(1,:);
dzv2=dzGe(2,:);
dzv3=dzGe(3,:);
%matrix=[(dxv2+dyv1)/2;(dzv1+dxv3)/2;(dzv2+dyv3)/2;dxv1;dyv2;dzv3];
matrix=[(dyv3-dzv2);(dzv1-dxv3);(dxv2-dyv1)];
end

% function matrix=curlpGM2
% dxv1=dxpGm(1,:);
% dxv2=dxpGm(2,:);
% dxv3=dxpGm(3,:);
% 
% dyv1=dypGm(1,:);
% dyv2=dypGm(2,:);
% dyv3=dypGm(3,:);
% 
% dzv1=dzpGm(1,:);
% dzv2=dzpGm(2,:);
% dzv3=dzpGm(3,:);
% %matrix=[(dxv2+dyv1)/2;(dzv1+dxv3)/2;(dzv2+dyv3)/2;dxv1;dyv2;dzv3];
% matrix=[(dyv3-dzv2);(dzv1-dxv3);(dxv2-dyv1)];
% end


function matrix=DiamondGe

dxv1=dxGe(1,:);
dxv2=dxGe(2,:);
dxv3=dxGe(3,:);

dyv1=dyGe(1,:);
dyv2=dyGe(2,:);
dyv3=dyGe(3,:);

dzv1=dzGe(1,:);
dzv2=dzGe(2,:);
dzv3=dzGe(3,:);
%matrix=[(dxv2+dyv1)/2;(dzv1+dxv3)/2;(dzv2+dyv3)/2;dxv1;dyv2;dzv3];
matrix=[(dxv2+dyv1)/2;(dzv1+dxv3)/2;(dzv2+dyv3)/2;dxv1;dyv2];
end

function matrix=DiamondPGe
%Since here we need the transpose of G then we take the rows and not the columns
dxv1=dxpGe(:,1);
dxv2=dxpGe(:,2);
dxv3=dxpGe(:,3);

dyv1=dypGe(:,1);
dyv2=dypGe(:,2);
dyv3=dypGe(:,3);

dzv1=dzpGe(:,1);
dzv2=dzpGe(:,2);
dzv3=dzpGe(:,3);

%matrix=[(dxv2+dyv1)/2,(dzv1+dxv3)/2,(dzv2+dyv3)/2,dxv1,dyv2,dzv3];
matrix=[(dxv2+dyv1)/2,(dzv1+dxv3)/2,(dzv2+dyv3)/2,dxv1,dyv2];
end

function matrix=DiamondCurlpGm

% dxv1=dxCurlGm(1,:);
% dxv2=dxCurlGm(2,:);
% dxv3=dxCurlGm(3,:);
% 
% dyv1=dyCurlGm(1,:);
% dyv2=dyCurlGm(2,:);
% dyv3=dyCurlGm(3,:);
% 
% dzv1=dzCurlGm(1,:);
% dzv2=dzCurlGm(2,:);
% dzv3=dzCurlGm(3,:);
% 
% %matrix=[(dxv2+dyv1)/2;(dzv1+dxv3)/2;(dzv2+dyv3)/2;dxv1;dyv2;dzv3];
% matrix=[(dxv2+dyv1)/2;(dzv1+dxv3)/2;(dzv2+dyv3)/2;dxv1;dyv2];

matrix=[(1/2)*(-dydzGm(2,1)+dydyGm(3,1)+dxdzGm(1,1)-dxdxGm(3,1)),...
        (1/2)*(-dydzGm(2,2)+dydyGm(3,2)+dxdzGm(1,2)-dxdxGm(3,2)),...
        (1/2)*(-dydzGm(2,3)+dydyGm(3,3)+dxdzGm(1,3)-dxdxGm(3,3));
        (1/2)*(-dzdzGm(2,1)+dydzGm(3,1)-dxdyGm(1,1)+dxdxGm(2,1)),...
        (1/2)*(-dzdzGm(2,2)+dydzGm(3,2)-dxdyGm(1,2)+dxdxGm(2,2)),...
        (1/2)*(-dzdzGm(2,3)+dydzGm(3,3)-dxdyGm(1,3)+dxdxGm(2,3));
        (1/2)*(dzdzGm(1,1)-dydyGm(1,1)-dxdzGm(3,1)+dxdyGm(2,1)),...
        (1/2)*(dzdzGm(1,2)-dydyGm(1,2)-dxdzGm(3,2)+dxdyGm(2,2)),...
        (1/2)*(dzdzGm(1,3)-dydyGm(1,3)-dxdzGm(3,3)+dxdyGm(2,3));
        (-dxdzGm(2,1)+dxdyGm(3,1)),...
        (-dxdzGm(2,2)+dxdyGm(3,2)),...
        (-dxdzGm(2,3)+dxdyGm(3,3));
        (dydzGm(1,1)-dxdyGm(3,1)),...
        (dydzGm(1,2)-dxdyGm(3,2)),...
        (dydzGm(1,3)-dxdyGm(3,3))];
end


function matrix=DiamondDiamondpGe

matrix11=[(1/4)*(dydypGe(1,1)+dydxpGe(1,2)+dxdypGe(2,1)+dxdxpGe(2,2)),(1/4)*(dydzpGe(1,1)+dydxpGe(1,3)+dxdzpGe(2,1)+dxdxpGe(2,3)),(1/4)*(dydzpGe(1,2)+dydypGe(1,3)+dxdzpGe(2,2)+dxdypGe(2,3));...
          (1/4)*(dzdypGe(1,1)+dzdxpGe(1,2)+dxdypGe(3,1)+dxdxpGe(3,2)),(1/4)*(dzdzpGe(1,1)+dzdxpGe(1,3)+dxdzpGe(3,1)+dxdxpGe(3,3)),(1/4)*(dzdzpGe(1,2)+dzdypGe(1,3)+dxdzpGe(3,2)+dxdypGe(3,3));...
          (1/4)*(dzdypGe(2,1)+dzdxpGe(2,2)+dydypGe(3,1)+dydxpGe(3,2)),(1/4)*(dzdzpGe(2,1)+dzdxpGe(2,3)+dydzpGe(3,1)+dydxpGe(3,3)),(1/4)*(dzdzpGe(2,2)+dzdypGe(2,3)+dydzpGe(3,2)+dydypGe(3,3))];
% matrix21=[(1/2)*(dxdypGe(1,1)+dxdxpGe(1,2)),(1/2)*(dxdzpGe(1,1)+dxdxpGe(1,3)),(1/2)*(dxdzpGe(1,2)+dxdypGe(1,3));...
%           (1/2)*(dydypGe(2,1)+dydxpGe(2,2)),(1/2)*(dydzpGe(2,1)+dydxpGe(2,3)),(1/2)*(dydzpGe(2,2)+dydypGe(2,3));...
%           (1/2)*(dzdypGe(3,1)+dzdxpGe(3,2)),(1/2)*(dzdzpGe(3,1)+dzdxpGe(3,3)),(1/2)*(dzdzpGe(3,2)+dzdypGe(3,3))];
matrix21=[(1/2)*(dxdypGe(1,1)+dxdxpGe(1,2)),(1/2)*(dxdzpGe(1,1)+dxdxpGe(1,3)),(1/2)*(dxdzpGe(1,2)+dxdypGe(1,3));...
          (1/2)*(dydypGe(2,1)+dydxpGe(2,2)),(1/2)*(dydzpGe(2,1)+dydxpGe(2,3)),(1/2)*(dydzpGe(2,2)+dydypGe(2,3))];
% matrix12=[(1/2)*(dydxpGe(1,1)+dxdxpGe(2,1)),(1/2)*(dydypGe(1,2)+dxdypGe(2,2)),(1/2)*(dydzpGe(1,3)+dxdzpGe(2,3));...
%           (1/2)*(dzdxpGe(1,1)+dxdxpGe(3,1)),(1/2)*(dzdypGe(1,2)+dxdypGe(3,2)),(1/2)*(dzdzpGe(1,3)+dxdzpGe(3,3));...
%           (1/2)*(dzdxpGe(2,1)+dydxpGe(3,1)),(1/2)*(dzdypGe(2,2)+dydypGe(3,2)),(1/2)*(dzdzpGe(2,3)+dydzpGe(3,3))]; 
matrix12=[(1/2)*(dydxpGe(1,1)+dxdxpGe(2,1)),(1/2)*(dydypGe(1,2)+dxdypGe(2,2));...
          (1/2)*(dzdxpGe(1,1)+dxdxpGe(3,1)),(1/2)*(dzdypGe(1,2)+dxdypGe(3,2));...
          (1/2)*(dzdxpGe(2,1)+dydxpGe(3,1)),(1/2)*(dzdypGe(2,2)+dydypGe(3,2))]; 
% matrix22=[dxdxpGe(1,1),dxdypGe(1,2),dxdzpGe(1,3);...
%           dydxpGe(2,1),dydypGe(2,2),dydzpGe(2,3);...
%           dzdxpGe(3,1),dzdypGe(3,2),dzdzpGe(3,3)];
matrix22=[dxdxpGe(1,1),dxdypGe(1,2);...
          dydxpGe(2,1),dydypGe(2,2)];

matrix=[matrix11,matrix12;matrix21,matrix22];
      
      
end

function matrix=CurldiamondpGe

% matrix=[[(1/2)*(-dzdypGe(1,2)+dydypGe(1,3)-dzdxpGe(2,2)+dydxpGe(2,3));...
%     (1/2)*(dzdypGe(1,1)-dxdypGe(1,3)+dzdxpGe(2,1)-dxdxpGe(2,3));...
%     (1/2)*(-dydypGe(1,1)+dxdypGe(1,2)-dydxpGe(2,1)+dxdxpGe(2,2))],...
%     [(1/2)*(-dzdzpGe(1,2)+dydzpGe(1,3)-dzdxpGe(3,2)+dydxpGe(3,3));...
%     (1/2)*(dzdzpGe(1,1)-dxdzpGe(1,3)+dzdxpGe(3,1)-dxdxpGe(3,3));...
%     (1/2)*(-dydzpGe(1,1)+dxdzpGe(1,2)-dydxpGe(3,1)+dxdxpGe(3,2))],...
%     [(1/2)*(-dzdzpGe(2,2)+dydzpGe(2,3)-dzdypGe(3,2)+dydypGe(3,3));...
%     (1/2)*(dzdzpGe(2,1)-dxdzpGe(2,3)+dzdypGe(3,1)-dxdypGe(3,3));...
%     (1/2)*(-dydzpGe(2,1)+dxdzpGe(2,2)-dydypGe(3,1)+dxdypGe(3,2))],...
%     [-dzdxpGe(1,2)+dydxpGe(1,3);...
%     dzdxpGe(1,1)+dxdxpGe(1,3);...
%     -dydxpGe(1,1)+dxdxpGe(1,2)],...
%     [-dzdypGe(2,2)+dydypGe(2,3);...
%     dzdypGe(2,1)+dxdypGe(2,3);...
%     -dydypGe(2,1)+dxdypGe(2,2)],...
%     [-dzdzpGe(3,2)+dydzpGe(3,3);...
%     dzdzpGe(3,1)+dxdzpGe(3,3);...
%     -dydzpGe(3,1)+dxdzpGe(3,2)]];
matrix=[[(1/2)*(-dzdypGe(2,1)+dydypGe(3,1)-dzdxpGe(2,2)+dydxpGe(3,2));...
    (1/2)*(dzdypGe(1,1)-dxdypGe(3,1)+dzdxpGe(1,2)-dxdxpGe(3,2));...
    (1/2)*(-dydypGe(1,1)+dxdypGe(2,1)-dydxpGe(1,2)+dxdxpGe(2,2))],...
    [(1/2)*(-dzdzpGe(2,1)+dydzpGe(3,1)-dzdxpGe(2,3)+dydxpGe(3,3));...
    (1/2)*(dzdzpGe(1,1)-dxdzpGe(3,1)+dzdxpGe(1,3)-dxdxpGe(3,3));...
    (1/2)*(-dydzpGe(1,1)+dxdzpGe(2,1)-dydxpGe(1,3)+dxdxpGe(2,3))],...
    [(1/2)*(-dzdzpGe(2,2)+dydzpGe(3,2)-dzdypGe(2,3)+dydypGe(3,3));...
    (1/2)*(dzdzpGe(1,2)-dxdzpGe(3,2)+dzdypGe(1,3)-dxdypGe(3,3));...
    (1/2)*(-dydzpGe(1,2)+dxdzpGe(2,2)-dydypGe(1,3)+dxdypGe(2,3))],...
    [-dzdxpGe(2,1)+dydxpGe(3,1);...
    dzdxpGe(1,1)+dxdxpGe(3,1);...
    -dydxpGe(1,1)+dxdxpGe(2,1)],...
    [-dzdypGe(2,2)+dydypGe(3,2);...
    dzdypGe(1,2)+dxdypGe(3,2);...
    -dydypGe(1,2)+dxdypGe(2,2)]];

end






end