function GreenDyad=GreenReflected6x6(k,rdetect,rsource,struct,t)

%This function only gives the reflected and transmited part of the green's
%function ommiting the free part.
%struct contains the permitivities and permeavilities of the layered
%e.g. structure [[eps1;eps2;eps3],[mu1;mu2;mu3]]
%

rvec=rdetect-rsource;
R=sqrt(rvec(:,1).^2+rvec(:,2).^2);
z=rdetect(:,3);
h=rsource(:,3);
phi=atan2(rvec(:,2),rvec(:,1));


numpoints=size(rdetect,1);

GreenDyad=zeros(6,6,numpoints);
Region=1;%if you want reflection inside a layer then you need to change region to 2 and also the rs and rp coefficient.
GreenDyad=GreenIntegratorRefTrans6x6(k,h,z,R,phi,struct,t,@GreenReflectedIntegrand6x6,Region);





