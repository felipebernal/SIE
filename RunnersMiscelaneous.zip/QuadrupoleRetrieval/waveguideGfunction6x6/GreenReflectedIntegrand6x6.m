function VectorfunctionsReflected=GreenReflectedIntegrand6x6(kR,k,h,z,R,phi,struct,t,J0,J1)

numpoints=size(R,1);
eps1=struct(1,1);
eps2=struct(2,1);
eps3=struct(3,1);
mu1=struct(1,2);
mu2=struct(2,2);
mu3=struct(3,2);

%first we turn the vercotrs R, phi J0 and J1 into the third dimension so
%that we can work with the whole matrix
numpunkt=size(R,1);

h=reshape(h,1,1,[]);
z=reshape(z,1,1,[]);
R=reshape(R,1,1,[]);
phi=reshape(phi,1,1,[]);
J0=reshape(J0,1,1,[]);
J1=reshape(J1,1,1,[]);
zeroval=zeros(1,1,numpunkt);

%this is femius version which gives very wierd results....:s
%VectorfunctionsReflected=(1i*k^2/2).*repmat(exp(1i*(h + z)*k1z(kR,k)),[6,6,1]).*(Ms(kR,k,h,z,R,phi,struct,t)*rs(kR,k,t)./k1z(kR,k)-Mp(kR,k,h,z,R,phi,struct,t)*rp(kR,k,t)./k1z(kR,k));


%this is with my stuff in
VectorfunctionsReflected=(kR/(4*k^4*pi*eps1*mu1))*(1i*k^2/2).*repmat(exp(1i*(h + z)*k1z(kR,k)),[6,6,1]).*(Ms(kR,k,h,z,R,phi,struct,t)*rs(kR,k,t)./k1z(kR,k)-Mp(kR,k,h,z,R,phi,struct,t)*rp(kR,k,t)./k1z(kR,k));

%Here we write the functions for vertical and horizontal dipoles but
%without the angle dependence so that we can use one single integral for
%both Gxi and Gyi components.

function valMs=Ms(kR,k,~,~,R,phi,~,~)
        
    valMs=[J0+J2(kR,k,R,J0,J1).*cos(2*phi),J2(kR,k,R,J0,J1).*sin(2*phi),zeroval,  -J2(kR,k,R,J0,J1).*sin(2*phi).*k1z(kR,k),(J0+J2(kR,k,R,J0,J1).*cos(2*phi)).*k1z(kR,k),kR*2*1i*J1.*sin(phi);...
           J2(kR,k,R,J0,J1).*sin(2*phi),J0-J2(kR,k,R,J0,J1).*cos(2*phi), zeroval,  -(J0-J2(kR,k,R,J0,J1).*cos(2*phi)).*k1z(kR,k),  J2(kR,k,R,J0,J1).*sin(2*phi).*k1z(kR,k),-kR*2*1i*J1.*cos(phi);...
           zeroval,zeroval,zeroval,zeroval,zeroval,zeroval;...
           -J2(kR,k,R,J0,J1).*sin(2*phi).*k1z(kR,k),-(J0-J2(kR,k,R,J0,J1).*cos(2*phi)).*k1z(kR,k),zeroval,(J0-J2(kR,k,R,J0,J1).*cos(2*phi)).*(k1z(kR,k).^2),-J2(kR,k,R,J0,J1).*sin(2*phi).*(k1z(kR,k).^2),kR*2*1i*J1.*cos(phi).*k1z(kR,k);...
           (J0+J2(kR,k,R,J0,J1).*cos(2*phi)).*k1z(kR,k),J2(kR,k,R,J0,J1).*sin(2*phi).*k1z(kR,k),zeroval,  -J2(kR,k,R,J0,J1).*sin(2*phi).*k1z(kR,k).^2,(J0+J2(kR,k,R,J0,J1).*cos(2*phi)).*k1z(kR,k).^2,kR*2*1i*J1.*sin(phi).*k1z(kR,k);...
           -kR*2*1i*J1.*sin(phi),kR*2*1i*J1.*cos(phi),zeroval,-kR*2*1i*J1.*cos(phi).*k1z(kR,k),-kR*2*1i*J1.*sin(phi).*k1z(kR,k),-(kR.^2)*2*J0];
end

function valMp=Mp(kR,k,~,~,R,phi,~,~)
        
    valMp=[(J0-J2(kR,k,R,J0,J1).*cos(2*phi)).*(k1z(kR,k).^2),-J2(kR,k,R,J0,J1).*sin(2*phi).*(k1z(kR,k).^2),kR*2*1i*J1.*cos(phi).*k1z(kR,k), J2(kR,k,R,J0,J1).*sin(2*phi).*k1z(kR,k),(J0-J2(kR,k,R,J0,J1).*cos(2*phi)).*k1z(kR,k),zeroval;...
           -J2(kR,k,R,J0,J1).*sin(2*phi).*(k1z(kR,k).^2),(J0+J2(kR,k,R,J0,J1).*sin(2*phi)).*(k1z(kR,k).^2), kR*2*1i*J1.*sin(phi).*k1z(kR,k),  -(J0+J2(kR,k,R,J0,J1).*cos(2*phi)).*k1z(kR,k),  -J2(kR,k,R,J0,J1).*sin(2*phi).*k1z(kR,k),zeroval;...
           -kR*2*1i*J1.*cos(phi).*k1z(kR,k),-kR*2*1i*J1.*sin(phi).*k1z(kR,k),-(kR.^2).*2.*J0,kR*2*1i*J1.*sin(phi),-kR*2*1i*J1.*cos(phi),zeroval;...
           J2(kR,k,R,J0,J1).*sin(2*phi).*k1z(kR,k),-(J0+J2(kR,k,R,J0,J1).*cos(2*phi)).*k1z(kR,k),-kR*2*1i*J1.*sin(phi),(J0+J2(kR,k,R,J0,J1).*cos(2*phi)),J2(kR,k,R,J0,J1).*sin(2*phi),zeroval;...
           (J0-J2(kR,k,R,J0,J1).*cos(2*phi)).*k1z(kR,k),-J2(kR,k,R,J0,J1).*sin(2*phi).*k1z(kR,k),kR*2*1i*J1.*cos(phi),  J2(kR,k,R,J0,J1).*sin(2*phi),(J0-J2(kR,k,R,J0,J1).*cos(2*phi)),zeroval;...
           zeroval,zeroval,zeroval,zeroval,zeroval,zeroval];
end


 function valJ2=J2(kR,k,R,J0,J1)
       valJ2=zeros(1,1,numpoints);
       cond=logical(kR*R<=(10^-10));
       valJ2(not(cond))=2*J1(not(cond))./(kR.*R(not(cond)))-J0(not(cond));
    end


function valrs=rs(kR,k,t)
    valrs=(mu2*k1z(kR,k)-mu1*k2z(kR,k))/(mu2*k1z(kR,k)+mu1*k2z(kR,k)); 
end

function valrp=rp(kR,k,t)
    valrp=(eps2*k1z(kR,k)-eps1*k2z(kR,k))/(eps2*k1z(kR,k)+eps1*k2z(kR,k)); 
end

function k1zval=k1z(kR,k)
    tempk1z=sqrt(eps1*mu1*k^2-kR^2);
    if abs(imag(tempk1z))<10^-6
        k1zval=tempk1z;
    else
        k1zval=tempk1z*sign(imag(tempk1z));
    end
end


function k2zval=k2z(kR,k)
 tempk2z=sqrt(eps2*mu2*k^2-kR^2);
    if abs(imag(tempk2z))<10^-6
        k2zval=tempk2z;
    else
        k2zval=tempk2z*sign(imag(tempk2z));
    end
end

function k3zval=k3z(kR,k)
 tempk3z=sqrt(eps3*mu3*k^2-kR^2);
    if abs(imag(tempk3z))<10^-6
        k3zval=tempk3z;
    else
        k3zval=tempk3z*sign(imag(tempk3z));
    end
end
function A1val=A1(kR,k,t)
    A1val=1i*(kR*(f1(kR,k)*f4(kR,k)+f2(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        /(k1z(kR,k)*((f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t))));
    %checked
end

function B1val=B1(kR,k,t)
 B1val=1i*(kR*(g1(kR,k)*g4(kR,k)+g2(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        /(k1z(kR,k)*((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t))));
    %checked
end

% function C1val=C1(kR,k,t)
%     C1val=2*(kR^2)*...
%         ((f4(kR,k)+f3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
%    *(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
%     *(eps1*mu1-eps2*mu2)+...
%     4*eps1*mu1*(k2z(kR,k)^2)*...
%      (eps2*mu2-eps3*mu3)*exp(2*1i*k2z(kR,k)*t))./...
%          (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
%         *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
%         %checked But there are differences with the paper when used for a
%         %single layer...there they have one minus too much after the reduction
% end

function C1val=C1(kR,k,t)
    C1val=-2*(kR^2)*...
        ((f4(kR,k)+f3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
   *(g4(kR,k)+g3(kR,k)*exp(2*1i*k2z(kR,k)*t))...
    *(eps1*mu1-eps2*mu2)+...
    4*eps1*mu1*(k2z(kR,k)^2)*...
     (eps2*mu2-eps3*mu3)*exp(2*1i*k2z(kR,k)*t))./...
         (((g2(kR,k)*g4(kR,k)+g1(kR,k)*g3(kR,k)*exp(2*1i*k2z(kR,k)*t)))...
        *(f2(kR,k)*f4(kR,k)+f1(kR,k)*f3(kR,k)*exp(2*1i*k2z(kR,k)*t)));
        %NOOOOTEEE this has a minus sign at the beggining cause there is
        %soemthing wrong and with this it gets just as Femius Green's!!!!!!!!
        %Does Novotny do it on porpouse...??? I am starting to believe
        %so!!!!!!!!!!
end

function f1val=f1(kR,k)
f1val=eps2*k1z(kR,k)-eps1*k2z(kR,k);
%checked
end

function f2val=f2(kR,k)
f2val=eps2*k1z(kR,k)+eps1*k2z(kR,k);
%checked
end

function f3val=f3(kR,k)
f3val=eps3*k2z(kR,k)-eps2*k3z(kR,k);
%checked
end

function f4val=f4(kR,k)
f4val=eps3*k2z(kR,k)+eps2*k3z(kR,k);
%checked
end

function g1val=g1(kR,k)
g1val=mu2*k1z(kR,k)-mu1*k2z(kR,k);
%checked
end
function g2val=g2(kR,k)
g2val=mu2*k1z(kR,k)+mu1*k2z(kR,k);
%checked
end
function g3val=g3(kR,k)
g3val=mu3*k2z(kR,k)-mu2*k3z(kR,k);
%checked
end
function g4val=g4(kR,k)
g4val=mu3*k2z(kR,k)+mu2*k3z(kR,k);
%checked
end


end