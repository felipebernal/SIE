function Gqij=QuadrupolePropagatorFreeSpace(omega,epsilon,mu,rtoeval,rsource)
%CHECKED!!!
% Only for test pourposes
% omega=1;
% epsilon=1;
% mu=1;
% rtoeval=[1,2,3;4,5,6;7,8,9;1,1,2;1,2,3];
% rsource=[1,2,1;0,0,0;3,4,5;1,1,1;1,2,1];
%





c=1;
k=omega*sqrt(epsilon*mu)/c;
numpoints=size(rtoeval,1);
rij=(rtoeval-rsource);
R=sqrt(sum((rij).^2,2));
nij=rij./repmat(R,1,3);

firstfactor=(-ones(numpoints,1)-(1i*3)./(k*R)+6./(k^2*R.^2)+(1i*6)./(k^3*R.^3));

firstfactormat=repmat(reshape(firstfactor,1,1,numpoints),3,3).*repmat(eye(3,3),[1,1,numpoints]);


secondfactor=(ones(numpoints,1)+(1i*6)./(k*R)-15./(k^2*R.^2)-(1i*15)./(k^3*R.^3));
outernijnij=zeros(3,3,numpoints);
outernijnij(1,1,:)=nij(:,1).*nij(:,1);
outernijnij(1,2,:)=nij(:,1).*nij(:,2);
outernijnij(1,3,:)=nij(:,1).*nij(:,3);
outernijnij(2,1,:)=nij(:,2).*nij(:,1);
outernijnij(2,2,:)=nij(:,2).*nij(:,2);
outernijnij(2,3,:)=nij(:,2).*nij(:,3);
outernijnij(3,1,:)=nij(:,3).*nij(:,1);
outernijnij(3,2,:)=nij(:,3).*nij(:,2);
outernijnij(3,3,:)=nij(:,3).*nij(:,3);
secondfactormat=repmat(reshape(secondfactor,1,1,numpoints),3,3).*outernijnij;

lastfactor=repmat(reshape(1i*k*exp(1i*k*R)./(24*pi*R),1,1,numpoints),3,3);

Gqij=(firstfactormat+secondfactormat).*lastfactor;



end