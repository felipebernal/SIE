numberpoints=100;
theta1=linspace(0,pi,numberpoints).';
phi1=linspace(0,2*pi,numberpoints).';
[theta2 phi2]=meshgrid(theta1,phi1);
theta=theta2(:);
phi=phi2(:);

radius=100;
rtoeval=[sin(theta).*cos(phi)*radius,sin(theta).*sin(phi)*radius,cos(theta)*radius];
rsource=[0,0,0];
lambda=1;
c=1;
omega=2*pi*c/lambda;
muv=[1,1];
epsilonv=[1,1];
Q=[0,1,0;1,0,0;0,0,0];
sourceinout=1;
valfunEQuadrupole=QuadrupoleEField(omega,1,Q,rtoeval,rsource,muv,epsilonv,sourceinout);




x=sin(theta2).*cos(phi2);
y=sin(theta2).*sin(phi2);
z=cos(theta2);
rad=reshape(sqrt(sum(valfunEQuadrupole.*conj(valfunEQuadrupole),2)),size(x,1),[]);

%The efield multiplied by the rdirector and from there we get the phase;
%angles=reshape(angle(valfunEQuadrupole(:,2)),size(x,1),[]);
%Einrdirector=sin(theta).*cos(phi).*valfunEQuadrupole(:,1)+sin(theta).*sin(phi).*valfunEQuadrupole(:,2)+cos(theta).*valfunEQuadrupole(:,3);
Eintheta=cos(theta).*cos(phi).*valfunEQuadrupole(:,1)+cos(theta).*sin(phi).*valfunEQuadrupole(:,2)-sin(theta).*valfunEQuadrupole(:,3);

%angles=reshape(angle(Einrdirector),size(x,1),[]);
angles=reshape(angle(Eintheta),size(x,1),[]);

surf(rad.*x,rad.*y,rad.*z,angles);