function [coeffs]=invertdata(sampledata,theta,phi,weights,l),
%% this function does the actual fast spherical harmonic transfer
%% input is 
%% theta and phi from reducegrid
%% weights are integration weights also from sphergrid
%% sampledata are the LDOS values at the theta and phi.

%% note theta and phi are input as matrices but all rows (columns) are
%% copies, since I have used a meshgrid to make a mesh


theta=theta(1,:);

pre= weights;
done=0;
 

 

for n=0:l

    pnm=neglegendre(n,cos(theta));

    for m=-n:n,
        
        done=done+1;

%% first fourier transform over phi

   fftphi=sum(exp(-i*phi*m).*sampledata,1)/(size(phi,1));  %% the phi integral
   coeffs(done)=sum(pre.*pnm(m+n+1,:).*fftphi); %% the theta integral with weights
    end
end
