
%% This test routine tells you that the function  Ysum  can be used to output Ylm's
%%
%% trick is:  you tell it an l,
%% it now wants coefficients  for each m,  for each l up to the maxium l.

%%  if l = 2, m=-1 you tell it:
%%  0 ,  0, 0, 0,     0, 1, 0,0,0,

l=[0:1:2];
theta=[0:0.01:1]*pi;
phi=[0:0.01:2]*pi;
[theta phi]=meshgrid(theta,phi);


x=sin(theta).*cos(phi);
y=sin(theta).*sin(phi);
z=cos(theta);

theta=reshape(theta,1,prod(size(theta)));
phi=reshape(phi,1,prod(size(theta)));


coefbase=[];

for ll=0:length(l),
    for m=-ll:ll,
        coeff=zeros(1,2*ll+1);
        coeff(m+ll+1)=1;
        coeff=[coefbase, coeff];
        yllm=Ysum(ll,coeff,theta.',phi.');
    
        ll
        m
    
    figure(ll+1);
    subplot(ceil(sqrt(2*ll+1)),ceil(sqrt(2*ll+1)),m+ll+1)
    r=real(reshape(yllm,size(x)));
    surf(abs(r).*x,abs(r).*y,abs(r).*z,angle(r)); shading flat; axis image
    
    
    
    end

    
    coefbase=0*coeff
end



%%% next to do:  let us make a test function!!!
 lmax=10;
 lprobe=lmax-1
 coeff=[1:lmax^2+lmax*2+1];
 
 
% coeff(3)=1;
 coeff=exp(1i*sin(coeff));

 
 % plot of test function
 testfunction=Ysum(lmax,coeff,theta.',phi.');
 figure(31415)
 r=abs(reshape(testfunction,size(x)));
 c=angle(reshape(testfunction,size(x)));
 surf(abs(r).*x,abs(r).*y,abs(r).*z,c); shading flat; axis image
 

 
%%  CORE STUFF
%%
%%% make the special points and weight
[thetaspecial,phispecial,weights,thetagrid,phigrid]=sphergrid(lprobe)
%% sample function on those points.  Only in this example, we use Ysum.
testfunctionONSPECIALPOINTSONLY=Ysum(lmax,coeff,thetaspecial,phispecial);
%%  retrieve the coefficients
coeffretrieved= invertdata(conj(reshape(testfunctionONSPECIALPOINTSONLY,size(thetagrid))),thetagrid,phigrid,weights,lprobe);

 

%% plot all the results.

 
  % plot of special points
 figure(314152),
 surf(x,y,z,0*z+1); hold on; shading flat; camlight; axis image
 plot3(sin(thetaspecial).*cos(phispecial),sin(thetaspecial).*sin(phispecial),cos(thetaspecial),'d')

 %% function sampled ONLY on special points 

 r=abs(testfunctionONSPECIALPOINTSONLY);
 figure(31415)
hold on
 plot3(r.*sin(thetaspecial).*cos(phispecial),r.*sin(thetaspecial).*sin(phispecial),r.*cos(thetaspecial),'d')
hold off
 


%%  return the overlap integrals with Ylms



figure(2718)
plot([1:length(coeff)],real(coeff),'-x', [1:length(coeffretrieved)],real(coeffretrieved),'d'); ylim([0 max(abs(coeff))])
hold on
plot([1:length(coeff)],imag(coeff), 'r-x', [1:length(coeffretrieved)],imag(coeffretrieved),'dk'); ylim([0 max(abs(coeff))])
lexact=lprobe-1;
plot((lexact+1).^2*[1 1],[0,max(abs(coeff))])
hold off

%


%%  ANOTHER EXAMPLE - THIS TEST FUNCTION DOES NOT DERIVE A PRIORI FROM YLMs
%%
%%% make the special points and weight

f = @(x,y,z)  x.^3-y.*x + z.^2-z.*x
r=f(x,y,z);
lprobe=5
[thetaspecial,phispecial,weights,thetagrid,phigrid]=sphergrid(lprobe)



%% sample function on those points.  Only in this example, we use Ysum.
testfunctionONSPECIALPOINTSONLY=f(cos(phigrid).*sin(thetagrid),sin(phigrid).*sin(thetagrid),cos(thetagrid));
%%  retrieve the coefficients
coeffretrieved= invertdata( (reshape(testfunctionONSPECIALPOINTSONLY,size(thetagrid))),thetagrid,phigrid,weights,lprobe);

figure(1001)
%% COMPARE ORIGINAL WITH DECOMPOSED

subplot(2,1,1)
surf(r.*x,r.*y,r.*z); shading flat; axis image, camlight
subplot(2,1,2)
        yllm=Ysum(ll,coeffretrieved,theta.',phi.');
 r=real(reshape(yllm,size(x)));
    surf((r).*x,(r).*y,(r).*z); shading flat; axis image; camlight
    



